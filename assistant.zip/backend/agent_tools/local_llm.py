"""
agent_tools/local_llm.py  —  Local LLM Tier (Ollama)

This module is the interface to the local Ollama instance.
It is NOT a registered tool (Claude doesn't call it directly). Instead, agent_core.py
and main.py call it for preprocessing tasks before/after Claude API calls:

  optimize_prompt()     — Rewrite raw user input into a clean, precise prompt.
  summarize_history()   — Compress old conversation turns into a compact summary.
  local_llm_call()      — Generic single-turn completion via /api/generate.
  local_agent_call()    — Full agentic loop via /api/chat with tool use (Feature 3).
  is_ollama_available() — Quick health check used for status display in the UI.

All functions handle Ollama being offline gracefully: they log a warning and return
None / the original input, never raising exceptions to the caller.
"""

import json
import logging
import httpx
from typing import Optional, Any

logger = logging.getLogger(__name__)

# Ollama's default address. Can be overridden via config.json → "ollama_base_url"
DEFAULT_BASE_URL    = "http://localhost:11434"
DEFAULT_MODEL       = "qwen2.5:7b"
DEFAULT_AGENT_MODEL = "qwen2.5:14b"

# Generous timeouts: local inference can be slow on CPU
GENERATE_TIMEOUT = 60.0
# NOTE: local_agent_call() no longer uses CHAT_TIMEOUT — it accepts a `timeout`
# parameter so the caller (agent_core.py) can pass config-driven values.
# CHAT_TIMEOUT is kept here only for reference / backward compatibility.
CHAT_TIMEOUT     = 300.0
HEALTH_TIMEOUT   = 3.0


async def local_llm_call(
    prompt: str,
    model: str = DEFAULT_MODEL,
    system: Optional[str] = None,
    base_url: str = DEFAULT_BASE_URL,
) -> Optional[str]:
    """
    Send a single prompt to the Ollama /api/generate endpoint and return the response.

    Uses stream=False so we get the full response in one HTTP response body,
    which is simpler to handle than streaming for short preprocessing tasks.

    Returns None if Ollama is unreachable or returns an error — never raises.
    """
    payload: dict = {
        "model":  model,
        "prompt": prompt,
        "stream": False,
    }
    if system:
        payload["system"] = system

    try:
        async with httpx.AsyncClient(timeout=GENERATE_TIMEOUT) as client:
            response = await client.post(f"{base_url}/api/generate", json=payload)
            response.raise_for_status()
            data = response.json()
            text = data.get("response", "").strip()
            return text if text else None

    except httpx.ConnectError:
        logger.warning("[local_llm] Ollama is offline (connection refused).")
        return None
    except httpx.TimeoutException:
        logger.warning(f"[local_llm] Ollama request timed out after {GENERATE_TIMEOUT}s.")
        return None
    except httpx.HTTPStatusError as e:
        logger.warning(f"[local_llm] Ollama returned HTTP {e.response.status_code}.")
        return None
    except Exception as e:
        logger.warning(f"[local_llm] Unexpected error calling Ollama: {e}")
        return None


async def optimize_prompt(
    raw_message: str,
    model: str = DEFAULT_MODEL,
    base_url: str = DEFAULT_BASE_URL,
) -> str:
    """
    Use the local LLM to rewrite a raw user message into a clean, precise prompt
    for Claude.

    Falls back to the ORIGINAL message if Ollama is offline or returns garbage.
    This means the system still works 100% without a local model.
    """
    system = (
        "You are a prompt optimizer for an AI assistant. "
        "Rewrite the user's message into a clear, concise, and unambiguous instruction. "
        "Preserve the original intent exactly. Fix grammar and remove filler words. "
        "Output ONLY the rewritten prompt — no explanation, no quotes, no preamble."
    )

    result = await local_llm_call(
        prompt=raw_message,
        model=model,
        system=system,
        base_url=base_url,
    )

    if result is None:
        logger.info("[local_llm] optimize_prompt: fallback to original (Ollama unavailable).")
        return raw_message

    # Sanity check: if the result is wildly longer than the input, something went wrong
    if len(result) > len(raw_message) * 3:
        logger.warning("[local_llm] optimize_prompt: result suspiciously long, using original.")
        return raw_message

    if result == raw_message:
        logger.debug("[local_llm] optimize_prompt: no change needed.")
    else:
        logger.info(
            f"[local_llm] Prompt optimized:\n"
            f"  ORIGINAL : {raw_message[:80]!r}\n"
            f"  OPTIMIZED: {result[:80]!r}"
        )

    return result


async def summarize_history(
    turns: list[dict],
    model: str = DEFAULT_MODEL,
    base_url: str = DEFAULT_BASE_URL,
    max_chars_per_turn: int = 300,
) -> Optional[str]:
    """
    Compress a list of old conversation turns into a compact natural-language summary.

    Called by build_context() in main.py when the conversation history grows beyond
    the recent-turns window. The summary is injected into Claude's system prompt.
    """
    if not turns:
        return None

    transcript_lines = []
    for entry in turns:
        role    = entry.get("role", "?")
        content = entry.get("content", "")[:max_chars_per_turn]
        if len(entry.get("content", "")) > max_chars_per_turn:
            content += "…"
        transcript_lines.append(f"{role.upper()}: {content}")

    transcript = "\n".join(transcript_lines)

    system = (
        "You are a conversation summarizer for an AI agent system. "
        "Your summary will be injected into a system prompt, so it must be dense and factual. "
        "Output ONLY the summary — no preamble, no labels, no markdown."
    )

    prompt = (
        f"Summarize this conversation history in 3-5 sentences. "
        f"Focus on: what the user is building or trying to accomplish, "
        f"key decisions or conclusions reached, any errors that were resolved, "
        f"and stated preferences or constraints.\n\n"
        f"CONVERSATION:\n{transcript}"
    )

    result = await local_llm_call(
        prompt=prompt,
        model=model,
        system=system,
        base_url=base_url,
    )

    if result:
        logger.info(
            f"[local_llm] summarize_history: compressed {len(turns)} entries "
            f"→ {len(result)} chars."
        )

    return result


async def local_agent_call(
    prompt: str,
    tools: list[dict],
    messages: list[dict],
    model: str = DEFAULT_AGENT_MODEL,
    base_url: str = DEFAULT_BASE_URL,
    max_iterations: int = 10,
    tool_dispatcher: Any = None,
    timeout: float = 300.0,
) -> str:
    """
    Run a full agentic loop entirely through Ollama — no Claude API required.

    Uses Ollama's /api/chat endpoint with OpenAI-compatible tool calling
    (supported by qwen2.5:14b and similar function-calling capable models).

    The loop mirrors agent_core.py's Claude loop:
      1. Send current messages + tool definitions to Ollama.
      2. If the model emits tool calls, dispatch them and feed results back.
      3. Repeat until the model returns a plain text response.
      4. Return the final text.

    Args:
        prompt:          The current user message (already appended to messages).
        tools:           List of tool definitions in Anthropic format (name, description,
                         input_schema). Converted to Ollama/OpenAI format internally.
        messages:        Full message history in [{role, content}] format.
        model:           Ollama model to use (default: qwen2.5:14b).
        base_url:        Ollama base URL.
        max_iterations:  Safety cap on tool call rounds to prevent infinite loops.
        tool_dispatcher: Async callable(tool_name, tool_input) → dict result.
                         Passed in from agent_core so we don't import it here
                         (avoids circular imports). If None, tool calls return errors.
        timeout:         Per-request HTTP timeout in seconds. Configurable via
                         config.json → "local_agent_timeout" (default 300s).
                         Larger models on CPU may need several minutes per response.

    Returns:
        Final text response string, or an error message if Ollama is unreachable.
    """

    # --- Convert Anthropic-format tool definitions to Ollama/OpenAI format ---
    # Anthropic: {"name": ..., "description": ..., "input_schema": {...}}
    # OpenAI:    {"type": "function", "function": {"name": ..., "description": ..., "parameters": {...}}}
    ollama_tools = []
    for t in tools:
        ollama_tools.append({
            "type": "function",
            "function": {
                "name":        t["name"],
                "description": t.get("description", ""),
                "parameters":  t.get("input_schema", {"type": "object", "properties": {}}),
            },
        })

    # Build the working message list (deep copy so we don't mutate the caller's list)
    working_messages = list(messages)

    for iteration in range(max_iterations):
        logger.info(f"[local_llm] local_agent_call iteration {iteration + 1} (timeout={timeout}s)")

        payload = {
            "model":    model,
            "messages": working_messages,
            "tools":    ollama_tools,
            "stream":   False,
        }

        try:
            # Use the caller-supplied timeout so large models get enough time
            async with httpx.AsyncClient(timeout=timeout) as client:
                resp = await client.post(f"{base_url}/api/chat", json=payload)
                resp.raise_for_status()
                data = resp.json()
        except httpx.ConnectError:
            logger.warning("[local_llm] Ollama offline during local_agent_call.")
            return "Error: local Ollama is not running. Start Ollama and try again."
        except httpx.TimeoutException:
            logger.warning(f"[local_llm] local_agent_call timed out after {timeout}s.")
            return (
                f"Error: local model timed out after {timeout}s. "
                "Try increasing local_agent_timeout in config, or use a smaller model."
            )
        except httpx.HTTPStatusError as e:
            logger.warning(f"[local_llm] Ollama HTTP {e.response.status_code} in local_agent_call.")
            return f"Error: Ollama returned HTTP {e.response.status_code}."
        except Exception as e:
            logger.warning(f"[local_llm] Unexpected error in local_agent_call: {e}")
            return f"Error: {e}"

        # Extract the assistant message from the response
        assistant_msg = data.get("message", {})
        content       = assistant_msg.get("content", "")
        tool_calls    = assistant_msg.get("tool_calls", [])

        # Append the assistant's turn to the working message list
        working_messages.append({
            "role":       "assistant",
            "content":    content,
            "tool_calls": tool_calls,
        })

        # --- No tool calls: final answer ---
        if not tool_calls:
            logger.info(f"[local_llm] local_agent_call finished in {iteration + 1} iteration(s).")
            return content.strip() if content else "No response generated."

        # --- Tool calls: dispatch each one and feed results back ---
        tool_result_messages = []
        for tc in tool_calls:
            fn   = tc.get("function", {})
            name = fn.get("name", "")
            # Arguments may be a JSON string or already a dict
            raw_args = fn.get("arguments", {})
            if isinstance(raw_args, str):
                try:
                    args = json.loads(raw_args)
                except json.JSONDecodeError:
                    args = {}
            else:
                args = raw_args

            logger.info(f"[local_llm] Tool call: {name}({args})")

            if tool_dispatcher is not None:
                try:
                    result = await tool_dispatcher(name, args)
                except Exception as e:
                    result = {"success": False, "error": str(e)}
            else:
                result = {"success": False, "error": "No tool dispatcher available in local mode."}

            # Ollama expects tool results as role="tool" messages
            tool_result_messages.append({
                "role":    "tool",
                "content": json.dumps(result, ensure_ascii=False),
                "name":    name,
            })

        working_messages.extend(tool_result_messages)

    # Reached max iterations without a final answer
    return "Error: local agent reached the maximum number of tool-use iterations without a final answer."


async def is_ollama_available(base_url: str = DEFAULT_BASE_URL) -> bool:
    """
    Quick health check: return True if Ollama is running and responsive.
    Used by main.py on startup and by the frontend status endpoint.
    Hits /api/tags which lists available models — a lightweight endpoint.
    """
    try:
        async with httpx.AsyncClient(timeout=HEALTH_TIMEOUT) as client:
            resp = await client.get(f"{base_url}/api/tags")
            return resp.status_code == 200
    except Exception:
        return False
