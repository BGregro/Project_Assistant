#!/usr/bin/env python3
"""
Simple CLI Calculator
Supports: +, -, *, /
"""

from operations import add, subtract, multiply, divide
from errors import validate_operator, validate_number

def print_welcome():
    print("\n" + "="*50)
    print("  Welcome to the CLI Calculator")
    print("="*50)
    print("Supported operations: +, -, *, /")
    print("Type 'quit', 'exit', or 'q' to exit")
    print("="*50 + "\n")

def main():
    print_welcome()
    
    while True:
        try:
            # Get user input
            user_input = input("Enter calculation (e.g., 5 + 3): ").strip()
            
            # Check for exit commands
            if user_input.lower() in ['quit', 'exit', 'q']:
                print("\nGoodbye!")
                break
            
            # Skip empty input
            if not user_input:
                print("Please enter a calculation.\n")
                continue
            
            # Parse input
            parts = user_input.split()
            if len(parts) != 3:
                print("Invalid format. Please use: number operator number\n")
                continue
            
            num1_str, operator, num2_str = parts
            
            # Validate inputs
            num1 = validate_number(num1_str)
            num2 = validate_number(num2_str)
            validate_operator(operator)
            
            # Perform calculation
            if operator == '+':
                result = add(num1, num2)
            elif operator == '-':
                result = subtract(num1, num2)
            elif operator == '*':
                result = multiply(num1, num2)
            elif operator == '/':
                result = divide(num1, num2)
            
            print(f"Result: {num1} {operator} {num2} = {result}\n")
        
        except ValueError as e:
            print(f"Error: {e}\n")
        except ZeroDivisionError as e:
            print(f"Error: {e}\n")
        except Exception as e:
            print(f"Unexpected error: {e}\n")

if __name__ == '__main__':
    main()
