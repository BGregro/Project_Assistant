"""
Input validation and error handling for the calculator
"""

def validate_number(value: str) -> float:
    """
    Validate and convert a string to a number
    
    Args:
        value: String to validate
        
    Returns:
        float: The converted number
        
    Raises:
        ValueError: If the string cannot be converted to a number
    """
    try:
        return float(value)
    except ValueError:
        raise ValueError(f"'{value}' is not a valid number")

def validate_operator(operator: str) -> None:
    """
    Validate that the operator is supported
    
    Args:
        operator: The operator to validate
        
    Raises:
        ValueError: If the operator is not supported
    """
    valid_operators = ['+', '-', '*', '/']
    if operator not in valid_operators:
        raise ValueError(f"'{operator}' is not a valid operator. Supported: {', '.join(valid_operators)}")
