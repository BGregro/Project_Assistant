"""
YouTube Shorts Analytics - Main Orchestrator

Orchestrates the complete analytics pipeline:
- Data collection from YouTube APIs
- Performance analysis and correlation
- ML-based recommendations
- Report generation
"""

import argparse
import json
import logging
import sys
from datetime import datetime, timedelta
from pathlib import Path

# Import analytics modules
from data_collection.data_collector import YouTubeAnalyticsCollector, setup_logging as setup_collector_logging
from data_processing.thumbnail_processor import ThumbnailPerformanceAnalyzer, setup_logging as setup_processor_logging
from recommendation_generator.recommendations import RecommendationEngine, setup_logging as setup_rec_logging
from report_generator.report import ReportGenerator, setup_logging as setup_report_logging


# Configure logging
logger = logging.getLogger(__name__)


class YouTubeShortsAnalytics:
    """Main analytics orchestrator."""
    
    def __init__(self):
        """Initialize analytics system."""
        self.setup_logging()
        self.collector = YouTubeAnalyticsCollector()
        self.analyzer = ThumbnailPerformanceAnalyzer()
        self.engine = RecommendationEngine()
        self.reporter = ReportGenerator()
        self.results = {}
    
    def setup_logging(self):
        """Configure logging for all modules."""
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler('analytics.log'),
                logging.StreamHandler()
            ]
        )
    
    def run_full_analysis(self, days: int = 30) -> Dict:
        """
        Run complete analysis pipeline.
        
        Args:
            days: Number of days to analyze
        
        Returns:
            Dictionary with results from all steps
        """
        print("\n" + "="*70)
        print("🚀 YouTube Shorts Analytics - Full Pipeline")
        print("="*70 + "\n")
        
        self.results = {
            'timestamp': datetime.now().isoformat(),
            'steps': {},
            'errors': []
        }
        
        # Step 1: Data Collection
        print("📊 Step 1: Collecting YouTube Analytics Data...")
        print("-"*70)
        self._run_collection(days)
        
        # Step 2: Data Processing
        print("\n📈 Step 2: Processing and Analyzing Data...")
        print("-"*70)
        self._run_analysis()
        
        # Step 3: ML Recommendations
        print("\n🤖 Step 3: Generating ML Recommendations...")
        print("-"*70)
        self._run_recommendations()
        
        # Step 4: Report Generation
        print("\n📄 Step 4: Generating Reports...")
        print("-"*70)
        self._run_reports()
        
        # Summary
        self._print_summary()
        
        return self.results
    
    def _run_collection(self, days: int = 30) -> bool:
        """Collect YouTube analytics data."""
        try:
            if not self.collector.youtube or not self.collector.analytics:
                logger.error("❌ YouTube API not initialized")
                logger.info("Run 'python setup_auth.py' to authenticate")
                self.results['errors'].append("YouTube API authentication required")
                return False
            
            # Get videos
            videos = self.collector.get_videos(min_results=50)
            
            if not videos:
                logger.warning("⚠ No videos found")
                self.results['steps']['collection'] = {
                    'success': False,
                    'message': 'No videos found'
                }
                return False
            
            # Get analytics for date range
            end_date = datetime.now().date()
            start_date = end_date - timedelta(days=days)
            
            analytics = self.collector.get_analytics_metrics(
                start_date=start_date.isoformat(),
                end_date=end_date.isoformat()
            )
            
            # Cache data
            self.collector.cache_data(videos, 'videos.json')
            if analytics is not None:
                self.collector.cache_data(analytics.to_dict(), 'analytics.json')
            
            self.results['steps']['collection'] = {
                'success': True,
                'videos_collected': len(videos),
                'analytics_days': len(analytics) if analytics is not None else 0,
                'date_range': f"{start_date} to {end_date}"
            }
            
            print(f"✓ Collected {len(videos)} videos")
            print(f"✓ Retrieved {len(analytics) if analytics is not None else 0} days of analytics")
            return True
        
        except Exception as e:
            logger.error(f"❌ Collection error: {e}")
            self.results['errors'].append(f"Collection error: {str(e)}")
            self.results['steps']['collection'] = {'success': False, 'error': str(e)}
            return False
    
    def _run_analysis(self) -> bool:
        """Analyze thumbnail performance correlation."""
        try:
            correlation_df = self.analyzer.correlate_thumbnails_with_performance()
            
            if correlation_df is None or correlation_df.empty:
                logger.warning("⚠ No correlation data available")
                self.results['steps']['analysis'] = {
                    'success': False,
                    'message': 'Insufficient data for analysis'
                }
                return False
            
            # Get variant performance
            variant_stats = self.analyzer.aggregate_performance_by_variant(correlation_df)
            
            # Get insights
            insights = self.analyzer.get_correlation_insights(correlation_df)
            
            # Generate comparison table
            comparison = self.analyzer.compare_variants()
            
            self.results['steps']['analysis'] = {
                'success': True,
                'videos_analyzed': len(correlation_df),
                'variants_tested': len(variant_stats),
                'top_variant': self.analyzer.get_top_performing_variant(),
                'variant_stats': variant_stats,
                'insights': insights
            }
            
            print(f"✓ Analyzed {len(correlation_df)} videos")
            print(f"✓ Tested {len(variant_stats)} thumbnail variants")
            if 'top_performing_variant' in insights:
                print(f"✓ Top performer: {insights['top_performing_variant']}")
            
            return True
        
        except Exception as e:
            logger.error(f"❌ Analysis error: {e}")
            self.results['errors'].append(f"Analysis error: {str(e)}")
            self.results['steps']['analysis'] = {'success': False, 'error': str(e)}
            return False
    
    def _run_recommendations(self) -> bool:
        """Generate ML-based recommendations."""
        try:
            recommendations = self.engine.generate_recommendations(
                confidence_threshold=0.6
            )
            
            if not recommendations:
                logger.warning("⚠ Could not generate recommendations")
                self.results['steps']['recommendations'] = {
                    'success': False,
                    'message': 'Insufficient data for recommendations'
                }
                return False
            
            self.results['steps']['recommendations'] = {
                'success': True,
                'model_r2': recommendations.get('model_metrics', {}).get('test_r2'),
                'recommendations_count': len(recommendations.get('variant_recommendations', [])),
                'top_recommendation': recommendations['variant_recommendations'][0] if recommendations.get('variant_recommendations') else None,
                'recommendations': recommendations
            }
            
            if recommendations.get('variant_recommendations'):
                top = recommendations['variant_recommendations'][0]
                print(f"✓ Generated {len(recommendations['variant_recommendations'])} recommendations")
                print(f"✓ Top recommendation: {top['variant']} ({top['action']})")
            
            return True
        
        except Exception as e:
            logger.error(f"❌ Recommendation error: {e}")
            self.results['errors'].append(f"Recommendation error: {str(e)}")
            self.results['steps']['recommendations'] = {'success': False, 'error': str(e)}
            return False
    
    def _run_reports(self) -> bool:
        """Generate performance reports."""
        try:
            # Weekly report
            weekly = self.reporter.generate_weekly_report(output_format='html')
            
            # Monthly report
            monthly = self.reporter.generate_monthly_report(output_format='html')
            
            self.results['steps']['reports'] = {
                'success': True,
                'weekly_report': str(weekly) if weekly else None,
                'monthly_report': str(monthly) if monthly else None,
            }
            
            if weekly:
                print(f"✓ Weekly report: {Path(weekly).name}")
            if monthly:
                print(f"✓ Monthly report: {Path(monthly).name}")
            
            return True
        
        except Exception as e:
            logger.error(f"❌ Report error: {e}")
            self.results['errors'].append(f"Report error: {str(e)}")
            self.results['steps']['reports'] = {'success': False, 'error': str(e)}
            return False
    
    def _print_summary(self):
        """Print analysis summary."""
        print("\n" + "="*70)
        print("📋 ANALYSIS SUMMARY")
        print("="*70)
        
        for step, result in self.results['steps'].items():
            status = "✓" if result.get('success') else "✗"
            print(f"\n{status} {step.upper()}")
            
            if result.get('success'):
                for key, value in result.items():
                    if key not in ['success', 'error', 'insights', 'recommendations', 'variant_stats', 'model_metrics', 'model_r2']:
                        if isinstance(value, dict):
                            print(f"  {key}: {len(value)} items")
                        elif value is not None:
                            print(f"  {key}: {value}")
        
        print("\n" + "="*70)
        
        if self.results['errors']:
            print("\n⚠️  ERRORS:")
            for error in self.results['errors']:
                print(f"  - {error}")
        
        print("\n✅ Analysis Complete!")
        print("="*70 + "\n")
    
    def save_results(self, filename: str = 'analysis_results.json'):
        """Save analysis results to JSON."""
        try:
            output_path = Path('data') / filename
            
            # Convert non-serializable objects
            serializable_results = {
                'timestamp': self.results['timestamp'],
                'steps': {},
                'errors': self.results['errors']
            }
            
            for step, result in self.results['steps'].items():
                # Convert complex objects to strings
                clean_result = {}
                for key, value in result.items():
                    if isinstance(value, (dict, list)):
                        clean_result[key] = str(value)
                    else:
                        clean_result[key] = value
                serializable_results['steps'][step] = clean_result
            
            with open(output_path, 'w') as f:
                json.dump(serializable_results, f, indent=2)
            
            logger.info(f"✓ Results saved to {output_path}")
        
        except Exception as e:
            logger.error(f"❌ Error saving results: {e}")


def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(
        description='YouTube Shorts Analytics System - Phase 2',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python main.py --action full --days 30
  python main.py --action collect --days 7
  python main.py --action analyze
  python main.py --action recommend
  python main.py --action report-weekly
        """
    )
    
    parser.add_argument(
        '--action',
        choices=['full', 'collect', 'analyze', 'recommend', 'report-weekly', 'report-monthly'],
        default='full',
        help='Action to perform (default: full)'
    )
    
    parser.add_argument(
        '--days',
        type=int,
        default=30,
        help='Number of days to analyze (default: 30)'
    )
    
    args = parser.parse_args()
    
    try:
        analytics = YouTubeShortsAnalytics()
        
        if args.action == 'full':
            results = analytics.run_full_analysis(days=args.days)
            analytics.save_results()
        
        elif args.action == 'collect':
            print("\n📊 Collecting YouTube Analytics...")
            analytics._run_collection(args.days)
        
        elif args.action == 'analyze':
            print("\n📈 Analyzing Data...")
            analytics._run_analysis()
        
        elif args.action == 'recommend':
            print("\n🤖 Generating Recommendations...")
            analytics._run_recommendations()
        
        elif args.action == 'report-weekly':
            print("\n📄 Generating Weekly Report...")
            analytics._run_reports()
        
        elif args.action == 'report-monthly':
            print("\n📄 Generating Monthly Report...")
            analytics._run_reports()
    
    except KeyboardInterrupt:
        print("\n\n❌ Interrupted by user")
        sys.exit(1)
    except Exception as e:
        logger.error(f"❌ Fatal error: {e}")
        sys.exit(1)


if __name__ == '__main__':
    main()
