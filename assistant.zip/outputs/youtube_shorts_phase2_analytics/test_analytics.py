"""
Tests for YouTube Shorts Analytics System - Phase 2
Validates project structure and module organization.
"""

import json
import pytest
from pathlib import Path


def test_project_structure():
    """Test that all required directories exist."""
    required_dirs = [
        'auth',
        'data_collection',
        'data_processing',
        'recommendation_generator',
        'report_generator',
    ]
    
    project_root = Path(__file__).parent
    for dir_name in required_dirs:
        dir_path = project_root / dir_name
        assert dir_path.exists(), f"Missing directory: {dir_name}"
        assert dir_path.is_dir(), f"Not a directory: {dir_name}"


def test_main_script_exists():
    """Test main.py exists."""
    main_file = Path(__file__).parent / 'main.py'
    assert main_file.exists(), "main.py not found"


def test_requirements_file_exists():
    """Test requirements.txt exists."""
    req_file = Path(__file__).parent / 'requirements.txt'
    assert req_file.exists(), "requirements.txt not found"
    
    with open(req_file, encoding='utf-8') as f:
        content = f.read()
    
    required_packages = [
        'google-api-python-client',
        'pandas',
        'scikit-learn',
    ]
    
    for pkg in required_packages:
        assert pkg.lower() in content.lower(), f"Missing dependency: {pkg}"


def test_readme_exists():
    """Test that README.md exists."""
    readme_file = Path(__file__).parent / 'README.md'
    assert readme_file.exists(), "README.md not found"


def test_scaffold_json_exists():
    """Test that scaffold.json exists and is valid."""
    scaffold_file = Path(__file__).parent / 'scaffold.json'
    assert scaffold_file.exists(), "scaffold.json not found"
    
    with open(scaffold_file, encoding='utf-8') as f:
        scaffold = json.load(f)
    
    assert 'name' in scaffold
    assert 'description' in scaffold


def test_auth_module_structure():
    """Test auth module files exist."""
    auth_dir = Path(__file__).parent / 'auth'
    required_files = ['__init__.py', 'auth.py']
    
    for file_name in required_files:
        file_path = auth_dir / file_name
        assert file_path.exists(), f"Missing file: auth/{file_name}"


def test_data_collection_module_structure():
    """Test data collection module files exist."""
    data_dir = Path(__file__).parent / 'data_collection'
    required_files = ['__init__.py', 'data_collector.py']
    
    for file_name in required_files:
        file_path = data_dir / file_name
        assert file_path.exists(), f"Missing file: data_collection/{file_name}"


def test_data_processing_module_structure():
    """Test data processing module files exist."""
    data_dir = Path(__file__).parent / 'data_processing'
    required_files = ['__init__.py', 'thumbnail_processor.py']
    
    for file_name in required_files:
        file_path = data_dir / file_name
        assert file_path.exists(), f"Missing file: data_processing/{file_name}"


def test_recommendation_module_structure():
    """Test recommendation module files exist."""
    rec_dir = Path(__file__).parent / 'recommendation_generator'
    required_files = ['__init__.py', 'recommendations.py']
    
    for file_name in required_files:
        file_path = rec_dir / file_name
        assert file_path.exists(), f"Missing file: recommendation_generator/{file_name}"


def test_report_module_structure():
    """Test report module files exist."""
    report_dir = Path(__file__).parent / 'report_generator'
    required_files = ['__init__.py', 'report.py']
    
    for file_name in required_files:
        file_path = report_dir / file_name
        assert file_path.exists(), f"Missing file: report_generator/{file_name}"


def test_setup_auth_script_exists():
    """Test setup_auth.py exists."""
    setup_file = Path(__file__).parent / 'setup_auth.py'
    assert setup_file.exists(), "setup_auth.py not found"


def test_python_files_are_valid():
    """Test that Python files have valid syntax."""
    project_root = Path(__file__).parent
    python_files = list(project_root.glob('**/*.py'))
    
    python_files = [f for f in python_files if '__pycache__' not in str(f)]
    
    assert len(python_files) > 0, "No Python files found"
    
    for py_file in python_files:
        try:
            with open(py_file, encoding='utf-8') as f:
                compile(f.read(), str(py_file), 'exec')
        except SyntaxError as e:
            pytest.fail(f"Syntax error in {py_file}: {e}")


def test_data_directory_exists():
    """Test that data directory exists."""
    data_dir = Path(__file__).parent / 'data'
    assert data_dir.exists(), "data directory not found"
    assert data_dir.is_dir(), "data is not a directory"


def test_progress_json_exists():
    """Test that progress.json was created."""
    progress_file = Path(__file__).parent / 'progress.json'
    assert progress_file.exists(), "progress.json not found"


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
