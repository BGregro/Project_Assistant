"""
Report Generation System

Creates HTML and text reports for YouTube Shorts performance analytics.
Generates weekly and monthly summaries with actionable insights.
"""

import json
import logging
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional
import pandas as pd


logger = logging.getLogger(__name__)


class ReportGenerator:
    """Generates performance reports for YouTube analytics."""
    
    def __init__(self, data_dir: str = 'data', output_dir: str = 'reports'):
        """
        Initialize report generator.
        
        Args:
            data_dir: Directory containing analytics data
            output_dir: Directory to save generated reports
        """
        self.data_dir = Path(data_dir)
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(exist_ok=True)
        
        self.videos_df = None
        self.analytics_df = None
        self._load_data()
    
    def _load_data(self):
        """Load video and analytics data."""
        try:
            # Load videos
            videos_file = self.data_dir / 'videos.json'
            if videos_file.exists():
                with open(videos_file, 'r') as f:
                    self.videos_df = pd.DataFrame(json.load(f))
            
            # Load analytics
            analytics_file = self.data_dir / 'analytics.json'
            if analytics_file.exists():
                with open(analytics_file, 'r') as f:
                    self.analytics_df = pd.DataFrame(json.load(f))
        
        except Exception as e:
            logger.warning(f"⚠ Could not load data: {e}")
    
    def generate_weekly_report(self,
                              week_offset: int = 0,
                              output_format: str = 'html') -> Optional[str]:
        """
        Generate weekly performance report.
        
        Args:
            week_offset: Weeks to look back (0 = current week)
            output_format: 'html' or 'text'
        
        Returns:
            Path to generated report
        """
        try:
            # Calculate date range
            today = datetime.now().date()
            week_start = today - timedelta(days=today.weekday() + (week_offset * 7))
            week_end = week_start + timedelta(days=6)
            
            # Generate report data
            report_data = self._generate_report_data(week_start, week_end, 'weekly')
            
            if not report_data:
                logger.warning("⚠ No data for report")
                return None
            
            # Generate output
            if output_format == 'html':
                filename = f"weekly_report_{week_start.isoformat()}.html"
                output_file = self.output_dir / filename
                self._write_html_report(output_file, report_data, 'weekly')
            else:
                filename = f"weekly_report_{week_start.isoformat()}.txt"
                output_file = self.output_dir / filename
                self._write_text_report(output_file, report_data, 'weekly')
            
            logger.info(f"✓ Weekly report generated: {filename}")
            return str(output_file)
        
        except Exception as e:
            logger.error(f"❌ Error generating weekly report: {e}")
            return None
    
    def generate_monthly_report(self,
                               month_offset: int = 0,
                               output_format: str = 'html') -> Optional[str]:
        """
        Generate monthly performance report.
        
        Args:
            month_offset: Months to look back (0 = current month)
            output_format: 'html' or 'text'
        
        Returns:
            Path to generated report
        """
        try:
            # Calculate date range
            today = datetime.now().date()
            month_start = (today.replace(day=1) - 
                          timedelta(days=1) * month_offset).replace(day=1)
            
            # Get last day of month
            next_month = month_start + timedelta(days=32)
            month_end = (next_month.replace(day=1) - timedelta(days=1))
            
            # Generate report data
            report_data = self._generate_report_data(month_start, month_end, 'monthly')
            
            if not report_data:
                logger.warning("⚠ No data for report")
                return None
            
            # Generate output
            if output_format == 'html':
                filename = f"monthly_report_{month_start.isoformat()}.html"
                output_file = self.output_dir / filename
                self._write_html_report(output_file, report_data, 'monthly')
            else:
                filename = f"monthly_report_{month_start.isoformat()}.txt"
                output_file = self.output_dir / filename
                self._write_text_report(output_file, report_data, 'monthly')
            
            logger.info(f"✓ Monthly report generated: {filename}")
            return str(output_file)
        
        except Exception as e:
            logger.error(f"❌ Error generating monthly report: {e}")
            return None
    
    def _generate_report_data(self,
                             start_date,
                             end_date,
                             report_type: str) -> Optional[Dict]:
        """Generate report data for date range."""
        try:
            if self.videos_df is None:
                return None
            
            # Filter videos by date
            df = self.videos_df.copy()
            df['published_at'] = pd.to_datetime(df['published_at']).dt.date
            
            period_videos = df[
                (df['published_at'] >= start_date) &
                (df['published_at'] <= end_date)
            ]
            
            if period_videos.empty:
                return None
            
            # Calculate metrics
            total_views = period_videos['view_count'].sum()
            total_likes = period_videos['like_count'].sum()
            total_comments = period_videos['comment_count'].sum()
            
            engagement_rate = (
                (total_likes + total_comments) / 
                max(total_views, 1)
            ) * 100
            
            # Top videos
            top_videos = period_videos.nlargest(5, 'view_count')[
                ['title', 'view_count', 'like_count', 'comment_count']
            ].to_dict('records')
            
            # Variant performance
            variant_perf = {}
            if 'thumbnail_variant' in period_videos.columns:
                for variant in ['v1', 'v2', 'v3', 'v4', 'v5']:
                    variant_data = period_videos[
                        period_videos['thumbnail_variant'] == variant
                    ]
                    if not variant_data.empty:
                        variant_perf[variant] = {
                            'count': len(variant_data),
                            'avg_views': variant_data['view_count'].mean(),
                            'total_views': variant_data['view_count'].sum(),
                        }
            
            report_data = {
                'report_type': report_type,
                'generated_at': datetime.now().isoformat(),
                'period': {
                    'start': str(start_date),
                    'end': str(end_date),
                },
                'summary': {
                    'total_videos': len(period_videos),
                    'total_views': int(total_views),
                    'total_likes': int(total_likes),
                    'total_comments': int(total_comments),
                    'engagement_rate': round(engagement_rate, 2),
                    'avg_views_per_video': int(total_views / len(period_videos)),
                },
                'top_videos': top_videos,
                'variant_performance': variant_perf,
            }
            
            return report_data
        
        except Exception as e:
            logger.error(f"❌ Error generating report data: {e}")
            return None
    
    def _write_html_report(self, filepath: Path, data: Dict, report_type: str):
        """Write HTML report file."""
        html_content = self._render_html_template(data, report_type)
        
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(html_content)
    
    def _write_text_report(self, filepath: Path, data: Dict, report_type: str):
        """Write text report file."""
        text_content = self._render_text_template(data, report_type)
        
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(text_content)
    
    def _render_html_template(self, data: Dict, report_type: str) -> str:
        """Render HTML template."""
        summary = data['summary']
        period = data['period']
        
        html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{report_type.capitalize()} Report - YouTube Shorts Analytics</title>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            background: #f5f5f5;
        }}
        .container {{
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }}
        header {{
            border-bottom: 3px solid #ff0000;
            padding-bottom: 20px;
            margin-bottom: 30px;
        }}
        h1 {{
            color: #ff0000;
            margin-bottom: 10px;
        }}
        .period {{
            color: #666;
            font-size: 14px;
        }}
        .metrics {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin: 30px 0;
        }}
        .metric {{
            background: #f9f9f9;
            padding: 20px;
            border-radius: 8px;
            border-left: 4px solid #ff0000;
        }}
        .metric-value {{
            font-size: 28px;
            font-weight: bold;
            color: #ff0000;
            margin: 10px 0;
        }}
        .metric-label {{
            color: #666;
            font-size: 14px;
        }}
        .section {{
            margin: 30px 0;
        }}
        .section h2 {{
            color: #333;
            border-bottom: 2px solid #ff0000;
            padding-bottom: 10px;
            margin-bottom: 20px;
        }}
        table {{
            width: 100%;
            border-collapse: collapse;
        }}
        th {{
            background: #f5f5f5;
            padding: 12px;
            text-align: left;
            border-bottom: 2px solid #ddd;
        }}
        td {{
            padding: 12px;
            border-bottom: 1px solid #ddd;
        }}
        tr:hover {{
            background: #f9f9f9;
        }}
        .footer {{
            margin-top: 40px;
            padding-top: 20px;
            border-top: 1px solid #ddd;
            color: #666;
            font-size: 12px;
        }}
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>📊 YouTube Shorts Analytics</h1>
            <p class="period">{report_type.upper()} REPORT | {period['start']} to {period['end']}</p>
        </header>
        
        <section class="metrics">
            <div class="metric">
                <div class="metric-label">Total Views</div>
                <div class="metric-value">{summary['total_views']:,}</div>
            </div>
            <div class="metric">
                <div class="metric-label">Videos Published</div>
                <div class="metric-value">{summary['total_videos']}</div>
            </div>
            <div class="metric">
                <div class="metric-label">Avg Views/Video</div>
                <div class="metric-value">{summary['avg_views_per_video']:,}</div>
            </div>
            <div class="metric">
                <div class="metric-label">Engagement Rate</div>
                <div class="metric-value">{summary['engagement_rate']}%</div>
            </div>
        </section>
        
        <section class="section">
            <h2>📹 Top Performing Videos</h2>
            <table>
                <thead>
                    <tr>
                        <th>Video Title</th>
                        <th>Views</th>
                        <th>Likes</th>
                        <th>Comments</th>
                    </tr>
                </thead>
                <tbody>
"""
        
        for video in data['top_videos']:
            html += f"""                    <tr>
                        <td>{video['title'][:50]}...</td>
                        <td>{video['view_count']:,}</td>
                        <td>{video['like_count']:,}</td>
                        <td>{video['comment_count']:,}</td>
                    </tr>
"""
        
        html += """                </tbody>
            </table>
        </section>
"""
        
        if data['variant_performance']:
            html += """        <section class="section">
            <h2>🎨 Thumbnail Variant Performance</h2>
            <table>
                <thead>
                    <tr>
                        <th>Variant</th>
                        <th>Videos</th>
                        <th>Total Views</th>
                        <th>Avg Views</th>
                    </tr>
                </thead>
                <tbody>
"""
            
            for variant, perf in sorted(data['variant_performance'].items()):
                html += f"""                    <tr>
                        <td><strong>{variant}</strong></td>
                        <td>{perf['count']}</td>
                        <td>{perf['total_views']:,}</td>
                        <td>{perf['avg_views']:,.0f}</td>
                    </tr>
"""
            
            html += """                </tbody>
            </table>
        </section>
"""
        
        html += f"""        <footer class="footer">
            <p>Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
            <p>YouTube Shorts Analytics System - Phase 2</p>
        </footer>
    </div>
</body>
</html>
"""
        return html
    
    def _render_text_template(self, data: Dict, report_type: str) -> str:
        """Render text template."""
        summary = data['summary']
        period = data['period']
        
        text = f"""
{'='*70}
YouTube Shorts Analytics - {report_type.upper()} Report
{'='*70}

Period: {period['start']} to {period['end']}
Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

SUMMARY METRICS
{'-'*70}
Total Views:              {summary['total_views']:>12,}
Videos Published:         {summary['total_videos']:>12}
Average Views per Video:  {summary['avg_views_per_video']:>12,}
Total Likes:              {summary['total_likes']:>12,}
Total Comments:           {summary['total_comments']:>12,}
Engagement Rate:          {summary['engagement_rate']:>12.2f}%

TOP PERFORMING VIDEOS
{'-'*70}
"""
        
        for i, video in enumerate(data['top_videos'], 1):
            text += f"""
#{i}: {video['title'][:60]}
     Views: {video['view_count']:,} | Likes: {video['like_count']:,} | Comments: {video['comment_count']:,}
"""
        
        if data['variant_performance']:
            text += f"""
THUMBNAIL VARIANT PERFORMANCE
{'-'*70}
"""
            for variant, perf in sorted(data['variant_performance'].items()):
                text += f"""
{variant}: {perf['count']} videos, {perf['total_views']:,} total views, {perf['avg_views']:,.0f} avg
"""
        
        text += f"""
{'='*70}
End of Report
{'='*70}
"""
        return text


def setup_logging():
    """Configure logging."""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )


if __name__ == '__main__':
    setup_logging()
    
    # Example usage
    reporter = ReportGenerator()
    
    # Generate reports
    weekly = reporter.generate_weekly_report()
    monthly = reporter.generate_monthly_report()
    
    print("✓ Reports generated")
    if weekly:
        print(f"  Weekly: {weekly}")
    if monthly:
        print(f"  Monthly: {monthly}")
