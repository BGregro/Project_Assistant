"""Report generation module."""

from .report import ReportGenerator

__all__ = ['ReportGenerator']
