"""
Machine Learning Recommendation Engine

Trains models on thumbnail performance data and generates recommendations.
Predicts which design variants will perform best.
"""

import json
import logging
import pickle
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import r2_score, mean_absolute_error


logger = logging.getLogger(__name__)


class RecommendationEngine:
    """ML-based recommendation engine for thumbnail optimization."""
    
    def __init__(self, data_dir: str = 'data'):
        """
        Initialize recommendation engine.
        
        Args:
            data_dir: Directory containing analytics data
        """
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(exist_ok=True)
        
        self.model = None
        self.scaler = None
        self.feature_names = None
        self.training_data = None
        self.feature_importance = None
    
    def load_training_data(self) -> Optional[pd.DataFrame]:
        """Load and prepare training data from analytics."""
        try:
            # Load videos with analytics
            videos_file = self.data_dir / 'videos.json'
            
            if not videos_file.exists():
                logger.error("❌ Video data file not found")
                return None
            
            with open(videos_file, 'r') as f:
                videos = json.load(f)
            
            df = pd.DataFrame(videos)
            
            # Ensure we have required columns
            required_cols = ['view_count', 'like_count', 'comment_count', 'thumbnail_variant']
            for col in required_cols:
                if col not in df.columns:
                    logger.warning(f"⚠ Missing column: {col}")
            
            # Handle missing values
            df = df.fillna(0)
            
            # Calculate engagement rate
            df['engagement_rate'] = (
                (df['like_count'] + df['comment_count']) /
                df['view_count'].replace(0, 1)
            ) * 100
            
            self.training_data = df
            logger.info(f"✓ Loaded {len(df)} videos for training")
            return df
        
        except Exception as e:
            logger.error(f"❌ Error loading training data: {e}")
            return None
    
    def prepare_features(self, df: Optional[pd.DataFrame] = None) -> Tuple[np.ndarray, np.ndarray]:
        """
        Prepare features for ML model.
        
        Args:
            df: DataFrame with video data
        
        Returns:
            Tuple of (features, target)
        """
        if df is None:
            df = self.load_training_data()
        
        if df is None or df.empty:
            logger.error("❌ No data to prepare")
            return None, None
        
        try:
            # Create feature matrix
            features_list = []
            
            # Extract thumbnail variant as numeric
            variant_mapping = {'v1': 1, 'v2': 2, 'v3': 3, 'v4': 4, 'v5': 5}
            variant_numeric = df['thumbnail_variant'].map(variant_mapping).fillna(3)
            features_list.append(('variant', variant_numeric))
            
            # Time-based features
            if 'published_at' in df.columns:
                df['published_at'] = pd.to_datetime(df['published_at'])
                df['day_of_week'] = df['published_at'].dt.dayofweek
                df['hour'] = df['published_at'].dt.hour
                features_list.append(('day_of_week', df['day_of_week']))
                features_list.append(('hour', df['hour']))
            
            # Title features
            if 'title' in df.columns:
                df['title_length'] = df['title'].str.len().fillna(0)
                df['has_number'] = df['title'].str.contains(r'\d', na=False).astype(int)
                df['has_caps'] = df['title'].str.contains(r'[A-Z]{2,}', na=False).astype(int)
                features_list.append(('title_length', df['title_length']))
                features_list.append(('has_number', df['has_number']))
                features_list.append(('has_caps', df['has_caps']))
            
            # Engagement features
            features_list.append(('like_count', df['like_count']))
            features_list.append(('comment_count', df['comment_count']))
            
            # Build feature matrix
            feature_names = [name for name, _ in features_list]
            X = np.column_stack([vals.values if hasattr(vals, 'values') else vals 
                                for _, vals in features_list])
            
            # Target: views
            y = df['view_count'].values
            
            self.feature_names = feature_names
            logger.info(f"✓ Prepared {X.shape[1]} features from {len(df)} samples")
            return X, y
        
        except Exception as e:
            logger.error(f"❌ Error preparing features: {e}")
            return None, None
    
    def train_performance_model(self) -> Optional[Dict]:
        """
        Train Random Forest model on thumbnail performance data.
        
        Returns:
            Dictionary with model metrics
        """
        X, y = self.prepare_features()
        
        if X is None or len(X) < 5:
            logger.error("❌ Insufficient training data (need at least 5 samples)")
            return None
        
        try:
            # Split data
            n_train = int(len(X) * 0.8)
            X_train, X_test = X[:n_train], X[n_train:]
            y_train, y_test = y[:n_train], y[n_train:]
            
            # Scale features
            self.scaler = StandardScaler()
            X_train_scaled = self.scaler.fit_transform(X_train)
            X_test_scaled = self.scaler.transform(X_test)
            
            # Train model
            self.model = RandomForestRegressor(
                n_estimators=50,
                max_depth=10,
                min_samples_split=3,
                random_state=42
            )
            self.model.fit(X_train_scaled, y_train)
            
            # Evaluate
            train_r2 = self.model.score(X_train_scaled, y_train)
            test_r2 = self.model.score(X_test_scaled, y_test)
            mae = mean_absolute_error(y_test, self.model.predict(X_test_scaled))
            
            # Feature importance
            self.feature_importance = {
                name: float(imp) 
                for name, imp in zip(self.feature_names, self.model.feature_importances_)
            }
            
            metrics = {
                'train_r2': float(train_r2),
                'test_r2': float(test_r2),
                'mae': float(mae),
                'samples': len(X),
                'features': len(self.feature_names),
                'feature_importance': self.feature_importance,
            }
            
            logger.info(f"✓ Model trained (R²: {test_r2:.3f}, MAE: {mae:.0f} views)")
            return metrics
        
        except Exception as e:
            logger.error(f"❌ Error training model: {e}")
            return None
    
    def predict_performance(self,
                          variant: str = 'v1',
                          title_length: int = 50,
                          has_number: bool = True,
                          has_caps: bool = True,
                          day_of_week: int = 3,
                          hour: int = 12) -> Optional[Dict]:
        """
        Predict view count for a new design.
        
        Args:
            variant: Thumbnail variant (v1-v5)
            title_length: Length of video title
            has_number: Whether title contains numbers
            has_caps: Whether title has all caps
            day_of_week: Day of week (0-6)
            hour: Upload hour (0-23)
        
        Returns:
            Dictionary with prediction and confidence
        """
        if self.model is None or self.scaler is None:
            self.train_performance_model()
        
        if self.model is None:
            logger.error("❌ Model not trained")
            return None
        
        try:
            # Map variant to number
            variant_map = {'v1': 1, 'v2': 2, 'v3': 3, 'v4': 4, 'v5': 5}
            variant_num = variant_map.get(variant, 3)
            
            # Create feature vector
            features = np.array([[
                variant_num,
                day_of_week,
                hour,
                title_length,
                int(has_number),
                int(has_caps),
                0,  # like_count (unknown)
                0,  # comment_count (unknown)
            ]])
            
            # Scale and predict
            features_scaled = self.scaler.transform(features)
            prediction = self.model.predict(features_scaled)[0]
            
            # Get prediction confidence from trees
            predictions = [tree.predict(features_scaled)[0] for tree in self.model.estimators_]
            std = np.std(predictions)
            confidence = max(0, 1 - (std / max(prediction, 1)))
            
            return {
                'variant': variant,
                'predicted_views': max(0, int(prediction)),
                'confidence': float(confidence),
                'std_dev': float(std),
            }
        
        except Exception as e:
            logger.error(f"❌ Error making prediction: {e}")
            return None
    
    def generate_recommendations(self,
                               correlation_data: Optional[Dict] = None,
                               confidence_threshold: float = 0.6) -> Dict:
        """
        Generate actionable recommendations based on analysis.
        
        Args:
            correlation_data: Pre-computed correlation analysis
            confidence_threshold: Minimum confidence for recommendations
        
        Returns:
            Dictionary with recommendations and actions
        """
        try:
            # Train model first
            metrics = self.train_performance_model()
            
            recommendations = {
                'timestamp': datetime.now().isoformat(),
                'model_metrics': metrics,
                'variant_recommendations': [],
                'testing_strategy': [],
                'optimization_tips': [],
            }
            
            if not metrics or metrics['test_r2'] < 0.3:
                logger.warning("⚠ Model accuracy is low, recommendations may be unreliable")
                recommendations['note'] = 'Model needs more training data for reliable recommendations'
                return recommendations
            
            # Get predictions for each variant
            variants = ['v1', 'v2', 'v3', 'v4', 'v5']
            predictions = {}
            
            for variant in variants:
                pred = self.predict_performance(variant=variant)
                if pred:
                    predictions[variant] = pred
            
            # Rank variants
            ranked = sorted(
                predictions.items(),
                key=lambda x: x[1]['predicted_views'],
                reverse=True
            )
            
            # Create recommendations
            for i, (variant, pred) in enumerate(ranked):
                if pred['confidence'] < confidence_threshold:
                    continue
                
                if i == 0:
                    action = 'INCREASE_USAGE'
                    priority = 'HIGH'
                elif i <= 2:
                    action = 'MAINTAIN'
                    priority = 'MEDIUM'
                else:
                    action = 'OPTIMIZE'
                    priority = 'MEDIUM'
                
                recommendation = {
                    'rank': i + 1,
                    'variant': variant,
                    'action': action,
                    'priority': priority,
                    'predicted_views': pred['predicted_views'],
                    'confidence': pred['confidence'],
                    'reasoning': self._generate_reasoning(variant, i, ranked)
                }
                
                recommendations['variant_recommendations'].append(recommendation)
            
            # Testing strategy
            if len(ranked) > 1:
                best = ranked[0][0]
                second_best = ranked[1][0]
                
                recommendations['testing_strategy'].append({
                    'test': 'A/B Test',
                    'variant_a': best,
                    'variant_b': second_best,
                    'expected_lift': f"+{(ranked[0][1]['predicted_views'] / ranked[1][1]['predicted_views'] - 1) * 100:.1f}%"
                })
            
            # Optimization tips
            if self.feature_importance:
                top_features = sorted(
                    self.feature_importance.items(),
                    key=lambda x: x[1],
                    reverse=True
                )[:3]
                
                for feature, importance in top_features:
                    recommendations['optimization_tips'].append({
                        'factor': feature,
                        'importance': float(importance),
                        'tip': self._get_optimization_tip(feature)
                    })
            
            logger.info(f"✓ Generated {len(recommendations['variant_recommendations'])} recommendations")
            return recommendations
        
        except Exception as e:
            logger.error(f"❌ Error generating recommendations: {e}")
            return {}
    
    def _generate_reasoning(self, variant: str, rank: int, all_predictions: List) -> str:
        """Generate human-readable reasoning for a recommendation."""
        if rank == 0:
            return f"{variant} shows strongest predicted performance among tested variants"
        elif rank == 1:
            return f"{variant} performs well but slightly behind top choice"
        else:
            return f"{variant} needs optimization - consider design changes or increased visibility"
    
    def _get_optimization_tip(self, feature: str) -> str:
        """Get actionable optimization tip for a feature."""
        tips = {
            'variant': 'Test different thumbnail designs - variant choice significantly impacts views',
            'title_length': 'Optimize title length - medium-length titles tend to perform better',
            'has_number': 'Include numbers in titles - they attract more clicks and views',
            'has_caps': 'Use uppercase strategically - it draws attention but overuse decreases engagement',
            'day_of_week': 'Consider posting schedule - some days have higher viewership',
            'hour': 'Upload timing matters - test different hours to find your audience peak',
            'like_count': 'Encourage likes - they signal video quality to YouTube algorithm',
            'comment_count': 'Increase engagement - comments boost video reach',
        }
        return tips.get(feature, f"Optimize {feature} for better performance")
    
    def get_next_variant_to_test(self) -> Optional[Dict]:
        """Determine which variant should be tested next."""
        recommendations = self.generate_recommendations()
        
        if not recommendations['variant_recommendations']:
            return None
        
        # Find variant with OPTIMIZE action
        optimize = [r for r in recommendations['variant_recommendations'] 
                   if r['action'] == 'OPTIMIZE']
        
        if optimize:
            return {
                'variant': optimize[0]['variant'],
                'reason': optimize[0]['reasoning'],
                'suggested_changes': [
                    'Increase contrast',
                    'Simplify design',
                    'Add more emotional appeal',
                    'Test with different colors'
                ]
            }
        
        return None
    
    def save_model(self, model_dir: str = 'models'):
        """Save trained model and scaler."""
        try:
            model_path = Path(model_dir)
            model_path.mkdir(exist_ok=True)
            
            if self.model:
                pickle.dump(self.model, open(model_path / 'model.pkl', 'wb'))
            
            if self.scaler:
                pickle.dump(self.scaler, open(model_path / 'scaler.pkl', 'wb'))
            
            if self.feature_names:
                with open(model_path / 'features.json', 'w') as f:
                    json.dump(self.feature_names, f)
            
            logger.info(f"✓ Model saved to {model_dir}/")
        
        except Exception as e:
            logger.error(f"❌ Error saving model: {e}")
    
    def load_model(self, model_dir: str = 'models') -> bool:
        """Load trained model and scaler."""
        try:
            model_path = Path(model_dir)
            
            if (model_path / 'model.pkl').exists():
                self.model = pickle.load(open(model_path / 'model.pkl', 'rb'))
            
            if (model_path / 'scaler.pkl').exists():
                self.scaler = pickle.load(open(model_path / 'scaler.pkl', 'rb'))
            
            if (model_path / 'features.json').exists():
                with open(model_path / 'features.json', 'r') as f:
                    self.feature_names = json.load(f)
            
            logger.info("✓ Model loaded successfully")
            return True
        
        except Exception as e:
            logger.warning(f"⚠ Could not load model: {e}")
            return False


def setup_logging():
    """Configure logging."""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )


if __name__ == '__main__':
    setup_logging()
    
    # Example usage
    engine = RecommendationEngine()
    
    # Generate recommendations
    recs = engine.generate_recommendations()
    
    print("\n🤖 ML RECOMMENDATIONS")
    print("=" * 60)
    print(f"Model R²: {recs['model_metrics']['test_r2']:.3f}")
    print(f"Features: {recs['model_metrics']['features']}")
    print()
    
    print("Variant Rankings:")
    for rec in recs['variant_recommendations']:
        print(f"  #{rec['rank']} {rec['variant']}: {rec['predicted_views']} views (confidence: {rec['confidence']:.1%})")
