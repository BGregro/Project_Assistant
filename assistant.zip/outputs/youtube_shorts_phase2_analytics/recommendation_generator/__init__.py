"""Recommendation generation module."""

from .recommendations import RecommendationEngine

__all__ = ['RecommendationEngine']
