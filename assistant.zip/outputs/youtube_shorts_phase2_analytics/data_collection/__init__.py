"""Data collection module for YouTube Analytics."""

from .data_collector import YouTubeAnalyticsCollector

__all__ = ['YouTubeAnalyticsCollector']
