"""
YouTube Analytics Data Collector

Fetches video statistics and analytics from YouTube APIs.
Handles authentication, data retrieval, and caching.
"""

import json
import os
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional, Any
import logging

from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
import pandas as pd


logger = logging.getLogger(__name__)


class YouTubeAnalyticsCollector:
    """Collects analytics data from YouTube APIs."""
    
    def __init__(self, credentials_path: str = 'config/credentials.json'):
        """
        Initialize the collector with credentials.
        
        Args:
            credentials_path: Path to OAuth 2.0 credentials JSON
        """
        self.credentials_path = credentials_path
        self.creds = None
        self.youtube = None
        self.analytics = None
        self.channel_id = None
        self.data_dir = Path('data')
        self.data_dir.mkdir(exist_ok=True)
        
        # Load credentials
        self._load_credentials()
        
        # Initialize API clients
        if self.creds:
            self.youtube = build('youtube', 'v3', credentials=self.creds)
            self.analytics = build('youtubeAnalytics', 'v2', credentials=self.creds)
            self._get_channel_id()
    
    def _load_credentials(self):
        """Load OAuth credentials from file."""
        try:
            if not os.path.exists(self.credentials_path):
                raise FileNotFoundError(f"Credentials file not found: {self.credentials_path}")
            
            with open(self.credentials_path, 'r') as f:
                creds_data = json.load(f)
            
            # Extract credentials from OAuth file
            if 'installed' in creds_data:
                oauth_config = creds_data['installed']
            elif 'web' in creds_data:
                oauth_config = creds_data['web']
            else:
                raise ValueError("Invalid credentials file format")
            
            # For simplicity in Phase 2, we'll use the credentials as-is
            # In production, you'd implement full OAuth token management
            self.creds_data = oauth_config
            
            logger.info("✓ Credentials loaded successfully")
        
        except FileNotFoundError as e:
            logger.error(f"❌ {e}")
            logger.info("Run 'python setup_auth.py' to set up authentication")
            self.creds = None
        except Exception as e:
            logger.error(f"❌ Error loading credentials: {e}")
            self.creds = None
    
    def _get_channel_id(self):
        """Get authenticated user's channel ID."""
        try:
            request = self.youtube.channels().list(
                part='id,snippet',
                mine=True
            )
            response = request.execute()
            
            if response['items']:
                self.channel_id = response['items'][0]['id']
                channel_name = response['items'][0]['snippet']['title']
                logger.info(f"✓ Channel: {channel_name} ({self.channel_id})")
            else:
                logger.error("❌ No channel found for authenticated user")
        
        except Exception as e:
            logger.error(f"❌ Error getting channel ID: {e}")
    
    def get_videos(self, 
                  min_results: int = 50,
                  order: str = 'date',
                  video_type: str = 'shorts') -> List[Dict]:
        """
        Get list of videos from channel.
        
        Args:
            min_results: Minimum number of results
            order: Sort order ('date', 'title', 'viewCount')
            video_type: 'shorts' or 'all'
        
        Returns:
            List of video dictionaries with id, title, etc.
        """
        if not self.youtube or not self.channel_id:
            logger.error("❌ YouTube API not initialized")
            return []
        
        try:
            videos = []
            next_page_token = None
            
            while len(videos) < min_results:
                request = self.youtube.search().list(
                    channelId=self.channel_id,
                    part='id,snippet',
                    type='video',
                    order=order,
                    maxResults=50,
                    pageToken=next_page_token
                )
                
                response = request.execute()
                
                for item in response.get('items', []):
                    if video_type == 'shorts':
                        # Filter for Shorts (videos < 60 seconds)
                        video_id = item['id']['videoId']
                        videos.append({
                            'id': video_id,
                            'title': item['snippet']['title'],
                            'published_at': item['snippet']['publishedAt'],
                            'thumbnail': item['snippet']['thumbnails']['medium']['url']
                        })
                    else:
                        video_id = item['id']['videoId']
                        videos.append({
                            'id': video_id,
                            'title': item['snippet']['title'],
                            'published_at': item['snippet']['publishedAt'],
                            'thumbnail': item['snippet']['thumbnails']['medium']['url']
                        })
                
                next_page_token = response.get('nextPageToken')
                
                if not next_page_token:
                    break
            
            logger.info(f"✓ Retrieved {len(videos)} videos")
            return videos[:min_results]
        
        except Exception as e:
            logger.error(f"❌ Error getting videos: {e}")
            return []
    
    def get_video_statistics(self, video_id: str) -> Optional[Dict]:
        """
        Get detailed statistics for a single video.
        
        Args:
            video_id: YouTube video ID
        
        Returns:
            Dictionary with views, likes, comments, etc.
        """
        if not self.youtube:
            logger.error("❌ YouTube API not initialized")
            return None
        
        try:
            request = self.youtube.videos().list(
                part='statistics,snippet,contentDetails',
                id=video_id
            )
            response = request.execute()
            
            if not response['items']:
                return None
            
            item = response['items'][0]
            stats = item['statistics']
            snippet = item['snippet']
            
            return {
                'id': video_id,
                'title': snippet['title'],
                'published_at': snippet['publishedAt'],
                'view_count': int(stats.get('viewCount', 0)),
                'like_count': int(stats.get('likeCount', 0)),
                'comment_count': int(stats.get('commentCount', 0)),
                'duration': item['contentDetails']['duration'],
            }
        
        except Exception as e:
            logger.error(f"❌ Error getting video statistics for {video_id}: {e}")
            return None
    
    def get_analytics_metrics(self,
                            start_date: str,
                            end_date: str,
                            metrics: str = 'views,estimatedMinutesWatched,averageViewDuration,subscribersGained') -> Optional[pd.DataFrame]:
        """
        Get analytics metrics for date range.
        
        Args:
            start_date: Start date (YYYY-MM-DD)
            end_date: End date (YYYY-MM-DD)
            metrics: Comma-separated metrics to retrieve
        
        Returns:
            DataFrame with metrics indexed by date
        """
        if not self.analytics or not self.channel_id:
            logger.error("❌ Analytics API not initialized")
            return None
        
        try:
            request = self.analytics.reports().query(
                ids=f'channel=={self.channel_id}',
                startDate=start_date,
                endDate=end_date,
                metrics=metrics,
                dimensions='day'
            )
            
            response = request.execute()
            
            if not response.get('rows'):
                logger.warning(f"⚠ No analytics data for {start_date} to {end_date}")
                return pd.DataFrame()
            
            # Convert to DataFrame
            headers = [h['name'] for h in response['columnHeaders']]
            data = response['rows']
            
            df = pd.DataFrame(data, columns=headers)
            df['day'] = pd.to_datetime(df['day'])
            df = df.set_index('day')
            
            # Convert numeric columns
            for col in df.columns:
                try:
                    df[col] = pd.to_numeric(df[col])
                except:
                    pass
            
            logger.info(f"✓ Retrieved analytics for {len(df)} days")
            return df
        
        except Exception as e:
            logger.error(f"❌ Error getting analytics metrics: {e}")
            return None
    
    def get_shorts_performance(self,
                              days: int = 30) -> Optional[pd.DataFrame]:
        """
        Get performance metrics for Shorts from last N days.
        
        Args:
            days: Number of days to look back
        
        Returns:
            DataFrame with video performance metrics
        """
        end_date = datetime.now().date()
        start_date = end_date - timedelta(days=days)
        
        # Get analytics metrics
        analytics = self.get_analytics_metrics(
            start_date=start_date.isoformat(),
            end_date=end_date.isoformat(),
            metrics='views,estimatedMinutesWatched,averageViewDuration,subscribersGained,likes'
        )
        
        if analytics is None or analytics.empty:
            return None
        
        # Get videos from last N days
        videos = self.get_videos(min_results=100)
        
        # Filter videos within date range
        video_data = []
        for video in videos:
            pub_date = pd.to_datetime(video['published_at']).date()
            if start_date <= pub_date <= end_date:
                stats = self.get_video_statistics(video['id'])
                if stats:
                    video_data.append(stats)
        
        # Combine with analytics
        if video_data:
            df = pd.DataFrame(video_data)
            df['published_at'] = pd.to_datetime(df['published_at']).dt.date
            logger.info(f"✓ Retrieved {len(df)} Shorts performance metrics")
            return df
        
        return None
    
    def cache_data(self, data: Any, filename: str):
        """Cache data to JSON file."""
        try:
            filepath = self.data_dir / filename
            
            if isinstance(data, pd.DataFrame):
                data.to_json(filepath)
            else:
                with open(filepath, 'w') as f:
                    json.dump(data, f, indent=2, default=str)
            
            logger.info(f"✓ Data cached to {filename}")
        except Exception as e:
            logger.error(f"❌ Error caching data: {e}")
    
    def load_cache(self, filename: str, as_dataframe: bool = False) -> Optional[Any]:
        """Load cached data from JSON file."""
        try:
            filepath = self.data_dir / filename
            
            if not filepath.exists():
                return None
            
            if as_dataframe:
                return pd.read_json(filepath)
            else:
                with open(filepath, 'r') as f:
                    return json.load(f)
        
        except Exception as e:
            logger.error(f"❌ Error loading cache: {e}")
            return None


def setup_logging():
    """Configure logging."""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler('data_collector.log'),
            logging.StreamHandler()
        ]
    )


if __name__ == '__main__':
    setup_logging()
    
    # Example usage
    collector = YouTubeAnalyticsCollector()
    
    if collector.youtube and collector.analytics:
        # Get recent videos
        videos = collector.get_videos(min_results=10)
        for v in videos[:3]:
            print(f"Video: {v['title']} ({v['id']})")
        
        # Get analytics for last 30 days
        end_date = datetime.now().date()
        start_date = end_date - timedelta(days=30)
        
        analytics = collector.get_analytics_metrics(
            start_date=start_date.isoformat(),
            end_date=end_date.isoformat()
        )
        
        if analytics is not None:
            print(f"\nAnalytics ({len(analytics)} days):")
            print(analytics.head())
