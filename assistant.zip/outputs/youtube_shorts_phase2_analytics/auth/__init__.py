"""Authentication module for YouTube API."""

from .authenticator import YouTubeAuthenticator

__all__ = ['YouTubeAuthenticator']
