"""
YouTube API Authentication Module

Handles OAuth 2.0 authentication for YouTube Data API v3.
Supports both user authentication and service account authentication.
"""

import os
import pickle
from pathlib import Path
from typing import Optional, Dict, Any
import json

from google.auth.transport.requests import Request
from google.oauth2.service_account import Credentials as ServiceAccountCredentials
from google.oauth2.credentials import Credentials as UserCredentials
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth import default


class YouTubeAuthenticator:
    """
    Manages YouTube API authentication and credential storage.
    
    Supports two authentication methods:
    1. OAuth 2.0 (User credentials - requires manual login)
    2. Service Account (Automated access using JSON key)
    
    Attributes:
        auth_cache_dir: Directory to store cached credentials
        credentials_file: Path to OAuth credentials JSON
        service_account_file: Path to service account JSON key
    """
    
    # Required OAuth scopes for YouTube Analytics
    SCOPES = [
        'https://www.googleapis.com/auth/youtube.readonly',
        'https://www.googleapis.com/auth/youtube.analytics.readonly',
        'https://www.googleapis.com/auth/yt-analytics.readonly',
    ]
    
    def __init__(
        self,
        auth_cache_dir: str = ".cache",
        credentials_file: Optional[str] = None,
        service_account_file: Optional[str] = None,
    ):
        """
        Initialize the authenticator.
        
        Args:
            auth_cache_dir: Directory for cached tokens (default: .cache)
            credentials_file: Path to OAuth credentials JSON from Google Cloud Console
            service_account_file: Path to service account JSON key
        """
        self.auth_cache_dir = Path(auth_cache_dir)
        self.auth_cache_dir.mkdir(parents=True, exist_ok=True)
        
        self.credentials_file = credentials_file or os.getenv('YOUTUBE_CREDENTIALS_FILE')
        self.service_account_file = service_account_file or os.getenv('YOUTUBE_SERVICE_ACCOUNT_FILE')
        
        self.token_cache = self.auth_cache_dir / "youtube_token.pickle"
        self.credentials = None
    
    def get_credentials(self, use_service_account: bool = False) -> UserCredentials:
        """
        Get valid credentials for YouTube API.
        
        Priority:
        1. Cached credentials (if valid)
        2. Service account (if use_service_account=True and file exists)
        3. OAuth flow (user login)
        
        Args:
            use_service_account: Use service account credentials if available
            
        Returns:
            Valid credentials object for API requests
            
        Raises:
            FileNotFoundError: If no credentials file is found
            ValueError: If credentials are invalid or incomplete
        """
        # Try loading cached credentials first
        if self.token_cache.exists():
            try:
                with open(self.token_cache, 'rb') as token_file:
                    self.credentials = pickle.load(token_file)
                
                # Check if credentials are still valid
                if self.credentials.valid:
                    return self.credentials
                
                # Refresh if expired but valid token available
                if self.credentials.expired and self.credentials.refresh_token:
                    self.credentials.refresh(Request())
                    self._save_credentials()
                    return self.credentials
            except Exception as e:
                print(f"Warning: Could not load cached credentials: {e}")
        
        # Try service account if requested
        if use_service_account and self.service_account_file:
            return self._get_service_account_credentials()
        
        # Fall back to OAuth flow
        return self._get_oauth_credentials()
    
    def _get_service_account_credentials(self) -> ServiceAccountCredentials:
        """
        Get credentials from service account JSON key file.
        
        Service accounts are useful for automated, long-running processes.
        
        Returns:
            Service account credentials
            
        Raises:
            FileNotFoundError: If service account file doesn't exist
            ValueError: If JSON is invalid
        """
        if not self.service_account_file or not Path(self.service_account_file).exists():
            raise FileNotFoundError(
                f"Service account file not found: {self.service_account_file}\n"
                "Create one at: https://console.cloud.google.com/iam-admin/serviceaccounts"
            )
        
        try:
            self.credentials = ServiceAccountCredentials.from_service_account_file(
                self.service_account_file,
                scopes=self.SCOPES
            )
            print(f"✓ Authenticated using service account: {self.service_account_file}")
            return self.credentials
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON in service account file: {e}")
        except Exception as e:
            raise ValueError(f"Failed to load service account: {e}")
    
    def _get_oauth_credentials(self) -> UserCredentials:
        """
        Get credentials using OAuth 2.0 flow (user login).
        
        First time: Opens browser for Google login
        Subsequent times: Uses cached token
        
        Returns:
            User credentials
            
        Raises:
            FileNotFoundError: If credentials.json not found
        """
        if not self.credentials_file or not Path(self.credentials_file).exists():
            raise FileNotFoundError(
                f"OAuth credentials file not found: {self.credentials_file}\n"
                "Create one at: https://console.cloud.google.com/apis/credentials\n"
                "1. Create OAuth 2.0 Client ID (Desktop Application)\n"
                "2. Download JSON and save as 'credentials.json'"
            )
        
        try:
            flow = InstalledAppFlow.from_client_secrets_file(
                self.credentials_file,
                self.SCOPES
            )
            self.credentials = flow.run_local_server(port=0)
            
            # Cache the credentials
            self._save_credentials()
            print("✓ OAuth authentication successful. Token cached for future use.")
            
            return self.credentials
        except Exception as e:
            raise ValueError(f"OAuth flow failed: {e}")
    
    def _save_credentials(self) -> None:
        """Save credentials to cache for future use."""
        try:
            with open(self.token_cache, 'wb') as token_file:
                pickle.dump(self.credentials, token_file)
        except Exception as e:
            print(f"Warning: Could not cache credentials: {e}")
    
    def refresh_credentials(self) -> bool:
        """
        Manually refresh current credentials.
        
        Returns:
            True if refresh successful, False otherwise
        """
        if not self.credentials:
            return False
        
        try:
            if self.credentials.expired and self.credentials.refresh_token:
                self.credentials.refresh(Request())
                self._save_credentials()
                return True
            return True
        except Exception as e:
            print(f"Error refreshing credentials: {e}")
            return False
    
    def clear_cache(self) -> None:
        """Clear cached credentials."""
        if self.token_cache.exists():
            self.token_cache.unlink()
            print(f"✓ Cleared credential cache: {self.token_cache}")
    
    def validate_credentials(self) -> Dict[str, Any]:
        """
        Validate current credentials and return info.
        
        Returns:
            Dictionary with credential status and details
        """
        if not self.credentials:
            return {
                'valid': False,
                'error': 'No credentials loaded',
            }
        
        try:
            return {
                'valid': True,
                'token_type': type(self.credentials).__name__,
                'expired': self.credentials.expired if hasattr(self.credentials, 'expired') else None,
                'scopes': self.credentials.scopes if hasattr(self.credentials, 'scopes') else None,
            }
        except Exception as e:
            return {
                'valid': False,
                'error': str(e),
            }


class YouTubeAPIClient:
    """
    Wrapper for YouTube API client initialization.
    
    Provides easy setup of YouTube API service with authentication.
    """
    
    def __init__(self, authenticator: YouTubeAuthenticator):
        """
        Initialize API client with authenticator.
        
        Args:
            authenticator: YouTubeAuthenticator instance
        """
        self.authenticator = authenticator
        self.service = None
    
    def initialize(self, use_service_account: bool = False):
        """
        Initialize YouTube API service.
        
        Args:
            use_service_account: Use service account if available
            
        Returns:
            Initialized YouTube API service
        """
        from googleapiclient.discovery import build
        
        credentials = self.authenticator.get_credentials(use_service_account)
        self.service = build('youtube', 'v3', credentials=credentials)
        
        return self.service
    
    def get_service(self):
        """Get initialized YouTube API service."""
        if self.service is None:
            raise RuntimeError("Service not initialized. Call initialize() first.")
        return self.service


# Convenience function for quick authentication
def authenticate_youtube(
    credentials_file: Optional[str] = None,
    service_account_file: Optional[str] = None,
    use_service_account: bool = False,
) -> 'YouTubeAPIClient':
    """
    Quick authentication to YouTube API.
    
    Args:
        credentials_file: Path to OAuth credentials JSON
        service_account_file: Path to service account JSON key
        use_service_account: Prefer service account over OAuth
        
    Returns:
        Initialized YouTube API client
        
    Example:
        >>> client = authenticate_youtube('credentials.json')
        >>> service = client.get_service()
        >>> channels = service.channels().list(part='snippet', mine=True).execute()
    """
    auth = YouTubeAuthenticator(
        credentials_file=credentials_file,
        service_account_file=service_account_file,
    )
    
    client = YouTubeAPIClient(auth)
    client.initialize(use_service_account=use_service_account)
    
    return client
