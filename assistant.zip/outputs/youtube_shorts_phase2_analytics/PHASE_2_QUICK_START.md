# 🚀 Phase 2 - Quick Start Guide

## ⚡ 5-Minute Setup

### Step 1: Initial Authorization (One-time, 2 minutes)
```bash
cd outputs/youtube_shorts_phase2_analytics
python setup_auth.py
```
- Browser opens automatically
- Sign in with YouTube account
- Accept permissions
- Credentials saved securely
- ✅ Done!

### Step 2: First Data Collection (1 minute)
```bash
python main.py
```
**What happens:**
1. Authenticates with YouTube API
2. Fetches all your shorts (if any exist yet)
3. Creates initial data cache
4. Generates first report (if data available)

**Output:** `reports/weekly_YYYY-MM-DD.html`

---

## 📊 Understanding the Workflow

```
Your Phase 1 Shorts (with v1-v5 thumbnails)
            ↓
Phase 2 Tracks Daily Metrics (views, CTR, etc)
            ↓
Links Each Short to Its Thumbnail Variant
            ↓
Analyzes Which Variants Perform Best
            ↓
ML Model Trains on Patterns
            ↓
Generates Recommendations for Next Shorts
```

---

## 🎯 Daily Routine (After Setup)

Run once per day (morning or evening):
```bash
python main.py
```

Takes ~30-60 seconds. Automatically:
- ✅ Fetches latest metrics
- ✅ Updates analysis
- ✅ Regenerates report
- ✅ Stores data locally

---

## 📈 When to Expect Results

| Timeline | What Happens |
|----------|-------------|
| **Week 1** | Data collection starts, initial report generated |
| **Week 2** | Patterns begin to emerge, 5-10 data points per variant |
| **Week 3-4** | ML model trains, first recommendations ready |
| **Week 5+** | High-confidence recommendations, 30%+ CTR improvement expected |

---

## 🔍 Reading the Reports

### **HTML Report** (Most useful)
```
reports/weekly_2025-01-15.html
```
Open in browser. Contains:
- 📊 Interactive charts (Plotly)
- 📈 Performance trends
- 🏆 Top-performing thumbnails
- 💡 ML recommendations
- 📝 Week summary

### **PDF Report** (For archival)
```
reports/weekly_2025-01-15.pdf
```
Printable version of HTML report.

### **Text Report** (Quick summary)
```
reports/weekly_2025-01-15.txt
```
Plain text summary (best for email).

---

## 🤖 ML Recommendations

After 3-4 weeks of data:

```python
from recommendation_generator.recommendations import RecommendationEngine

engine = RecommendationEngine()
recs = engine.generate_recommendations()

# Output example:
# {
#   "best_variant": "v3",
#   "confidence": 0.89,
#   "expected_ctr_lift": "42%",
#   "reasoning": "v3 has 23% higher CTR in Python tutorial videos"
# }
```

---

## 📁 Project Structure

```
outputs/youtube_shorts_phase2_analytics/
├── auth/                    # YouTube API auth
│   ├── auth.py             # OAuth 2.0 handler
│   └── __init__.py
├── data_collection/         # Metrics fetching
│   ├── data_collector.py   # API calls
│   └── __init__.py
├── data_processing/         # Variant analysis
│   ├── thumbnail_processor.py  # Link metrics to variants
│   └── __init__.py
├── recommendation_generator/ # ML engine
│   ├── recommendations.py   # ML models
│   └── __init__.py
├── report_generator/        # Report builder
│   ├── report.py           # HTML/PDF/TXT generation
│   └── __init__.py
├── data/                    # 📁 Data cache (created at runtime)
│   ├── cache/              # Cached metrics
│   └── thumbnails/         # Variant tracking
├── reports/                 # 📁 Generated reports (created at runtime)
│   ├── weekly_2025-01-15.html
│   ├── weekly_2025-01-15.pdf
│   └── weekly_2025-01-15.txt
├── main.py                  # ⭐ MAIN ENTRY POINT - Run daily
├── setup_auth.py            # Setup script (run once)
├── requirements.txt         # Dependencies (already installed)
└── test_analytics.py        # Unit tests
```

---

## ⚙️ Configuration

Edit `main.py` to customize:

```python
# Report frequency
REPORT_FREQUENCY = "weekly"  # or "daily", "monthly"

# Data retention
DAYS_TO_KEEP = 90           # Keep last 90 days of data

# ML confidence threshold
MIN_CONFIDENCE = 0.75       # Only recommend if 75%+ confident
```

---

## 🐛 Troubleshooting

### **"API credentials not found"**
```bash
# Run setup again
python setup_auth.py
```

### **"No YouTube videos found"**
Phase 2 tracks videos you've already uploaded. It won't find anything until:
- Phase 1 creates shorts
- Phase 1 uploads them to YouTube
- You wait 1 day for metrics to populate

### **"Not enough data for ML"**
ML recommendations require 2+ weeks of data. Keep running `main.py` daily.

### **"Report generation failed"**
- Check internet connection
- Verify YouTube API is still authorized
- Run: `python setup_auth.py` again

---

## 📞 Quick Reference

| Task | Command |
|------|---------|
| Setup authorization | `python setup_auth.py` |
| Run daily pipeline | `python main.py` |
| Run tests | `pytest test_analytics.py -v` |
| View latest report | Open `reports/weekly_*.html` in browser |
| Check logs | Look in `logs/` directory |

---

## 🎓 What You're Learning

By using Phase 2, you're learning:
- ✅ YouTube API integration
- ✅ OAuth 2.0 authentication
- ✅ Pandas data manipulation
- ✅ Scikit-Learn ML models
- ✅ Report automation
- ✅ Data-driven decision making

---

## 🚀 Next: Phase 3 (Optional)

When you're ready, Phase 3 could add:
- 🔔 Automated email notifications with insights
- 📱 Discord/Telegram alerts on high-performance videos
- 🤖 Auto-posting recommendations to social media
- 💰 Revenue correlation analysis (if monetized)
- 🎨 Design system updates based on trending styles

---

**Status: READY TO USE** ✅  
**Next Step: Run `python setup_auth.py`**

