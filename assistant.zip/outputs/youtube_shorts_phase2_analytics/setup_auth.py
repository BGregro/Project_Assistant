"""
YouTube API Authentication Setup

Sets up OAuth 2.0 credentials for YouTube Data API and YouTube Analytics API.
Generates credentials.json file for use in the analytics system.
"""

import os
import json
import sys
from pathlib import Path
from google_auth_oauthlib.flow import InstalledAppFlow


SCOPES = [
    'https://www.googleapis.com/auth/youtube.analytics.readonly',
    'https://www.googleapis.com/auth/youtube.readonly',
]


def setup_oauth2():
    """
    Set up OAuth 2.0 authentication for YouTube APIs.
    
    This function will:
    1. Ask user for path to client secrets JSON
    2. Open browser for authentication
    3. Save credentials to config/credentials.json
    """
    
    print("=" * 60)
    print("YouTube API Authentication Setup")
    print("=" * 60)
    print()
    
    # Step 1: Get client secrets file
    print("Step 1: Locate your Google OAuth 2.0 credentials file")
    print("-" * 60)
    print()
    print("Instructions:")
    print("1. Go to: https://console.cloud.google.com/")
    print("2. Create a new project (or select existing)")
    print("3. Enable these APIs:")
    print("   • YouTube Data API v3")
    print("   • YouTube Analytics API")
    print("4. Go to 'Credentials' → 'Create Credentials' → OAuth 2.0 Client IDs")
    print("5. Select 'Desktop application'")
    print("6. Download JSON file")
    print()
    
    # Prompt for file location
    while True:
        client_secrets_path = input("Enter path to your OAuth 2.0 JSON file: ").strip()
        
        if not client_secrets_path:
            print("❌ Please provide a valid path")
            continue
        
        # Handle quotes and expand path
        client_secrets_path = client_secrets_path.strip('"\'')
        client_secrets_path = os.path.expanduser(client_secrets_path)
        
        if not os.path.exists(client_secrets_path):
            print(f"❌ File not found: {client_secrets_path}")
            continue
        
        if not client_secrets_path.endswith('.json'):
            print("❌ File must be a JSON file (.json)")
            continue
        
        # Verify it's a valid OAuth credentials file
        try:
            with open(client_secrets_path, 'r') as f:
                creds_data = json.load(f)
            
            if 'installed' not in creds_data and 'web' not in creds_data:
                print("❌ Invalid OAuth credentials file format")
                continue
            
            print(f"✓ File verified: {client_secrets_path}")
            break
        except json.JSONDecodeError:
            print("❌ File is not valid JSON")
            continue
        except Exception as e:
            print(f"❌ Error reading file: {e}")
            continue
    
    print()
    
    # Step 2: Create config directory
    config_dir = Path('config')
    config_dir.mkdir(exist_ok=True)
    
    # Step 3: Copy credentials file to config directory
    print("Step 2: Setting up OAuth 2.0 flow")
    print("-" * 60)
    print()
    
    try:
        # Initialize OAuth flow
        flow = InstalledAppFlow.from_client_secrets_file(
            client_secrets_path,
            SCOPES
        )
        
        # Run local server for OAuth callback
        print("Opening browser for authentication...")
        print("(If browser doesn't open, visit the URL shown)")
        print()
        
        creds = flow.run_local_server(port=0)
        
        print()
        print("✓ Authentication successful!")
        print()
        
        # Save credentials
        print("Step 3: Saving credentials")
        print("-" * 60)
        print()
        
        # Copy original file
        import shutil
        credentials_path = config_dir / 'credentials.json'
        shutil.copy(client_secrets_path, credentials_path)
        
        print(f"✓ Credentials saved to: {credentials_path}")
        print()
        
        # Save token info
        token_path = config_dir / 'token.json'
        token_data = {
            'token': creds.token,
            'refresh_token': creds.refresh_token,
            'token_uri': creds.token_uri,
            'client_id': creds.client_id,
            'client_secret': creds.client_secret,
        }
        
        with open(token_path, 'w') as f:
            json.dump(token_data, f, indent=2)
        
        print(f"✓ Access token saved to: {token_path}")
        print()
        
        # Verify setup
        print("Step 4: Verifying setup")
        print("-" * 60)
        print()
        
        # Try to access YouTube API
        from googleapiclient.discovery import build
        
        youtube = build('youtube', 'v3', credentials=creds)
        
        request = youtube.channels().list(
            part='id,snippet',
            mine=True
        )
        response = request.execute()
        
        if response['items']:
            channel_info = response['items'][0]
            channel_id = channel_info['id']
            channel_name = channel_info['snippet']['title']
            
            print(f"✓ Successfully connected to YouTube!")
            print(f"✓ Channel ID: {channel_id}")
            print(f"✓ Channel Name: {channel_name}")
            print()
        
        print("=" * 60)
        print("✅ SETUP COMPLETE")
        print("=" * 60)
        print()
        print("You can now run the analytics system:")
        print("  python main.py --action full --days 30")
        print()
        
        return True
    
    except Exception as e:
        print()
        print("=" * 60)
        print("❌ SETUP FAILED")
        print("=" * 60)
        print(f"Error: {e}")
        print()
        print("Troubleshooting:")
        print("1. Verify you have the correct OAuth credentials file")
        print("2. Ensure the required APIs are enabled in Google Cloud")
        print("3. Check your internet connection")
        print()
        return False


def main():
    """Main entry point."""
    try:
        success = setup_oauth2()
        
        if not success:
            sys.exit(1)
    
    except KeyboardInterrupt:
        print()
        print("\n❌ Setup cancelled by user")
        sys.exit(1)
    except Exception as e:
        print()
        print(f"❌ Unexpected error: {e}")
        sys.exit(1)


if __name__ == '__main__':
    main()
