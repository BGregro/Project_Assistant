"""
Thumbnail Performance Analyzer

Correlates thumbnail variants (v1-v5) with video performance metrics.
Analyzes which designs perform best and why.
"""

import json
import logging
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional, Tuple
import pandas as pd
import numpy as np


logger = logging.getLogger(__name__)


class ThumbnailPerformanceAnalyzer:
    """Analyzes thumbnail performance correlation."""
    
    def __init__(self, data_dir: str = 'data'):
        """
        Initialize analyzer.
        
        Args:
            data_dir: Directory containing video data and analytics
        """
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(exist_ok=True)
        
        self.videos_df = None
        self.thumbnails_df = None
        self.analytics_df = None
        
        self._load_data()
    
    def _load_data(self):
        """Load video and analytics data."""
        try:
            # Load videos data
            videos_file = self.data_dir / 'videos.json'
            if videos_file.exists():
                with open(videos_file, 'r') as f:
                    videos = json.load(f)
                self.videos_df = pd.DataFrame(videos)
            
            # Load thumbnails data (metadata about which variant was used)
            thumbnails_file = self.data_dir / 'thumbnails.json'
            if thumbnails_file.exists():
                with open(thumbnails_file, 'r') as f:
                    self.thumbnails_df = pd.DataFrame(json.load(f))
            
            # Load analytics data
            analytics_file = self.data_dir / 'analytics.json'
            if analytics_file.exists():
                with open(analytics_file, 'r') as f:
                    analytics = json.load(f)
                self.analytics_df = pd.DataFrame(analytics)
        
        except Exception as e:
            logger.warning(f"⚠ Could not load data files: {e}")
            logger.info("Run data collector first to generate data")
    
    def correlate_thumbnails_with_performance(self,
                                             min_days: int = 7) -> Optional[pd.DataFrame]:
        """
        Correlate thumbnail variants with performance metrics.
        
        Args:
            min_days: Minimum days since upload to consider (let analytics stabilize)
        
        Returns:
            DataFrame with thumbnail variant and corresponding metrics
        """
        if self.videos_df is None or self.thumbnails_df is None:
            logger.error("❌ Video or thumbnail data not loaded")
            return None
        
        try:
            # Merge videos with thumbnails
            merged = self.videos_df.merge(
                self.thumbnails_df,
                on='id',
                how='left'
            )
            
            # Calculate days since upload
            merged['published_at'] = pd.to_datetime(merged['published_at'])
            merged['days_since_upload'] = (datetime.now() - merged['published_at']).dt.days
            
            # Filter for videos with sufficient analytics history
            filtered = merged[merged['days_since_upload'] >= min_days].copy()
            
            # Calculate engagement metrics
            filtered['engagement_rate'] = (
                (filtered['like_count'] + filtered['comment_count']) /
                filtered['view_count'].replace(0, 1)
            ) * 100
            
            filtered['ctr'] = (
                filtered.get('clicks', 0) /
                filtered.get('impressions', 1)
            ) * 100
            
            logger.info(f"✓ Correlated {len(filtered)} videos with thumbnails")
            return filtered
        
        except Exception as e:
            logger.error(f"❌ Error correlating data: {e}")
            return None
    
    def aggregate_performance_by_variant(self,
                                        correlation_df: Optional[pd.DataFrame] = None) -> Dict:
        """
        Aggregate performance metrics by thumbnail variant.
        
        Args:
            correlation_df: DataFrame from correlate_thumbnails_with_performance
        
        Returns:
            Dictionary with performance stats per variant
        """
        if correlation_df is None:
            correlation_df = self.correlate_thumbnails_with_performance()
        
        if correlation_df is None or correlation_df.empty:
            logger.error("❌ No correlation data available")
            return {}
        
        try:
            # Group by variant
            variant_stats = {}
            
            for variant in ['v1', 'v2', 'v3', 'v4', 'v5']:
                variant_data = correlation_df[
                    correlation_df['thumbnail_variant'] == variant
                ]
                
                if variant_data.empty:
                    continue
                
                # Calculate stats
                stats = {
                    'count': len(variant_data),
                    'avg_views': variant_data['view_count'].mean(),
                    'median_views': variant_data['view_count'].median(),
                    'avg_likes': variant_data['like_count'].mean(),
                    'avg_comments': variant_data['comment_count'].mean(),
                    'avg_engagement_rate': variant_data['engagement_rate'].mean(),
                    'view_std': variant_data['view_count'].std(),
                    'min_views': variant_data['view_count'].min(),
                    'max_views': variant_data['view_count'].max(),
                }
                
                variant_stats[variant] = stats
            
            logger.info(f"✓ Aggregated performance for {len(variant_stats)} variants")
            return variant_stats
        
        except Exception as e:
            logger.error(f"❌ Error aggregating data: {e}")
            return {}
    
    def get_top_performing_variant(self) -> Optional[str]:
        """Get best performing thumbnail variant."""
        stats = self.aggregate_performance_by_variant()
        
        if not stats:
            return None
        
        # Find variant with highest average views
        top_variant = max(stats.items(), key=lambda x: x[1]['avg_views'])
        return top_variant[0]
    
    def get_correlation_insights(self,
                                correlation_df: Optional[pd.DataFrame] = None) -> Dict:
        """
        Generate insights about thumbnail performance.
        
        Args:
            correlation_df: DataFrame from correlate_thumbnails_with_performance
        
        Returns:
            Dictionary with key insights and recommendations
        """
        if correlation_df is None:
            correlation_df = self.correlate_thumbnails_with_performance()
        
        if correlation_df is None or correlation_df.empty:
            return {}
        
        try:
            variant_stats = self.aggregate_performance_by_variant(correlation_df)
            
            if not variant_stats:
                return {}
            
            insights = {
                'total_videos_analyzed': len(correlation_df),
                'variants_tested': len(variant_stats),
                'top_performing_variant': self.get_top_performing_variant(),
                'variant_performance': variant_stats,
                'recommendations': [],
            }
            
            # Generate recommendations
            if variant_stats:
                # Find best and worst variants
                best = max(variant_stats.items(), key=lambda x: x[1]['avg_views'])
                worst = min(variant_stats.items(), key=lambda x: x[1]['avg_views'])
                
                improvement = (
                    (best[1]['avg_views'] - worst[1]['avg_views']) /
                    worst[1]['avg_views']
                ) * 100
                
                insights['performance_gap'] = improvement
                
                insights['recommendations'].append({
                    'priority': 'HIGH',
                    'action': f"INCREASE_USAGE",
                    'variant': best[0],
                    'reason': f"{best[0]} performs best with {best[1]['avg_views']:.0f} avg views",
                    'improvement': f"+{improvement:.1f}% better than {worst[0]}"
                })
                
                # Check for consistency
                best_consistency = best[1]['view_std'] / best[1]['avg_views']
                if best_consistency < 0.5:
                    insights['recommendations'].append({
                        'priority': 'MEDIUM',
                        'action': 'MAINTAIN',
                        'variant': best[0],
                        'reason': f"{best[0]} has consistent performance (std: {best[1]['view_std']:.0f})",
                    })
                
                # Flag underperforming variants
                if worst[1]['count'] > 3:
                    insights['recommendations'].append({
                        'priority': 'MEDIUM',
                        'action': 'OPTIMIZE',
                        'variant': worst[0],
                        'reason': f"{worst[0]} underperforms ({worst[1]['avg_views']:.0f} avg views)",
                        'suggestion': 'Test design changes or increase text contrast'
                    })
            
            logger.info(f"✓ Generated {len(insights['recommendations'])} recommendations")
            return insights
        
        except Exception as e:
            logger.error(f"❌ Error generating insights: {e}")
            return {}
    
    def compare_variants(self) -> pd.DataFrame:
        """
        Create comparison table of all variants.
        
        Returns:
            DataFrame comparing variants side-by-side
        """
        stats = self.aggregate_performance_by_variant()
        
        if not stats:
            return pd.DataFrame()
        
        # Convert to DataFrame
        comparison = pd.DataFrame(stats).T
        
        # Calculate performance score (0-100)
        if not comparison.empty:
            max_views = comparison['avg_views'].max()
            comparison['performance_score'] = (
                (comparison['avg_views'] / max_views) * 100
            ).round(1)
            
            # Sort by performance
            comparison = comparison.sort_values('performance_score', ascending=False)
        
        return comparison
    
    def analyze_by_category(self,
                           category_field: str = 'category') -> Dict:
        """
        Analyze thumbnail performance by content category.
        
        Args:
            category_field: Field name containing category info
        
        Returns:
            Dictionary with performance per category
        """
        if self.videos_df is None:
            logger.error("❌ Video data not loaded")
            return {}
        
        try:
            correlation_df = self.correlate_thumbnails_with_performance()
            
            if correlation_df is None or category_field not in correlation_df.columns:
                return {}
            
            category_stats = {}
            
            for category in correlation_df[category_field].unique():
                cat_data = correlation_df[
                    correlation_df[category_field] == category
                ]
                
                category_stats[category] = {
                    'count': len(cat_data),
                    'avg_views': cat_data['view_count'].mean(),
                    'avg_engagement': cat_data['engagement_rate'].mean(),
                    'best_variant': cat_data.groupby('thumbnail_variant')[
                        'view_count'
                    ].mean().idxmax() if len(cat_data) > 0 else None,
                }
            
            logger.info(f"✓ Analyzed performance for {len(category_stats)} categories")
            return category_stats
        
        except Exception as e:
            logger.error(f"❌ Error analyzing by category: {e}")
            return {}
    
    def export_analysis(self, output_file: str = 'thumbnail_analysis.json'):
        """Export analysis results to JSON."""
        try:
            analysis = {
                'timestamp': datetime.now().isoformat(),
                'variant_performance': self.aggregate_performance_by_variant(),
                'insights': self.get_correlation_insights(),
                'comparison': self.compare_variants().to_dict(),
            }
            
            output_path = self.data_dir / output_file
            with open(output_path, 'w') as f:
                json.dump(analysis, f, indent=2, default=str)
            
            logger.info(f"✓ Analysis exported to {output_file}")
        
        except Exception as e:
            logger.error(f"❌ Error exporting analysis: {e}")


def setup_logging():
    """Configure logging."""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )


if __name__ == '__main__':
    setup_logging()
    
    # Example usage
    analyzer = ThumbnailPerformanceAnalyzer()
    
    # Get insights
    insights = analyzer.get_correlation_insights()
    
    if insights:
        print("\n📊 THUMBNAIL PERFORMANCE ANALYSIS")
        print("=" * 60)
        print(f"Videos Analyzed: {insights['total_videos_analyzed']}")
        print(f"Variants Tested: {insights['variants_tested']}")
        print(f"Top Performer: {insights['top_performing_variant']}")
        print()
        
        print("Recommendations:")
        for rec in insights['recommendations']:
            print(f"  [{rec['priority']}] {rec['action']}: {rec['variant']}")
            print(f"       {rec['reason']}")
        
        # Comparison table
        print("\n📈 VARIANT COMPARISON")
        print(analyzer.compare_variants())
