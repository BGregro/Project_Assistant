"""
YouTube Uploader - Handles video uploads to YouTube.
Includes A/B testing thumbnail variant tracking.
"""

from pathlib import Path
from typing import Optional, Dict
from datetime import datetime
import json
from utils import log_action, get_logger, save_json, load_json
from config import config, DATA_DIR

logger = get_logger(__name__)


class YouTubeUploader:
    def __init__(self):
        self.api_key = config.get("upload.youtube_api_key")
        self.channel_id = config.get("upload.channel_id")
        self.auto_publish = config.get("upload.mode") == "automatic"
        self.auto_schedule = config.get("upload.upload_schedule")
        self.upload_status_file = Path(config.get("paths.metadata_dir")) / "upload_status.json"
        self.upload_history = self._load_history()

    def _load_history(self) -> Dict:
        """Load upload history."""
        data = load_json(self.upload_status_file, default={"uploads": []})
        return data

    def _save_history(self):
        """Save upload history."""
        save_json(self.upload_history, self.upload_status_file)

    def prepare_video(
        self,
        video_path: Path,
        topic: str,
        category: str,
        script: str = None,
        thumbnail_variants: Dict = None,
        selected_variant_id: str = None,
    ) -> Dict:
        """
        Prepare video for upload with metadata.
        Includes thumbnail variant tracking for A/B testing.
        """
        if not video_path.exists():
            log_action("UPLOAD_PREP", f"Video file not found: {video_path}", "ERROR")
            return {}

        # Generate metadata
        metadata = {
            "title": self._generate_title(topic),
            "description": self._generate_description(topic, script),
            "tags": self._generate_tags(topic, category),
            "category_id": self._get_youtube_category_id(category),
            "made_for_kids": False,
            "privacy_status": "private" if not self.auto_publish else "public",
            "video_path": str(video_path),
            "topic": topic,
            "category": category,
            "file_size_mb": video_path.stat().st_size / (1024 * 1024),
            # A/B Testing tracking
            "thumbnail_variants": thumbnail_variants or {},
            "selected_variant_id": selected_variant_id,
            "ab_test_tracking": {
                "enabled": True,
                "variants_generated": len(thumbnail_variants) if thumbnail_variants else 0,
                "selected_variant": selected_variant_id,
                "test_start_date": datetime.now().isoformat(),
                "metrics": {}
            }
        }

        log_action("UPLOAD_PREP", f"Prepared metadata for: {topic} (variant: {selected_variant_id})")
        return metadata

    def _generate_title(self, topic: str, max_length: int = 70) -> str:
        """Generate YouTube-friendly title."""
        title_templates = [
            "{topic} - You Won't Believe This!",
            "This {topic} Will Blow Your Mind",
            "{topic} Explained in 60 Seconds",
            "The Ultimate {topic} Guide",
            "Shocking {topic} Hack You Need to Know",
        ]

        import random
        template = random.choice(title_templates)
        title = template.format(topic=topic)

        if len(title) > max_length:
            title = title[:max_length - 3] + "..."

        return title

    def _generate_description(self, topic: str, script: str = None) -> str:
        """Generate YouTube description."""
        description = f"""About this video:
In this short, we explore {topic}. This is essential knowledge you need to know.

Timeline:
0:00 - Intro
0:15 - Key Points
0:50 - Conclusion

Learn More:
Subscribe to our channel for more amazing content like this!

#Shorts #{topic.replace(' ', '')} #MustWatch

---
Disclaimer: This content is for educational purposes. All information is to the best of our knowledge.
"""

        if script:
            description = f"Script:\n{script}\n\n" + description

        return description

    def _generate_tags(self, topic: str, category: str) -> list:
        """Generate YouTube tags."""
        tags = [
            topic,
            category,
            "shorts",
            "viral",
            "short video",
            "educational",
            "trending",
        ]

        topic_words = topic.split()
        tags.extend(topic_words[:3])

        tags = list(dict.fromkeys(tags))
        return tags[:30]

    def _get_youtube_category_id(self, category: str) -> str:
        """Map category to YouTube category ID."""
        category_map = {
            "Python Tips": "28",
            "AI Tools": "28",
            "Coding Challenges": "28",
            "Web Development": "28",
            "General": "25",
        }

        return category_map.get(category, "25")

    def schedule_upload(
        self,
        video_metadata: Dict,
        publish_time: datetime = None,
    ) -> bool:
        """
        Schedule video upload (for manual approval).
        Doesn't actually upload yet.
        """
        if not video_metadata:
            log_action("SCHEDULE", "No metadata provided", "ERROR")
            return False

        scheduled = {
            "scheduled_at": datetime.now().isoformat(),
            "publish_at": publish_time.isoformat() if publish_time else None,
            "status": "pending_approval",
            "metadata": video_metadata,
        }

        self.upload_history["uploads"].append(scheduled)
        self._save_history()

        log_action("SCHEDULE", f"Scheduled for approval: {video_metadata['title']}")
        return True

    def upload_video(self, video_metadata: Dict, auto_approve: bool = False) -> bool:
        """
        Upload video to YouTube.
        If auto_approve is False, requires manual YouTube account authorization.
        """
        if not self.api_key:
            log_action("UPLOAD", "YouTube API key not configured", "ERROR")
            log_action("UPLOAD", "Manual upload required - log into YouTube Studio", "INFO")
            return False

        if not video_metadata:
            log_action("UPLOAD", "No metadata provided", "ERROR")
            return False

        try:
            try:
                from google_auth_oauthlib.flow import InstalledAppFlow
                from googleapiclient.discovery import build
                from googleapiclient.http import MediaFileUpload
            except ImportError:
                log_action(
                    "UPLOAD",
                    "YouTube API libraries not installed. Install with: pip install google-auth-oauthlib google-auth-httplib2 google-api-python-client",
                    "ERROR",
                )
                return False

            log_action("UPLOAD", f"Uploading: {video_metadata['title']}")

            log_action(
                "UPLOAD",
                "Full API upload requires OAuth2 authentication setup",
                "INFO",
            )

            upload_record = {
                "uploaded_at": datetime.now().isoformat(),
                "title": video_metadata["title"],
                "video_path": video_metadata["video_path"],
                "status": "ready_for_upload",
                "requires_manual_upload": True,
                "instructions": "Use YouTube Studio to upload the video file manually",
            }

            self.upload_history["uploads"].append(upload_record)
            self._save_history()

            log_action("UPLOAD", "✓ Video prepared for manual upload")
            return True

        except Exception as e:
            log_action("UPLOAD", f"Error: {str(e)}", "ERROR")
            return False

    def list_pending_uploads(self) -> list:
        """Get list of pending uploads."""
        pending = [
            u for u in self.upload_history.get("uploads", [])
            if u.get("status") in ["pending_approval", "ready_for_upload"]
        ]

        return sorted(pending, key=lambda x: x.get("uploaded_at"), reverse=True)

    def approve_upload(self, video_index: int) -> bool:
        """Approve a pending upload."""
        uploads = self.upload_history.get("uploads", [])

        if 0 <= video_index < len(uploads):
            upload = uploads[video_index]

            if upload.get("status") == "pending_approval":
                upload["status"] = "approved"
                upload["approved_at"] = datetime.now().isoformat()
                self._save_history()

                log_action("APPROVE", f"Approved: {upload.get('title')}")
                return True

        return False

    def reject_upload(self, video_index: int, reason: str = None) -> bool:
        """Reject a pending upload."""
        uploads = self.upload_history.get("uploads", [])

        if 0 <= video_index < len(uploads):
            upload = uploads[video_index]

            if upload.get("status") == "pending_approval":
                upload["status"] = "rejected"
                upload["rejected_at"] = datetime.now().isoformat()
                upload["rejection_reason"] = reason

                self._save_history()

                log_action("REJECT", f"Rejected: {upload.get('title')} - Reason: {reason}")
                return True

        return False

    def display_pending_uploads(self):
        """Display pending uploads for approval."""
        pending = self.list_pending_uploads()

        if not pending:
            print("No pending uploads.")
            return

        print("\n" + "=" * 70)
        print("PENDING UPLOADS FOR APPROVAL")
        print("=" * 70)

        for i, upload in enumerate(pending):
            print(f"\n[{i}] {upload.get('title')}")
            print(f"    Scheduled: {upload.get('scheduled_at', 'N/A')[:10]}")
            print(f"    Status: {upload.get('status')}")
            print(f"    Publish: {upload.get('publish_at', 'Immediately')}")

        print("\n" + "=" * 70)
        print("Use: approve_upload(index) or reject_upload(index, 'reason')")
        print("=" * 70 + "\n")

    def display_status(self):
        """Display upload status."""
        print("\n" + "=" * 70)
        print("YOUTUBE UPLOAD STATUS")
        print("=" * 70)

        print(f"Channel ID: {self.channel_id or 'NOT SET'}")
        print(f"API Key: {'✓ Configured' if self.api_key else '✗ Not configured'}")
        print(f"Auto-publish: {'✓ Enabled' if self.auto_publish else '○ Disabled (Manual approval)'}")

        if self.auto_schedule:
            print(f"Auto-schedule time: {self.auto_schedule}")

        uploads = self.upload_history.get("uploads", [])
        pending = self.list_pending_uploads()

        print(f"\nTotal uploads: {len(uploads)}")
        print(f"Pending approval: {len(pending)}")

        print("=" * 70 + "\n")

    def export_upload_metadata(self, video_metadata: Dict, filepath: Path = None) -> str:
        """Export metadata to JSON file for manual upload."""
        if filepath is None:
            from utils import sanitize_filename

            filename = f"{sanitize_filename(video_metadata['title'])}_metadata.json"
            filepath = DATA_DIR / filename

        save_json(video_metadata, filepath)
        log_action("EXPORT", f"Exported metadata to {filepath}")
        return str(filepath)
