"""
Voiceover Synthesis - Converts scripts to audio using pyttsx3 or ElevenLabs.
"""

from pathlib import Path
from typing import Optional
import pyttsx3
from utils import log_action, get_logger, timer, sanitize_filename
from config import config, DATA_DIR

logger = get_logger(__name__)


class VoiceoverSynthesis:
    """Generates voiceover audio from scripts."""

    def __init__(self):
        self.engine = config.get("voiceover.engine", "pyttsx3")
        self.language = config.get("voiceover.language", "en")
        self.rate = config.get("voiceover.rate", 150)
        self.volume = config.get("voiceover.volume", 1.0)
        self.voice_gender = config.get("voiceover.voice_gender", "female")
        self.voiceovers_dir = Path(config.get("paths.voiceovers_dir"))

        if self.engine == "pyttsx3":
            self.tts = pyttsx3.init()
            self._setup_pyttsx3()
        elif self.engine == "elevenlabs":
            self.api_key = config.get("voiceover.elevenlabs_api_key")
            if not self.api_key:
                log_action("VOICEOVER", "ElevenLabs API key not set", "WARNING")
                self.engine = "pyttsx3"
                self.tts = pyttsx3.init()
                self._setup_pyttsx3()

    def _setup_pyttsx3(self):
        """Configure pyttsx3 settings."""
        try:
            # Set speech rate
            self.tts.setProperty("rate", self.rate)
            log_action("VOICEOVER", f"✓ Set rate to {self.rate} WPM")

            # Set volume
            self.tts.setProperty("volume", self.volume)
            log_action("VOICEOVER", f"✓ Set volume to {self.volume}")

            # Set voice gender
            voices = self.tts.getProperty("voices")
            if voices:
                # Try to find voice matching gender preference
                for voice in voices:
                    if self.voice_gender.lower() in voice.name.lower():
                        self.tts.setProperty("voice", voice.id)
                        log_action("VOICEOVER", f"✓ Set voice to {voice.name}")
                        break
                else:
                    # Fallback to first available voice
                    self.tts.setProperty("voice", voices[0].id)
                    log_action("VOICEOVER", f"✓ Using voice: {voices[0].name}")

        except Exception as e:
            log_action("VOICEOVER", f"Error configuring pyttsx3: {str(e)}", "WARNING")

    @timer
    def synthesize(self, script: str, topic: str) -> Optional[dict]:
        """
        Convert script to audio file.
        Returns dict with audio metadata or None on failure.
        """
        if not script.strip():
            log_action("VOICEOVER", "Empty script provided", "ERROR")
            return None

        try:
            if self.engine == "pyttsx3":
                return self._synthesize_pyttsx3(script, topic)
            elif self.engine == "elevenlabs":
                return self._synthesize_elevenlabs(script, topic)
            else:
                log_action("VOICEOVER", f"Unknown engine: {self.engine}", "ERROR")
                return None

        except Exception as e:
            log_action("VOICEOVER", f"Error synthesizing voiceover: {str(e)}", "ERROR")
            return None

    def _synthesize_pyttsx3(self, script: str, topic: str) -> dict:
        """Synthesize using pyttsx3 (local, offline)."""
        log_action("VOICEOVER", f"Synthesizing voiceover for: {topic}")

        # Create filename
        audio_filename = f"{sanitize_filename(topic)}_voiceover.mp3"
        audio_path = self.voiceovers_dir / audio_filename

        # Save audio
        self.tts.save_to_file(script, str(audio_path))
        self.tts.runAndWait()

        if audio_path.exists():
            size_mb = audio_path.stat().st_size / (1024 * 1024)
            log_action("VOICEOVER", f"✓ Generated: {audio_filename} ({size_mb:.2f} MB)")

            return {
                "filename": audio_filename,
                "filepath": str(audio_path),
                "size_bytes": audio_path.stat().st_size,
                "size_mb": size_mb,
                "topic": topic,
                "engine": "pyttsx3",
                "estimated_duration": self._estimate_duration(script),
            }
        else:
            log_action("VOICEOVER", "Failed to generate audio file", "ERROR")
            return None

    def _synthesize_elevenlabs(self, script: str, topic: str) -> Optional[dict]:
        """Synthesize using ElevenLabs API."""
        try:
            from elevenlabs import client
            from elevenlabs.client import ElevenLabs

            api_client = ElevenLabs(api_key=self.api_key)

            log_action("VOICEOVER", f"Synthesizing voiceover (ElevenLabs) for: {topic}")

            # Get voice ID based on gender preference
            voice_id = "21m00Tcm4TlvDq8ikWAM" if self.voice_gender == "female" else "jBpfuIE2acCO8z3wKNLl"

            # Create audio
            audio = api_client.text_to_speech.convert(
                voice_id=voice_id,
                text=script,
                model_id="eleven_monolingual_v1",
            )

            # Save audio
            audio_filename = f"{sanitize_filename(topic)}_voiceover_elevenlabs.mp3"
            audio_path = self.voiceovers_dir / audio_filename

            with open(audio_path, "wb") as f:
                for chunk in audio:
                    f.write(chunk)

            if audio_path.exists():
                size_mb = audio_path.stat().st_size / (1024 * 1024)
                log_action("VOICEOVER", f"✓ Generated: {audio_filename} ({size_mb:.2f} MB)")

                return {
                    "filename": audio_filename,
                    "filepath": str(audio_path),
                    "size_bytes": audio_path.stat().st_size,
                    "size_mb": size_mb,
                    "topic": topic,
                    "engine": "elevenlabs",
                    "estimated_duration": self._estimate_duration(script),
                }

        except ImportError:
            log_action("VOICEOVER", "ElevenLabs SDK not installed", "ERROR")
        except Exception as e:
            log_action("VOICEOVER", f"ElevenLabs error: {str(e)}", "ERROR")

        return None

    def _estimate_duration(self, script: str, wpm: int = None) -> float:
        """Estimate audio duration in seconds."""
        if wpm is None:
            wpm = self.rate

        word_count = len(script.split())
        duration = (word_count / wpm) * 60
        return duration

    def list_generated_voiceovers(self) -> list:
        """Get list of generated voiceovers."""
        voiceovers = []

        for audio_file in self.voiceovers_dir.glob("*.mp3"):
            voiceovers.append({
                "filename": audio_file.name,
                "filepath": str(audio_file),
                "size_mb": audio_file.stat().st_size / (1024 * 1024),
                "created": audio_file.stat().st_mtime,
            })

        return sorted(voiceovers, key=lambda x: x["created"], reverse=True)

    def change_rate(self, new_rate: int):
        """Change speech rate dynamically."""
        self.rate = new_rate

        if self.engine == "pyttsx3":
            self.tts.setProperty("rate", new_rate)
            log_action("VOICEOVER", f"Changed rate to {new_rate} WPM")

    def change_volume(self, new_volume: float):
        """Change volume dynamically (0.0 to 1.0)."""
        self.volume = max(0.0, min(1.0, new_volume))

        if self.engine == "pyttsx3":
            self.tts.setProperty("volume", self.volume)
            log_action("VOICEOVER", f"Changed volume to {self.volume}")

    def get_available_voices(self) -> list:
        """Get list of available voices."""
        if self.engine == "pyttsx3":
            try:
                voices = self.tts.getProperty("voices")
                return [{"id": v.id, "name": v.name, "languages": v.languages} for v in voices]
            except Exception as e:
                log_action("VOICEOVER", f"Error getting voices: {str(e)}", "ERROR")
                return []
        else:
            return []

    def set_voice(self, voice_id: str):
        """Set voice by ID."""
        if self.engine == "pyttsx3":
            try:
                self.tts.setProperty("voice", voice_id)
                log_action("VOICEOVER", f"Set voice to {voice_id}")
                return True
            except Exception as e:
                log_action("VOICEOVER", f"Error setting voice: {str(e)}", "ERROR")
                return False
        return False

    def test_voiceover(self, text: str = "Testing voiceover synthesis"):
        """Test voiceover synthesis with sample text."""
        log_action("VOICEOVER", "Testing voiceover...")

        if self.engine == "pyttsx3":
            self.tts.say(text)
            self.tts.runAndWait()
            log_action("VOICEOVER", "✓ Test completed")
        else:
            log_action("VOICEOVER", "Test only available for pyttsx3 engine", "INFO")

    def display_status(self):
        """Display voiceover synthesis status."""
        print("\n" + "=" * 70)
        print("VOICEOVER SYNTHESIS STATUS")
        print("=" * 70)

        print(f"Engine: {self.engine}")
        print(f"Speech Rate: {self.rate} WPM")
        print(f"Volume: {self.volume}")
        print(f"Voice Gender: {self.voice_gender}")
        print(f"Language: {self.language}")

        voiceovers = self.list_generated_voiceovers()
        print(f"\nGenerated Voiceovers: {len(voiceovers)}")

        if voiceovers:
            print("-" * 70)
            for vo in voiceovers[:5]:
                print(f"  {vo['filename']:40} ({vo['size_mb']:.2f} MB)")

        print("=" * 70 + "\n")
