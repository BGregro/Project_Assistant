"""
YouTube Shorts Automation System - Main Orchestrator
Manages the complete pipeline from topic to YouTube upload.
Includes thumbnail A/B testing.
"""

import sys
from pathlib import Path
from typing import Optional
import json
from datetime import datetime

# Add src to path
sys.path.insert(0, str(Path(__file__).parent))

from config import config, DATA_DIR
from utils import log_action, get_logger
from topic_manager import TopicManager
from script_generator import ScriptGenerator
from voiceover_synthesis import VoiceoverSynthesis
from thumbnail_generator import ThumbnailGenerator, DESIGN_VARIANTS
from video_synthesizer import VideoSynthesizer
from youtube_uploader import YouTubeUploader

logger = get_logger(__name__)


class YouTubeShortsAutomation:
    """Main orchestrator for the entire YouTube Shorts automation pipeline."""

    def __init__(self):
        self.topic_manager = TopicManager()
        self.script_generator = ScriptGenerator()
        self.voiceover = VoiceoverSynthesis()
        self.thumbnail_gen = ThumbnailGenerator()
        self.video_synth = VideoSynthesizer()
        self.youtube = YouTubeUploader()

        log_action("INIT", "YouTube Shorts Automation System initialized")

    def create_shorts(
        self,
        topic: str,
        category: str = None,
        script_variations: int = 1,
        auto_approve: bool = False,
        thumbnail_variant: str = None,
    ) -> Optional[dict]:
        """
        Complete pipeline: topic → script → voiceover → thumbnail → video → upload.
        Includes 5 thumbnail variant generation for A/B testing.
        """
        print("\n" + "=" * 70)
        print("YOUTUBE SHORTS CREATION PIPELINE")
        print("=" * 70)

        # Step 1: Add topic
        print(f"\n[1/8] Adding topic: {topic}")
        if not self.topic_manager.add_topic(topic, category):
            print("✗ Topic already exists or invalid!")
            return None
        print("✓ Topic added")

        # Step 2: Generate scripts
        print(f"\n[2/8] Generating {script_variations} script(s)...")
        scripts = self.script_generator.generate_script(topic, variations=script_variations)

        if not scripts:
            print("✗ Failed to generate scripts")
            return None

        # User selects best script (or use first)
        selected_script = scripts[0]
        print(f"✓ Generated {len(scripts)} script(s)")
        print(f"  Selected: {selected_script['filepath']}")
        self.script_generator.display_script(selected_script["text"], max_lines=15)

        # Step 3: Generate voiceover
        print("\n[3/8] Generating voiceover...")
        voiceover_info = self.voiceover.synthesize(selected_script["text"], topic)

        if not voiceover_info:
            print("✗ Failed to generate voiceover")
            return None

        print(f"✓ Voiceover generated: {voiceover_info['filename']}")

        # Step 4: Generate thumbnail variants (NEW - A/B testing)
        print("\n[4/8] Generating 5 thumbnail variants for A/B testing...")
        variants = self.thumbnail_gen.generate_variants(topic, category)

        if not variants:
            print("✗ Failed to generate thumbnail variants")
            return None

        print(f"✓ Generated 5 design variants for: {topic}")

        # Step 5: User selects best variant (or auto-select)
        print("\n[5/8] Selecting best thumbnail variant...")
        if thumbnail_variant and thumbnail_variant in variants:
            selected_variant_id = thumbnail_variant
        else:
            self.thumbnail_gen.display_variants(topic, show_paths=False)
            while True:
                choice = input(
                    "\nSelect variant [1-5] or [a]uto (high contrast), [s]kip: "
                ).strip().lower()
                if choice == "a":
                    selected_variant_id = "v1_high_contrast"
                    break
                elif choice == "s":
                    selected_variant_id = list(variants.keys())[0]
                    break
                elif choice in ["1", "2", "3", "4", "5"]:
                    variant_ids = list(variants.keys())
                    selected_variant_id = variant_ids[int(choice) - 1]
                    break
                else:
                    print("Invalid choice")

        self.thumbnail_gen.select_variant(topic, selected_variant_id)
        selected_thumbnail_info = variants[selected_variant_id]
        print(f"✓ Selected: {DESIGN_VARIANTS[selected_variant_id]['name']}")

        # Step 6: Synthesize video
        print("\n[6/8] Synthesizing video...")
        video_info = self.video_synth.generate_video(
            audio_path=Path(voiceover_info["filepath"]),
            thumbnail_path=Path(selected_thumbnail_info["filepath"]),
            topic=topic,
            category=category or self.topic_manager.categories[0],
            duration=voiceover_info.get("estimated_duration", 60),
        )

        if not video_info:
            print("✗ Failed to generate video")
            return None

        print(f"✓ Video generated: {video_info['filename']}")

        # Step 7: Prepare upload metadata
        print("\n[7/8] Preparing upload metadata...")
        video_metadata = self.youtube.prepare_video(
            video_path=Path(video_info["filepath"]),
            topic=topic,
            category=category or self.topic_manager.categories[0],
            script=selected_script["text"],
            thumbnail_variants=variants,
            selected_variant_id=selected_variant_id,
        )

        print(f"✓ Metadata prepared")
        print(f"  Title: {video_metadata['title']}")
        print(f"  Thumbnail: {selected_thumbnail_info['variant_name']}")

        # Step 8: Upload/Schedule
        print("\n[8/8] Upload decision...")
        if auto_approve or config.get("upload.auto_publish", False):
            self.youtube.upload_video(video_metadata, auto_approve=True)
            print("✓ Upload initiated")
        else:
            self.youtube.schedule_upload(video_metadata)
            print("✓ Scheduled for manual approval")

        # Mark video created
        self.topic_manager.mark_video_complete(topic)

        # Check for compilation
        self._check_compilation(category or self.topic_manager.categories[0])

        result = {
            "topic": topic,
            "category": category,
            "script": selected_script,
            "voiceover": voiceover_info,
            "thumbnail_variants": variants,
            "selected_variant": {
                "id": selected_variant_id,
                **selected_thumbnail_info,
            },
            "video": video_info,
            "metadata": video_metadata,
            "timestamp": datetime.now().isoformat(),
        }

        print("\n" + "=" * 70)
        print("✓ SHORTS CREATION COMPLETE!")
        print("=" * 70 + "\n")

        return result

    def batch_create_shorts(self, topics: list, category: str = None):
        """Create multiple Shorts from a list of topics."""
        print(f"\n[BATCH] Creating {len(topics)} Shorts...")

        results = []
        for i, topic in enumerate(topics, 1):
            print(f"\n--- Shorts {i}/{len(topics)} ---")
            result = self.create_shorts(topic, category)
            if result:
                results.append(result)

        print(f"\n[BATCH] Completed {len(results)}/{len(topics)} Shorts")
        return results

    def _check_compilation(self, category: str):
        """Check if compilation is ready and suggest it."""
        threshold = config.get("compilation.videos_before_compile", 5)
        status = self.topic_manager.get_compilation_status(category)

        if status[category]["ready_for_compilation"]:
            print(f"\n📌 Category '{category}' is ready for compilation!")
            print(f"   {status[category]['videos_created']} videos are ready")
            print(f"   Use: compile_category('{category}')")

    def compile_category(self, category: str, output_name: str = None) -> Optional[dict]:
        """Compile all videos in a category into a full-length video."""
        print(f"\n[COMPILE] Creating compilation for: {category}")

        # Get topics ready for compilation
        topics = self.topic_manager.get_pending_compilation_topics(category)

        if len(topics) < config.get("compilation.videos_before_compile", 5):
            print(f"✗ Not enough videos ({len(topics)} < 5)")
            return None

        # Get video files
        category_dir = Path(config.get("paths.videos_dir")) / category
        videos = list(category_dir.glob("*.mp4"))

        if not videos:
            print("✗ No videos found in category")
            return None

        # Create compilation
        compilation = self.video_synth.compile_shorts_to_full_video(
            category=category,
            shorts_videos=[str(v) for v in videos],
            output_filename=output_name,
        )

        if compilation:
            print(f"✓ Compilation created: {compilation['filename']}")
            self.topic_manager.mark_compiled(category, topics)
            return compilation
        else:
            print("✗ Compilation failed")
            return None

    def display_dashboard(self):
        """Display system status dashboard."""
        print("\n" + "=" * 70)
        print("YOUTUBE SHORTS AUTOMATION DASHBOARD")
        print("=" * 70)

        # Topics
        self.topic_manager.display_status()

        # Scripts
        scripts = self.script_generator.get_generated_scripts()
        print(f"Generated Scripts: {len(scripts)}")

        # Voiceovers
        self.voiceover.display_status()

        # Thumbnails
        self.thumbnail_gen.display_status()

        # Videos
        self.video_synth.display_status()

        # Uploads
        self.youtube.display_status()

    def interactive_menu(self):
        """Interactive menu for the system."""
        print("\n" + "=" * 70)
        print("YOUTUBE SHORTS AUTOMATION - INTERACTIVE MENU")
        print("=" * 70)

        while True:
            print("\n[1] Create single Shorts")
            print("[2] Create batch Shorts")
            print("[3] Approve pending uploads")
            print("[4] Create compilation")
            print("[5] View dashboard")
            print("[6] List all topics")
            print("[7] Settings")
            print("[0] Exit")

            choice = input("\nSelect option: ").strip()

            if choice == "1":
                topic = input("Enter topic: ").strip()
                if topic:
                    self.create_shorts(topic)

            elif choice == "2":
                num = int(input("How many Shorts? "))
                topics = []
                for i in range(num):
                    t = input(f"Topic {i+1}: ").strip()
                    if t:
                        topics.append(t)
                if topics:
                    self.batch_create_shorts(topics)

            elif choice == "3":
                self._approve_pending_uploads()

            elif choice == "4":
                categories = self.topic_manager.get_all_categories()
                print("\nAvailable categories:", list(categories.keys()))
                category = input("Category: ").strip()
                if category:
                    self.compile_category(category)

            elif choice == "5":
                self.display_dashboard()

            elif choice == "6":
                self.topic_manager.list_all_topics()

            elif choice == "7":
                self._settings_menu()

            elif choice == "0":
                print("Goodbye!")
                break

            else:
                print("Invalid option")

    def _approve_pending_uploads(self):
        """Review and approve pending uploads."""
        pending = self.youtube.list_pending_uploads()

        if not pending:
            print("No pending uploads")
            return

        self.youtube.display_pending_uploads()

        while True:
            action = input("\nApprove (a), Reject (r), or Skip (s)? ").strip().lower()

            if action == "a":
                idx = int(input("Upload index: "))
                self.youtube.approve_upload(idx)
                print("✓ Approved")
                break

            elif action == "r":
                idx = int(input("Upload index: "))
                reason = input("Rejection reason: ")
                self.youtube.reject_upload(idx, reason)
                print("✓ Rejected")
                break

            elif action == "s":
                break

    def _settings_menu(self):
        """Configure system settings."""
        print("\n[SETTINGS]")
        print("[1] Voiceover rate (WPM)")
        print("[2] Video resolution")
        print("[3] Auto-publish settings")
        print("[0] Back")

        choice = input("Select: ").strip()

        if choice == "1":
            rate = int(input("Speech rate (WPM, e.g., 150): "))
            self.voiceover.change_rate(rate)

        elif choice == "2":
            width = int(input("Width (default 1080): ") or "1080")
            height = int(input("Height (default 1920): ") or "1920")
            print(f"Resolution set to {width}x{height}")

        elif choice == "3":
            auto_publish = input("Auto-publish? (y/n): ").lower() == "y"
            print(f"Auto-publish: {'✓ Enabled' if auto_publish else '○ Disabled'}")


def main():
    """Main entry point."""
    print("\n" + "🎬 " * 15)
    print("YOUTUBE SHORTS AUTOMATION SYSTEM")
    print("🎬 " * 15 + "\n")

    system = YouTubeShortsAutomation()

    # Check arguments for command-line mode
    if len(sys.argv) > 1:
        if sys.argv[1] == "single" and len(sys.argv) > 2:
            topic = " ".join(sys.argv[2:])
            system.create_shorts(topic)
        elif sys.argv[1] == "batch" and len(sys.argv) > 2:
            topics = sys.argv[2:]
            system.batch_create_shorts(topics)
        elif sys.argv[1] == "dashboard":
            system.display_dashboard()
        else:
            print("Usage:")
            print("  python main.py single 'Topic Name'")
            print("  python main.py batch Topic1 Topic2 Topic3...")
            print("  python main.py dashboard")
            print("  python main.py  # Interactive mode")
    else:
        # Interactive mode
        system.interactive_menu()


if __name__ == "__main__":
    main()
