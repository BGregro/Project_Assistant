"""
Video Synthesizer - Generates videos from scripts, voiceovers, and thumbnails using stable diffusion.
"""

from pathlib import Path
from typing import Optional
import subprocess
import json
from utils import log_action, get_logger, timer, sanitize_filename
from config import config, DATA_DIR

logger = get_logger(__name__)


class VideoSynthesizer:
    """Generates videos from components."""

    def __init__(self):
        self.method = config.get("video_synthesis.method", "framepack")
        self.ffmpeg_path = config.get("paths.ffmpeg_path", "ffmpeg")
        self.video_width = config.get("video_synthesis.width", 1080)
        self.video_height = config.get("video_synthesis.height", 1920)
        self.fps = config.get("video_synthesis.fps", 30)
        self.bitrate = config.get("video_synthesis.bitrate", "8000k")
        self.audio_bitrate = config.get("video_synthesis.audio_bitrate", "192k")
        self.videos_dir = Path(config.get("paths.videos_dir"))
        self._verify_ffmpeg()

    def _verify_ffmpeg(self):
        """Check if FFmpeg is installed."""
        try:
            result = subprocess.run(
                [self.ffmpeg_path, "-version"],
                capture_output=True,
                timeout=5,
            )
            if result.returncode == 0:
                log_action("VIDEO_SYNTH", "✓ FFmpeg is available")
            else:
                log_action("VIDEO_SYNTH", "✗ FFmpeg error", "ERROR")
        except FileNotFoundError:
            log_action("VIDEO_SYNTH", "✗ FFmpeg not found in PATH", "ERROR")
        except Exception as e:
            log_action("VIDEO_SYNTH", f"✗ FFmpeg check failed: {str(e)}", "ERROR")

    @timer
    def generate_video(
        self,
        audio_path: Path,
        thumbnail_path: Path,
        topic: str,
        category: str,
        duration: float,
    ) -> Optional[dict]:
        """
        Generate video from audio and static thumbnail.
        Uses FFmpeg to combine components.
        """
        if not audio_path.exists():
            log_action("VIDEO_SYNTH", f"Audio file not found: {audio_path}", "ERROR")
            return None

        if not thumbnail_path.exists():
            log_action("VIDEO_SYNTH", f"Thumbnail not found: {thumbnail_path}", "ERROR")
            return None

        try:
            if self.method == "framepack":
                return self._generate_with_framepack(audio_path, thumbnail_path, topic, category)
            elif self.method == "slideshow":
                return self._generate_slideshow(audio_path, thumbnail_path, topic, category)
            else:
                log_action("VIDEO_SYNTH", f"Unknown method: {self.method}", "ERROR")
                return None

        except Exception as e:
            log_action("VIDEO_SYNTH", f"Error generating video: {str(e)}", "ERROR")
            return None

    def _generate_with_framepack(
        self, audio_path: Path, thumbnail_path: Path, topic: str, category: str
    ) -> Optional[dict]:
        """Generate video using FramePack method (static image + audio)."""
        log_action("VIDEO_SYNTH", f"Generating video (FramePack) for: {topic}")

        # Create output directory for category if it doesn't exist
        category_dir = self.videos_dir / category
        category_dir.mkdir(parents=True, exist_ok=True)

        video_filename = f"{sanitize_filename(topic)}_shorts.mp4"
        video_path = category_dir / video_filename

        # FFmpeg command to combine audio and static image
        cmd = [
            self.ffmpeg_path,
            "-loop", "1",
            "-i", str(thumbnail_path),
            "-i", str(audio_path),
            "-c:v", "libx264",
            "-c:a", "aac",
            "-b:v", self.bitrate,
            "-b:a", self.audio_bitrate,
            "-pix_fmt", "yuv420p",
            "-preset", "medium",
            "-y",  # Overwrite output file
            str(video_path),
        ]

        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                timeout=300,
            )

            if result.returncode == 0 and video_path.exists():
                size_mb = video_path.stat().st_size / (1024 * 1024)
                log_action("VIDEO_SYNTH", f"✓ Generated: {video_filename} ({size_mb:.2f} MB)")

                return {
                    "filename": video_filename,
                    "filepath": str(video_path),
                    "category": category,
                    "size_bytes": video_path.stat().st_size,
                    "size_mb": size_mb,
                    "topic": topic,
                    "method": "framepack",
                    "width": self.video_width,
                    "height": self.video_height,
                    "fps": self.fps,
                }
            else:
                log_action("VIDEO_SYNTH", f"FFmpeg error: {result.stderr.decode()}", "ERROR")
                return None

        except subprocess.TimeoutExpired:
            log_action("VIDEO_SYNTH", "Video generation timeout", "ERROR")
            return None

    def _generate_slideshow(
        self, audio_path: Path, thumbnail_path: Path, topic: str, category: str
    ) -> Optional[dict]:
        """Generate slideshow-style video with effects."""
        log_action("VIDEO_SYNTH", f"Generating video (Slideshow) for: {topic}")

        category_dir = self.videos_dir / category
        category_dir.mkdir(parents=True, exist_ok=True)

        video_filename = f"{sanitize_filename(topic)}_shorts.mp4"
        video_path = category_dir / video_filename

        # FFmpeg command with zoom/pan effects
        cmd = [
            self.ffmpeg_path,
            "-loop", "1",
            "-i", str(thumbnail_path),
            "-i", str(audio_path),
            "-vf",
            "scale=1080:1920,format=yuv420p,"
            "zoompan=z='min(zoom+0.002,1.5)':x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':d=1:s=1080x1920:fps=30",
            "-c:v", "libx264",
            "-c:a", "aac",
            "-b:v", self.bitrate,
            "-b:a", self.audio_bitrate,
            "-pix_fmt", "yuv420p",
            "-preset", "medium",
            "-y",
            str(video_path),
        ]

        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                timeout=300,
            )

            if result.returncode == 0 and video_path.exists():
                size_mb = video_path.stat().st_size / (1024 * 1024)
                log_action("VIDEO_SYNTH", f"✓ Generated: {video_filename} ({size_mb:.2f} MB)")

                return {
                    "filename": video_filename,
                    "filepath": str(video_path),
                    "category": category,
                    "size_bytes": video_path.stat().st_size,
                    "size_mb": size_mb,
                    "topic": topic,
                    "method": "slideshow",
                    "width": self.video_width,
                    "height": self.video_height,
                    "fps": self.fps,
                }
            else:
                log_action("VIDEO_SYNTH", f"FFmpeg error: {result.stderr.decode()}", "ERROR")
                return None

        except subprocess.TimeoutExpired:
            log_action("VIDEO_SYNTH", "Video generation timeout", "ERROR")
            return None

    def list_generated_videos(self, category: str = None) -> list:
        """Get list of generated videos."""
        videos = []

        if category:
            video_dir = self.videos_dir / category
            if video_dir.exists():
                for video_file in video_dir.glob("*.mp4"):
                    videos.append({
                        "filename": video_file.name,
                        "filepath": str(video_file),
                        "category": category,
                        "size_mb": video_file.stat().st_size / (1024 * 1024),
                        "created": video_file.stat().st_mtime,
                    })
        else:
            for category_dir in self.videos_dir.glob("*"):
                if category_dir.is_dir():
                    for video_file in category_dir.glob("*.mp4"):
                        videos.append({
                            "filename": video_file.name,
                            "filepath": str(video_file),
                            "category": category_dir.name,
                            "size_mb": video_file.stat().st_size / (1024 * 1024),
                            "created": video_file.stat().st_mtime,
                        })

        return sorted(videos, key=lambda x: x["created"], reverse=True)

    def display_status(self):
        """Display video synthesis status."""
        print("\n" + "=" * 70)
        print("VIDEO SYNTHESIS STATUS")
        print("=" * 70)

        print(f"Method: {self.method}")
        print(f"Resolution: {self.video_width}x{self.video_height}")
        print(f"FPS: {self.fps}")
        print(f"Video Bitrate: {self.bitrate}")
        print(f"Audio Bitrate: {self.audio_bitrate}")

        # Count videos by category
        all_videos = self.list_generated_videos()
        categories = {}

        for video in all_videos:
            cat = video["category"]
            if cat not in categories:
                categories[cat] = []
            categories[cat].append(video)

        print(f"\nGenerated Videos: {len(all_videos)}")
        print("-" * 70)

        for category, videos in sorted(categories.items()):
            total_size = sum(v["size_mb"] for v in videos)
            print(f"  {category:30} ({len(videos):3} videos, {total_size:8.2f} MB)")

        print("=" * 70 + "\n")

    def compile_shorts_to_full_video(
        self, category: str, shorts_videos: list, output_filename: str = None
    ) -> Optional[dict]:
        """
        Compile multiple Shorts into a full-length video.
        """
        if not shorts_videos:
            log_action("VIDEO_COMPILE", "No videos to compile", "ERROR")
            return None

        log_action("VIDEO_COMPILE", f"Compiling {len(shorts_videos)} Shorts for {category}")

        # Create output directory
        category_dir = self.videos_dir / category
        category_dir.mkdir(parents=True, exist_ok=True)

        if output_filename is None:
            output_filename = f"{sanitize_filename(category)}_compilation.mp4"

        output_path = category_dir / output_filename

        # Create concat demux file
        concat_file = category_dir / f"{sanitize_filename(category)}_concat.txt"
        with open(concat_file, "w") as f:
            for video in shorts_videos:
                f.write(f"file '{video}'\n")

        # FFmpeg concat command
        cmd = [
            self.ffmpeg_path,
            "-f", "concat",
            "-safe", "0",
            "-i", str(concat_file),
            "-c", "copy",
            "-y",
            str(output_path),
        ]

        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                timeout=600,
            )

            # Clean up concat file
            concat_file.unlink()

            if result.returncode == 0 and output_path.exists():
                size_mb = output_path.stat().st_size / (1024 * 1024)
                log_action("VIDEO_COMPILE", f"✓ Compiled: {output_filename} ({size_mb:.2f} MB)")

                return {
                    "filename": output_filename,
                    "filepath": str(output_path),
                    "category": category,
                    "size_mb": size_mb,
                    "shorts_compiled": len(shorts_videos),
                }
            else:
                log_action("VIDEO_COMPILE", f"FFmpeg error: {result.stderr.decode()}", "ERROR")
                return None

        except subprocess.TimeoutExpired:
            log_action("VIDEO_COMPILE", "Compilation timeout", "ERROR")
            if concat_file.exists():
                concat_file.unlink()
            return None
