"""
Script Generator - Generates video scripts using Ollama (qwen2.5).
"""

import requests
import json
from pathlib import Path
from typing import Optional
from utils import save_text, load_text, log_action, get_logger, timer
from config import config, DATA_DIR

logger = get_logger(__name__)


class ScriptGenerator:
    """Generates scripts using Ollama API."""

    def __init__(self):
        self.ollama_url = config.get("script_generation.ollama_api_url", "http://localhost:11434")
        self.model = config.get("script_generation.model", "qwen2.5")
        self.temperature = config.get("script_generation.temperature", 0.7)
        self.top_p = config.get("script_generation.top_p", 0.9)
        self.max_length = config.get("script_generation.max_script_length", 300)
        self.scripts_dir = Path(config.get("paths.scripts_dir"))
        self._verify_ollama()

    def _verify_ollama(self):
        """Check if Ollama is running and model is available."""
        try:
            response = requests.get(f"{self.ollama_url}/api/tags", timeout=5)
            if response.status_code == 200:
                models = response.json().get("models", [])
                model_names = [m.get("name", "").split(":")[0] for m in models]

                if self.model in model_names:
                    log_action("OLLAMA", f"✓ Model {self.model} is available")
                else:
                    log_action(
                        "OLLAMA",
                        f"⚠ Model {self.model} not found. Available: {model_names}",
                        "WARNING",
                    )
            else:
                log_action("OLLAMA", "✗ Failed to connect to Ollama", "ERROR")
        except requests.exceptions.ConnectionError:
            log_action(
                "OLLAMA", "✗ Ollama not running on " + self.ollama_url, "ERROR"
            )

    def _load_prompt_template(self) -> str:
        """Load script generation prompt template."""
        template_path = Path(config.get("paths.config_dir", "config")) / "prompts" / "script_template.txt"

        if template_path.exists():
            return load_text(template_path)

        # Default template
        return """You are an expert YouTube Shorts script writer. Create an engaging, concise script for a video about: {topic}

Requirements:
- Length: 60-90 seconds when read aloud
- Target: Tech-savvy audience
- Style: Informative and engaging
- Hook: Start with a compelling question or statement
- Content: 3-4 key points with examples
- CTA: End with a call-to-action (like, subscribe, comment)
- Format: Plain text, natural speech pattern

Write the script now:"""

    @timer
    def generate_script(self, topic: str, variations: int = 1) -> list:
        """
        Generate script(s) for a topic using Ollama.
        Returns list of scripts.
        """
        if not topic.strip():
            log_action("SCRIPT_GEN", "Empty topic provided", "ERROR")
            return []

        template = self._load_prompt_template()
        prompt = template.format(topic=topic)

        scripts = []

        for i in range(variations):
            try:
                log_action("SCRIPT_GEN", f"Generating script {i+1}/{variations} for: {topic}")

                response = requests.post(
                    f"{self.ollama_url}/api/generate",
                    json={
                        "model": self.model,
                        "prompt": prompt,
                        "stream": False,
                        "temperature": self.temperature,
                        "top_p": self.top_p,
                    },
                    timeout=120,
                )

                if response.status_code == 200:
                    result = response.json()
                    script = result.get("response", "").strip()

                    if script:
                        # Save script
                        script_filename = self._sanitize_filename(topic)
                        script_path = self.scripts_dir / f"{script_filename}_v{i+1}.txt"
                        save_text(script, script_path)

                        scripts.append({
                            "text": script,
                            "filepath": str(script_path),
                            "word_count": len(script.split()),
                            "topic": topic,
                            "variation": i + 1,
                        })

                        log_action("SCRIPT_GEN", f"✓ Generated variation {i+1}")
                    else:
                        log_action("SCRIPT_GEN", "Empty response from Ollama", "WARNING")
                else:
                    log_action(
                        "SCRIPT_GEN",
                        f"Ollama error: {response.status_code}",
                        "ERROR",
                    )

            except requests.exceptions.Timeout:
                log_action("SCRIPT_GEN", "Request timeout - Ollama response too slow", "ERROR")
            except requests.exceptions.ConnectionError:
                log_action("SCRIPT_GEN", f"Cannot connect to Ollama at {self.ollama_url}", "ERROR")
                break
            except Exception as e:
                log_action("SCRIPT_GEN", f"Error: {str(e)}", "ERROR")

        return scripts

    def refine_script(self, script: str, refinement_type: str = "engagement") -> str:
        """Refine an existing script."""
        refinement_prompts = {
            "engagement": "Make this script more engaging and hook the viewer immediately: {script}",
            "brevity": "Shorten this script to 60 seconds read time while keeping key points: {script}",
            "clarity": "Improve clarity and make technical concepts easier to understand: {script}",
            "seo": "Add relevant keywords naturally for SEO without sounding forced: {script}",
        }

        prompt = refinement_prompts.get(
            refinement_type, refinement_prompts["engagement"]
        ).format(script=script)

        try:
            response = requests.post(
                f"{self.ollama_url}/api/generate",
                json={
                    "model": self.model,
                    "prompt": prompt,
                    "stream": False,
                    "temperature": self.temperature,
                },
                timeout=60,
            )

            if response.status_code == 200:
                refined = response.json().get("response", "").strip()
                log_action("SCRIPT_REFINE", f"✓ Refined with {refinement_type}")
                return refined
            else:
                log_action("SCRIPT_REFINE", f"Error: {response.status_code}", "ERROR")
                return script

        except Exception as e:
            log_action("SCRIPT_REFINE", f"Error: {str(e)}", "ERROR")
            return script

    def estimate_duration(self, script: str, wpm: int = 150) -> float:
        """Estimate script duration in seconds."""
        word_count = len(script.split())
        duration = (word_count / wpm) * 60
        return duration

    def validate_script(self, script: str) -> tuple[bool, list]:
        """
        Validate script. Returns (is_valid, warnings).
        """
        warnings = []
        word_count = len(script.split())

        # Check word count (rough estimate: 150 WPM = 25 words per 10 seconds)
        if word_count > self.max_length:
            warnings.append(
                f"Script exceeds recommended length ({word_count} > {self.max_length} words)"
            )

        if word_count < 50:
            warnings.append("Script is very short (< 50 words)")

        # Check for required sections
        if not any(word in script.lower() for word in ["subscribe", "like", "comment", "cta"]):
            warnings.append("No clear call-to-action found")

        # Check minimum length
        if len(script.strip()) < 100:
            warnings.append("Script is too short (< 100 characters)")

        is_valid = len(warnings) == 0 or len(warnings) <= 1

        return is_valid, warnings

    def _sanitize_filename(self, text: str) -> str:
        """Convert text to valid filename."""
        invalid_chars = r'<>:"/\|?*'
        for char in invalid_chars:
            text = text.replace(char, "_")
        return text.replace(" ", "_")[:50]

    def load_script(self, filepath: Path) -> str:
        """Load script from file."""
        return load_text(filepath)

    def get_generated_scripts(self, topic: str = None) -> list:
        """Get list of generated scripts, optionally filtered by topic."""
        scripts = []

        for script_file in self.scripts_dir.glob("*.txt"):
            script_text = load_text(script_file)
            info = {
                "filename": script_file.name,
                "filepath": str(script_file),
                "size": script_file.stat().st_size,
                "word_count": len(script_text.split()),
            }

            if topic and topic in script_file.name:
                scripts.append(info)
            elif topic is None:
                scripts.append(info)

        return sorted(scripts, key=lambda x: x["filepath"], reverse=True)

    def display_script(self, script: str, max_lines: int = 50):
        """Pretty-print a script."""
        print("\n" + "=" * 70)
        print("SCRIPT PREVIEW")
        print("=" * 70)

        lines = script.split("\n")
        for i, line in enumerate(lines[:max_lines], 1):
            print(f"{i:3} | {line}")

        if len(lines) > max_lines:
            print(f"\n... ({len(lines) - max_lines} more lines)")

        duration = self.estimate_duration(script)
        word_count = len(script.split())
        print("\n" + "-" * 70)
        print(f"Word count: {word_count} | Est. duration: {duration:.1f}s | Lines: {len(lines)}")
        print("=" * 70 + "\n")
