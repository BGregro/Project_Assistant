"""
Thumbnail Generator - Generates 5 design variants for A/B testing.
Pure PIL-based, no external APIs required.
"""

from pathlib import Path
from typing import Optional, Dict, List
from PIL import Image, ImageDraw, ImageFont, ImageFilter
import json
from datetime import datetime
from utils import log_action, get_logger, timer, sanitize_filename
from config import config, DATA_DIR

logger = get_logger(__name__)

# Design variants configuration
DESIGN_VARIANTS = {
    "v1_high_contrast": {
        "name": "High Contrast + Large Text",
        "description": "Bold black background with bright text - benefits-driven",
        "bg_color": (0, 0, 0),
        "text_color": (255, 255, 0),
        "accent_color": (255, 100, 0),
        "text_size_ratio": 0.12,
        "style": "bold",
    },
    "v2_curiosity_hook": {
        "name": "Curiosity Hook + Muted",
        "description": "Muted colors with emoji/symbol - intriguing topics",
        "bg_color": (50, 50, 70),
        "text_color": (220, 220, 240),
        "accent_color": (150, 100, 200),
        "text_size_ratio": 0.10,
        "style": "elegant",
    },
    "v3_minimal": {
        "name": "Minimal + Geometric",
        "description": "Clean minimal design with geometric shapes",
        "bg_color": (240, 240, 245),
        "text_color": (20, 20, 40),
        "accent_color": (100, 150, 255),
        "text_size_ratio": 0.11,
        "style": "minimal",
    },
    "v4_benefit_driven": {
        "name": "Benefit-Driven + Action",
        "description": "Colorful background with action-oriented text",
        "bg_color": (30, 120, 200),
        "text_color": (255, 255, 255),
        "accent_color": (255, 200, 0),
        "text_size_ratio": 0.11,
        "style": "action",
    },
    "v5_trending_bold": {
        "name": "Trending + Bold",
        "description": "High saturation colors - viral/trending topics",
        "bg_color": (255, 100, 100),
        "text_color": (255, 255, 255),
        "accent_color": (0, 0, 0),
        "text_size_ratio": 0.12,
        "style": "bold",
    },
}


class ThumbnailGenerator:
    """Generates 5 thumbnail design variants for A/B testing."""

    def __init__(self):
        self.thumbnails_dir = Path(config.get("paths.thumbnails_dir"))
        self.width = config.get("thumbnail_generation.width", 1080)
        self.height = config.get("thumbnail_generation.height", 1920)
        self.font_path = self._get_font_path()
        self.tracking_file = self.thumbnails_dir / "thumbnail_tracking.json"
        self._load_tracking()

    def _get_font_path(self) -> str:
        """Get the best available font on the system."""
        import platform

        system = platform.system()

        # Try different font paths based on OS
        font_options = []
        if system == "Windows":
            font_options = [
                "C:\\Windows\\Fonts\\arial.ttf",
                "C:\\Windows\\Fonts\\ariblk.ttf",
                "C:\\Windows\\Fonts\\impact.ttf",
            ]
        elif system == "Darwin":  # macOS
            font_options = [
                "/Library/Fonts/Arial.ttf",
                "/System/Library/Fonts/Helvetica.ttc",
            ]
        else:  # Linux
            font_options = [
                "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
                "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
            ]

        # Return first available font
        for path in font_options:
            if Path(path).exists():
                return path

        # Fallback to default
        log_action("THUMBNAIL", "Using system default font", "WARNING")
        return None

    def _load_tracking(self):
        """Load thumbnail tracking data."""
        if self.tracking_file.exists():
            try:
                with open(self.tracking_file, "r") as f:
                    self.tracking = json.load(f)
            except:
                self.tracking = {}
        else:
            self.tracking = {}

    def _save_tracking(self):
        """Save thumbnail tracking data."""
        with open(self.tracking_file, "w") as f:
            json.dump(self.tracking, f, indent=2)

    @timer
    def generate_variants(
        self, topic: str, category: str = None
    ) -> Optional[Dict[str, dict]]:
        """
        Generate all 5 thumbnail design variants for A/B testing.
        Returns dict with variant_id -> {filepath, metadata}
        """
        if not topic.strip():
            log_action("THUMBNAIL", "Empty topic provided", "ERROR")
            return None

        log_action("THUMBNAIL", f"Generating 5 variants for: {topic}")

        variants = {}
        variant_tracking = {}

        try:
            for variant_id, variant_config in DESIGN_VARIANTS.items():
                variant_path = self._generate_variant(
                    topic, variant_id, variant_config
                )

                if variant_path:
                    variants[variant_id] = {
                        "filepath": str(variant_path),
                        "filename": variant_path.name,
                        "variant_name": variant_config["name"],
                        "variant_id": variant_id,
                        "topic": topic,
                        "category": category or "Uncategorized",
                        "size_kb": variant_path.stat().st_size / 1024,
                        "created": datetime.now().isoformat(),
                    }
                    variant_tracking[variant_id] = variants[variant_id]

            if variants:
                # Store tracking data
                topic_key = sanitize_filename(topic)
                self.tracking[topic_key] = {
                    "topic": topic,
                    "category": category,
                    "variants": variant_tracking,
                    "created": datetime.now().isoformat(),
                    "selected_variant": None,  # User will select one
                    "performance_data": {},  # For later analytics
                }
                self._save_tracking()

                log_action(
                    "THUMBNAIL",
                    f"✓ Generated 5 variants for: {topic}",
                )
                return variants
            else:
                log_action(
                    "THUMBNAIL",
                    f"Failed to generate variants for: {topic}",
                    "ERROR",
                )
                return None

        except Exception as e:
            log_action("THUMBNAIL", f"Error generating variants: {str(e)}", "ERROR")
            return None

    def _generate_variant(
        self, topic: str, variant_id: str, config: dict
    ) -> Optional[Path]:
        """Generate a single variant thumbnail."""
        try:
            # Create base image
            img = Image.new("RGB", (self.width, self.height), color=config["bg_color"])
            draw = ImageDraw.Draw(img, "RGBA")

            # Add design elements based on style
            self._add_design_elements(draw, config, self.width, self.height)

            # Add text
            self._add_text(draw, topic, config)

            # Add subtle grain/texture
            img = self._add_texture(img)

            # Save
            safe_topic = sanitize_filename(topic)
            filename = f"{safe_topic}_{variant_id}.png"
            filepath = self.thumbnails_dir / filename

            img.save(filepath, "PNG", optimize=True, quality=95)

            return filepath

        except Exception as e:
            log_action(
                "THUMBNAIL",
                f"Error generating {variant_id}: {str(e)}",
                "WARNING",
            )
            return None

    def _add_design_elements(self, draw, config: dict, width: int, height: int):
        """Add design elements based on style."""
        style = config["style"]
        accent = config["accent_color"]

        if style == "bold":
            # Add thick accent bar
            bar_height = 60
            draw.rectangle(
                [(0, height - bar_height), (width, height)],
                fill=accent,
            )

        elif style == "elegant":
            # Add elegant top border
            border_height = 8
            draw.rectangle(
                [(0, 0), (width, border_height)],
                fill=accent,
            )
            # Add subtle circles
            for x in range(0, width, width // 5):
                draw.ellipse(
                    [(x - 30, 50), (x + 30, 110)],
                    outline=accent,
                    width=2,
                )

        elif style == "minimal":
            # Add geometric accent lines
            line_width = 4
            draw.rectangle(
                [(0, 0), (width, line_width)],
                fill=accent,
            )
            draw.rectangle(
                [(0, height - line_width), (width, height)],
                fill=accent,
            )
            # Add subtle rectangles
            for i in range(3):
                x = (width // 3) * i
                draw.rectangle(
                    [(x, height // 2 - 50), (x + 100, height // 2 + 50)],
                    outline=accent,
                    width=2,
                )

        elif style == "action":
            # Add diagonal accent stripe
            draw.polygon(
                [
                    (0, 0),
                    (width // 2, 0),
                    (0, height // 3),
                ],
                fill=accent,
            )
            # Add corner badge
            badge_size = 150
            draw.ellipse(
                [(width - badge_size, height - badge_size), (width, height)],
                fill=accent,
            )

    def _add_text(self, draw, topic: str, config: dict):
        """Add formatted text to thumbnail."""
        text_color = config["text_color"]
        text_size = int(self.height * config["text_size_ratio"])

        # Try to use system font, fall back to default
        try:
            if self.font_path:
                font = ImageFont.truetype(self.font_path, size=text_size)
                font_small = ImageFont.truetype(self.font_path, size=int(text_size * 0.6))
            else:
                font = ImageFont.load_default()
                font_small = font
        except:
            font = ImageFont.load_default()
            font_small = font

        # Wrap and format text
        lines = self._wrap_text(topic, max_width=self.width - 80)

        # Center text vertically
        total_height = len(lines) * text_size
        y_start = (self.height - total_height) // 2

        # Draw text with shadow effect
        shadow_offset = 3
        for i, line in enumerate(lines):
            y = y_start + (i * text_size)

            # Shadow
            bbox = draw.textbbox(
                (0, 0), line, font=font
            )  # Get text size
            text_width = bbox[2] - bbox[0]
            x = (self.width - text_width) // 2

            shadow_color = (
                config["bg_color"][0] // 2,
                config["bg_color"][1] // 2,
                config["bg_color"][2] // 2,
            )
            draw.text(
                (x + shadow_offset, y + shadow_offset),
                line,
                fill=shadow_color,
                font=font,
            )

            # Main text
            draw.text(
                (x, y),
                line,
                fill=text_color,
                font=font,
            )

    def _wrap_text(self, text: str, max_width: int) -> List[str]:
        """Wrap text to fit width (approximate)."""
        words = text.split()
        lines = []
        current_line = []

        for word in words:
            current_line.append(word)
            # Rough estimate: 15 chars per line at max_width
            if len(" ".join(current_line)) > 15:
                current_line.pop()
                if current_line:
                    lines.append(" ".join(current_line))
                current_line = [word]

        if current_line:
            lines.append(" ".join(current_line))

        return lines

    def _add_texture(self, img: Image.Image) -> Image.Image:
        """Add subtle texture/grain to image."""
        # Create subtle noise layer
        noise = Image.new("RGBA", img.size, (0, 0, 0, 0))
        pixels = noise.load()

        import random

        for i in range(img.size[0]):
            for j in range(img.size[1]):
                if random.random() < 0.01:  # 1% noise density
                    alpha = random.randint(5, 15)
                    pixels[i, j] = (255, 255, 255, alpha)

        # Blend noise onto image
        img_rgba = img.convert("RGBA")
        img_rgba = Image.alpha_composite(img_rgba, noise)
        return img_rgba.convert("RGB")

    def select_variant(
        self, topic: str, variant_id: str, is_compilation: bool = False
    ) -> bool:
        """
        Mark a variant as selected for upload.
        If is_compilation=True, track for compilation video analysis.
        """
        topic_key = sanitize_filename(topic)

        if topic_key not in self.tracking:
            log_action(
                "THUMBNAIL",
                f"No variants found for topic: {topic}",
                "ERROR",
            )
            return False

        if variant_id not in DESIGN_VARIANTS:
            log_action(
                "THUMBNAIL",
                f"Unknown variant: {variant_id}",
                "ERROR",
            )
            return False

        self.tracking[topic_key]["selected_variant"] = variant_id
        self.tracking[topic_key]["is_compilation"] = is_compilation
        self._save_tracking()

        log_action(
            "THUMBNAIL",
            f"✓ Selected {variant_id} for: {topic}",
        )
        return True

    def get_selected_variant(
        self, topic: str
    ) -> Optional[Dict[str, str]]:
        """Get the selected variant for a topic."""
        topic_key = sanitize_filename(topic)

        if topic_key not in self.tracking:
            return None

        variant_id = self.tracking[topic_key].get("selected_variant")
        if not variant_id:
            return None

        variant_data = self.tracking[topic_key]["variants"].get(variant_id)
        return variant_data

    def display_variants(
        self, topic: str, show_paths: bool = False
    ):
        """Display generated variants for user selection."""
        topic_key = sanitize_filename(topic)

        if topic_key not in self.tracking:
            print(f"No variants found for: {topic}")
            return

        data = self.tracking[topic_key]
        variants = data["variants"]

        print("\n" + "=" * 70)
        print(f"THUMBNAIL VARIANTS FOR: {topic}")
        print("=" * 70)

        for i, (variant_id, variant_info) in enumerate(variants.items(), 1):
            config = DESIGN_VARIANTS[variant_id]
            print(f"\n[{i}] {variant_id.upper()}")
            print(f"    Name: {config['name']}")
            print(f"    Desc: {config['description']}")
            if show_paths:
                print(f"    Path: {variant_info['filepath']}")

        print("\n" + "=" * 70)

    def list_generated_thumbnails(self) -> list:
        """Get list of all generated thumbnail variants."""
        thumbnails = []

        for thumb_file in self.thumbnails_dir.glob("*_v[1-5]_*.png"):
            thumbnails.append({
                "filename": thumb_file.name,
                "filepath": str(thumb_file),
                "size_kb": thumb_file.stat().st_size / 1024,
                "created": thumb_file.stat().st_mtime,
            })

        return sorted(thumbnails, key=lambda x: x["created"], reverse=True)

    def display_status(self):
        """Display thumbnail generation status."""
        print("\n" + "=" * 70)
        print("THUMBNAIL GENERATION STATUS")
        print("=" * 70)

        print(f"Resolution: {self.width}x{self.height}")
        print(f"Design Variants: 5 (High Contrast, Curiosity, Minimal, Benefit, Trending)")

        thumbnails = self.list_generated_thumbnails()
        topics_with_variants = len(self.tracking)

        print(f"\nGenerated Thumbnail Sets: {topics_with_variants}")
        print(f"Total Variant Images: {len(thumbnails)}")

        if thumbnails:
            print("-" * 70)
            for thumb in thumbnails[:10]:
                print(f"  {thumb['filename']:50} ({thumb['size_kb']:.1f} KB)")

        print("=" * 70 + "\n")
