"""
Configuration module for YouTube Shorts automation system.
Loads settings from settings.yaml and environment variables.
"""

import os
import json
from pathlib import Path
from typing import Dict, Any
import yaml
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Project root paths
PROJECT_ROOT = Path(__file__).parent.parent
DATA_DIR = PROJECT_ROOT / "data"
CONFIG_DIR = PROJECT_ROOT / "config"
SRC_DIR = PROJECT_ROOT / "src"

# Create necessary directories
DATA_DIR.mkdir(exist_ok=True)
(DATA_DIR / "scripts").mkdir(exist_ok=True)
(DATA_DIR / "voiceovers").mkdir(exist_ok=True)
(DATA_DIR / "videos").mkdir(exist_ok=True)
(DATA_DIR / "thumbnails").mkdir(exist_ok=True)
(DATA_DIR / "metadata").mkdir(exist_ok=True)
CONFIG_DIR.mkdir(exist_ok=True)
(CONFIG_DIR / "prompts").mkdir(exist_ok=True)

# Default settings (hardcoded fallback)
DEFAULT_SETTINGS = {
    "system": {
        "mode": "manual",  # manual, scheduled, automatic
        "batch_mode": True,  # Allow batch topic input
        "verbose": True,
        "log_file": str(DATA_DIR / "system.log"),
    },
    "topics": {
        "collection_categories": [
            "Python Tips",
            "AI Tools",
            "Coding Challenges",
            "Web Development",
            "General Tech",
        ],
        "auto_categorize": True,  # Automatically assign topics to categories
        "allow_duplicate_check": True,
    },
    "video_generation": {
        "shorts_mode": True,  # True = Shorts (60-90s), False = Full video
        "shorts_duration_min": 60,
        "shorts_duration_max": 90,
        "full_video_duration_min": 300,
        "full_video_duration_max": 600,
        "fps": 24,
        "resolution": "1080x1920",  # Shorts vertical format
        "video_quality": "high",  # low, medium, high
        "output_format": "mp4",
    },
    "script_generation": {
        "model": "qwen2.5",  # Ollama model to use
        "ollama_api_url": "http://localhost:11434",
        "max_script_length": 300,  # words
        "temperature": 0.7,
        "top_p": 0.9,
    },
    "voiceover": {
        "engine": "pyttsx3",  # pyttsx3 or elevenlabs
        "language": "en",
        "rate": 150,  # Words per minute
        "volume": 1.0,
        "voice_gender": "female",  # female or male
        "elevenlabs_api_key": os.getenv("ELEVENLABS_API_KEY", ""),
    },
    "thumbnail_generation": {
        "enabled": True,
        "model": "stable_diffusion",  # or "dall_e"
        "size": "1280x720",
        "style": "vibrant",
    },
    "compilation": {
        "auto_compile": False,  # Auto-compile when threshold reached
        "videos_before_compile": 5,  # Number of videos in collection before auto-compile
        "compilation_video_format": "mp4",
    },
    "upload": {
        "mode": "manual",  # manual, scheduled, automatic
        "upload_schedule": "09:00",  # HH:MM format (24-hour)
        "days_of_week": [1, 3, 5],  # Mon(0), Wed(2), Fri(4), etc.
        "youtube_credentials": os.getenv("YOUTUBE_CREDENTIALS_PATH", ""),
        "publish_status": "private",  # private, unlisted, public
        "add_timestamps": True,
    },
    "paths": {
        "data_dir": str(DATA_DIR),
        "scripts_dir": str(DATA_DIR / "scripts"),
        "voiceovers_dir": str(DATA_DIR / "voiceovers"),
        "videos_dir": str(DATA_DIR / "videos"),
        "thumbnails_dir": str(DATA_DIR / "thumbnails"),
        "metadata_dir": str(DATA_DIR / "metadata"),
        "topics_file": str(DATA_DIR / "topics.json"),
    },
    "logging": {
        "level": "INFO",  # DEBUG, INFO, WARNING, ERROR
        "format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    },
}


class Config:
    """Configuration manager - loads from YAML, env vars, or defaults."""

    def __init__(self):
        self.settings = self._load_settings()

    def _load_settings(self) -> Dict[str, Any]:
        """Load settings from settings.yaml or use defaults."""
        settings_file = CONFIG_DIR / "settings.yaml"

        if settings_file.exists():
            with open(settings_file, "r") as f:
                loaded = yaml.safe_load(f)
                # Deep merge with defaults
                return self._merge_dicts(DEFAULT_SETTINGS, loaded)
        else:
            # Create default settings file
            self._save_default_settings(settings_file)
            return DEFAULT_SETTINGS

    def _merge_dicts(self, base: Dict, override: Dict) -> Dict:
        """Deep merge override dict into base dict."""
        result = base.copy()
        for key, value in override.items():
            if isinstance(value, dict) and key in result:
                result[key] = self._merge_dicts(result[key], value)
            else:
                result[key] = value
        return result

    def _save_default_settings(self, path: Path):
        """Save default settings to YAML file."""
        with open(path, "w") as f:
            yaml.dump(DEFAULT_SETTINGS, f, default_flow_style=False)

    def get(self, key: str, default: Any = None) -> Any:
        """Get config value using dot notation (e.g., 'system.mode')."""
        keys = key.split(".")
        value = self.settings

        for k in keys:
            if isinstance(value, dict):
                value = value.get(k)
                if value is None:
                    return default
            else:
                return default

        return value

    def set(self, key: str, value: Any):
        """Set config value using dot notation."""
        keys = key.split(".")
        current = self.settings

        for k in keys[:-1]:
            if k not in current:
                current[k] = {}
            current = current[k]

        current[keys[-1]] = value

    def get_all(self) -> Dict[str, Any]:
        """Get all settings."""
        return self.settings

    def save_to_file(self, path: Path = None):
        """Save current settings to YAML file."""
        if path is None:
            path = CONFIG_DIR / "settings.yaml"

        with open(path, "w") as f:
            yaml.dump(self.settings, f, default_flow_style=False)

    def display_settings(self):
        """Pretty print all settings."""
        print("\n" + "=" * 60)
        print("CURRENT CONFIGURATION")
        print("=" * 60)
        print(json.dumps(self.settings, indent=2))
        print("=" * 60 + "\n")


# Global config instance
config = Config()
