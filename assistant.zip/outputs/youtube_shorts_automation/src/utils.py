"""
Utility functions for logging, file operations, and timing.
"""

import logging
import json
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Callable
from functools import wraps

try:
    from config import config, DATA_DIR
except ImportError:
    from .config import config, DATA_DIR

# Configure logging
log_file = Path(config.get("logging.format", DATA_DIR / "system.log"))
logging.basicConfig(
    level=getattr(logging, config.get("logging.level", "INFO")),
    format=config.get("logging.format", "%(asctime)s - %(name)s - %(levelname)s - %(message)s"),
    handlers=[
        logging.FileHandler(log_file),
        logging.StreamHandler(),
    ],
)

logger = logging.getLogger(__name__)


def get_logger(name: str) -> logging.Logger:
    """Get a logger instance for a specific module."""
    return logging.getLogger(name)


def log_action(action: str, details: str = "", level: str = "INFO"):
    """Log an action with consistent formatting."""
    log_func = getattr(logger, level.lower())
    log_func(f"[{action}] {details}")


def timer(func: Callable) -> Callable:
    """Decorator to time function execution."""

    @wraps(func)
    def wrapper(*args, **kwargs):
        start = time.time()
        result = func(*args, **kwargs)
        elapsed = time.time() - start
        logger.debug(f"{func.__name__} took {elapsed:.2f}s")
        return result

    return wrapper


def save_json(data: Any, filepath: Path, pretty: bool = True):
    """Save data to JSON file."""
    filepath = Path(filepath)
    filepath.parent.mkdir(parents=True, exist_ok=True)

    with open(filepath, "w") as f:
        json.dump(data, f, indent=2 if pretty else None)

    log_action("SAVE_JSON", f"Saved to {filepath}")


def load_json(filepath: Path, default: Any = None) -> Any:
    """Load data from JSON file."""
    filepath = Path(filepath)

    if not filepath.exists():
        log_action("LOAD_JSON", f"File not found: {filepath}, returning default", "WARNING")
        return default

    try:
        with open(filepath, "r") as f:
            data = json.load(f)
        log_action("LOAD_JSON", f"Loaded from {filepath}")
        return data
    except json.JSONDecodeError as e:
        log_action("LOAD_JSON", f"JSON decode error in {filepath}: {e}", "ERROR")
        return default


def save_text(content: str, filepath: Path):
    """Save text content to file."""
    filepath = Path(filepath)
    filepath.parent.mkdir(parents=True, exist_ok=True)

    with open(filepath, "w", encoding="utf-8") as f:
        f.write(content)

    log_action("SAVE_TEXT", f"Saved to {filepath}")


def load_text(filepath: Path) -> str:
    """Load text content from file."""
    filepath = Path(filepath)

    if not filepath.exists():
        log_action("LOAD_TEXT", f"File not found: {filepath}", "WARNING")
        return ""

    with open(filepath, "r", encoding="utf-8") as f:
        return f.read()


def format_timestamp() -> str:
    """Get current timestamp in ISO format."""
    return datetime.now().isoformat()


def format_duration(seconds: float) -> str:
    """Format seconds into human-readable duration."""
    if seconds < 60:
        return f"{seconds:.1f}s"
    elif seconds < 3600:
        minutes = seconds / 60
        return f"{minutes:.1f}m"
    else:
        hours = seconds / 3600
        return f"{hours:.1f}h"


def sanitize_filename(filename: str) -> str:
    """Remove invalid characters from filename."""
    invalid_chars = r'<>:"/\|?*'
    for char in invalid_chars:
        filename = filename.replace(char, "_")
    return filename


def truncate_text(text: str, max_length: int, suffix: str = "...") -> str:
    """Truncate text to max length."""
    if len(text) <= max_length:
        return text
    return text[: max_length - len(suffix)] + suffix


def print_header(title: str, width: int = 60):
    """Print a formatted header."""
    print("\n" + "=" * width)
    print(f"{title:^{width}}")
    print("=" * width)


def print_section(title: str):
    """Print a section divider."""
    print(f"\n--- {title} ---")


def print_success(message: str):
    """Print a success message."""
    print(f"✓ {message}")


def print_error(message: str):
    """Print an error message."""
    print(f"✗ {message}")


def print_info(message: str):
    """Print an info message."""
    print(f"ℹ {message}")


def prompt_user(question: str, options: list = None, default: str = None) -> str:
    """Prompt user for input with optional validation."""
    while True:
        response = input(f"\n{question}: ").strip()

        if not response and default:
            return default

        if options is None or response in options:
            return response

        print(f"Invalid option. Choose from: {', '.join(options)}")


def confirm_action(message: str) -> bool:
    """Ask user for confirmation."""
    response = prompt_user(f"{message} (y/n)", options=["y", "n"])
    return response.lower() == "y"


def read_large_file_chunks(filepath: Path, chunk_size: int = 8192):
    """Read large file in chunks."""
    with open(filepath, "rb") as f:
        while True:
            chunk = f.read(chunk_size)
            if not chunk:
                break
            yield chunk


def get_file_size_mb(filepath: Path) -> float:
    """Get file size in MB."""
    return filepath.stat().st_size / (1024 * 1024)
