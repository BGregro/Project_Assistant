"""
Topic Manager - Handles topic tracking, duplicate prevention, and collection organization.
"""

from pathlib import Path
from typing import List, Dict, Optional, Set
from datetime import datetime
from utils import save_json, load_json, log_action, get_logger
from config import config, DATA_DIR

logger = get_logger(__name__)


class TopicManager:
    """Manages topics, prevents duplicates, organizes into collections."""

    def __init__(self):
        self.topics_file = Path(config.get("paths.topics_file"))
        self.categories = config.get("topics.collection_categories", [])
        self.data = self._load_topics()

    def _load_topics(self) -> Dict:
        """Load topics database from JSON."""
        data = load_json(self.topics_file, default={})

        if not data:
            data = {
                "metadata": {
                    "created": datetime.now().isoformat(),
                    "total_topics": 0,
                },
                "used_topics": {},  # {topic: {category, created_at, video_count}}
                "collections": {},  # {category: [topics]}
                "pending_compilation": {},  # {category: [topics to compile]}
            }
            self._save_topics(data)

        return data

    def _save_topics(self, data: Dict = None):
        """Save topics database to JSON."""
        if data is None:
            data = self.data

        data["metadata"]["total_topics"] = len(data.get("used_topics", {}))
        save_json(data, self.topics_file)

    def add_topic(self, topic: str, category: str = None) -> bool:
        """
        Add a new topic to the database.
        Returns True if added, False if duplicate.
        """
        topic = topic.strip()

        if not topic:
            log_action("ADD_TOPIC", "Empty topic provided", "WARNING")
            return False

        if self._is_duplicate(topic):
            log_action("ADD_TOPIC", f"Duplicate topic: {topic}", "WARNING")
            return False

        # Auto-categorize if not specified
        if category is None and config.get("topics.auto_categorize", True):
            category = self._auto_categorize(topic)
        elif category is None:
            category = self.categories[0] if self.categories else "General"

        # Ensure category exists
        if category not in self.data["collections"]:
            self.data["collections"][category] = []

        # Add to database
        self.data["used_topics"][topic] = {
            "category": category,
            "created_at": datetime.now().isoformat(),
            "video_count": 0,
        }

        self.data["collections"][category].append(topic)

        self._save_topics()
        log_action("ADD_TOPIC", f"Added: {topic} → {category}")
        return True

    def _is_duplicate(self, topic: str) -> bool:
        """Check if topic already exists (case-insensitive)."""
        topic_lower = topic.lower().strip()
        for existing in self.data.get("used_topics", {}):
            if existing.lower().strip() == topic_lower:
                return True
        return False

    def _auto_categorize(self, topic: str) -> str:
        """Auto-assign topic to category based on keywords."""
        topic_lower = topic.lower()

        category_keywords = {
            "Python Tips": ["python", "pip", "virtual env", "decorator", "async", "pandas"],
            "AI Tools": ["ai", "machine learning", "llm", "neural", "model", "training"],
            "Coding Challenges": ["algorithm", "leetcode", "problem", "code", "challenge"],
            "Web Development": ["web", "html", "css", "javascript", "react", "django"],
        }

        for category, keywords in category_keywords.items():
            if any(keyword in topic_lower for keyword in keywords):
                return category

        # Default to first category
        return self.categories[0] if self.categories else "General"

    def get_topic_by_category(self, category: str) -> List[str]:
        """Get all topics in a specific category."""
        return self.data.get("collections", {}).get(category, [])

    def get_all_categories(self) -> List[str]:
        """Get all collection categories with topic counts."""
        result = {}
        for category, topics in self.data.get("collections", {}).items():
            result[category] = len(topics)
        return result

    def mark_video_complete(self, topic: str) -> bool:
        """Mark topic as having a video created."""
        if topic not in self.data["used_topics"]:
            log_action("MARK_VIDEO", f"Topic not found: {topic}", "WARNING")
            return False

        self.data["used_topics"][topic]["video_count"] += 1
        self._save_topics()
        log_action("MARK_VIDEO", f"Marked video for: {topic}")
        return True

    def get_compilation_status(self, category: str = None) -> Dict:
        """Check which categories are ready for compilation."""
        threshold = config.get("compilation.videos_before_compile", 5)
        status = {}

        categories = [category] if category else self.data.get("collections", {}).keys()

        for cat in categories:
            topics = self.data.get("collections", {}).get(cat, [])
            video_count = sum(
                self.data["used_topics"].get(t, {}).get("video_count", 0) for t in topics
            )

            status[cat] = {
                "total_topics": len(topics),
                "videos_created": video_count,
                "ready_for_compilation": video_count >= threshold,
                "progress": f"{video_count}/{threshold}",
            }

        return status

    def get_pending_compilation_topics(self, category: str) -> List[str]:
        """Get topics ready for compilation in a category."""
        topics = self.get_topic_by_category(category)
        return [t for t in topics if self.data["used_topics"].get(t, {}).get("video_count", 0) > 0]

    def mark_compiled(self, category: str, topics: List[str]):
        """Mark topics as compiled into a full-length video."""
        if "compilation_history" not in self.data:
            self.data["compilation_history"] = []

        compilation = {
            "category": category,
            "topics": topics,
            "compiled_at": datetime.now().isoformat(),
            "video_count": len(topics),
        }

        self.data["compilation_history"].append(compilation)
        self._save_topics()
        log_action("MARK_COMPILED", f"Compiled {len(topics)} topics from {category}")

    def display_status(self):
        """Display current topic management status."""
        print("\n" + "=" * 70)
        print("TOPIC MANAGEMENT STATUS")
        print("=" * 70)

        print(f"\nTotal Topics Used: {self.data['metadata']['total_topics']}")

        status = self.get_compilation_status()
        print("\nCATEGORY STATUS:")
        print("-" * 70)

        for category, info in status.items():
            ready = "✓ READY" if info["ready_for_compilation"] else "○ In Progress"
            print(
                f"{category:25} | Topics: {info['total_topics']:3} | "
                f"Videos: {info['progress']:8} | {ready}"
            )

        print("-" * 70)
        print()

    def list_all_topics(self):
        """Display all topics organized by category."""
        print("\n" + "=" * 70)
        print("ALL TOPICS BY CATEGORY")
        print("=" * 70)

        for category in sorted(self.data.get("collections", {}).keys()):
            topics = self.data["collections"][category]
            print(f"\n[{category}] ({len(topics)} topics)")
            print("-" * 70)

            for i, topic in enumerate(topics, 1):
                info = self.data["used_topics"].get(topic, {})
                videos = info.get("video_count", 0)
                created = info.get("created_at", "N/A")[:10]
                print(f"  {i:2}. {topic:50} | Videos: {videos} | Added: {created}")

        print("\n" + "=" * 70 + "\n")

    def validate_topic(self, topic: str) -> tuple[bool, str]:
        """Validate topic before adding."""
        topic = topic.strip()

        if not topic:
            return False, "Topic cannot be empty"

        if len(topic) < 3:
            return False, "Topic must be at least 3 characters"

        if len(topic) > 200:
            return False, "Topic cannot exceed 200 characters"

        if self._is_duplicate(topic):
            return False, f"Topic '{topic}' already exists"

        return True, "Valid"

    def bulk_add_topics(self, topics: List[str]) -> Dict[str, bool]:
        """Add multiple topics at once. Returns status for each."""
        results = {}

        for topic in topics:
            is_valid, msg = self.validate_topic(topic)

            if not is_valid:
                results[topic] = False
                log_action("BULK_ADD", f"Invalid: {topic} - {msg}", "WARNING")
            else:
                success = self.add_topic(topic)
                results[topic] = success

        return results

    def export_topics(self, filepath: Path = None) -> str:
        """Export topics to JSON file."""
        if filepath is None:
            filepath = DATA_DIR / f"topics_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"

        save_json(self.data, filepath)
        log_action("EXPORT", f"Exported to {filepath}")
        return str(filepath)

    def get_stats(self) -> Dict:
        """Get statistics about topics."""
        stats = {
            "total_topics": len(self.data["used_topics"]),
            "total_categories": len(self.data["collections"]),
            "total_videos_created": sum(
                self.data["used_topics"].get(t, {}).get("video_count", 0)
                for t in self.data["used_topics"]
            ),
            "categories": {},
        }

        for category, topics in self.data["collections"].items():
            stats["categories"][category] = {
                "topic_count": len(topics),
                "video_count": sum(
                    self.data["used_topics"].get(t, {}).get("video_count", 0) for t in topics
                ),
            }

        return stats
