"""
Compilation engine: Group videos by category and create longer compilations.
Automatically creates full-length videos from 5+ Shorts videos.
"""

import json
import subprocess
from pathlib import Path
from typing import Dict, List, Tuple, Optional
from config import config, VIDEOS_DIR, COMPILATIONS_DIR
from utils import logger, timer

# ============================================================================
# COMPILATION ENGINE
# ============================================================================

class CompilationEngine:
    """Create compilation videos from multiple Shorts."""
    
    def __init__(self):
        self.videos_dir = VIDEOS_DIR
        self.compilations_dir = COMPILATIONS_DIR
        self.min_videos_for_compilation = config.get("compilation", "min_videos_for_compilation")
        self.ordering_method = config.get("compilation", "ordering_method")
        self.include_intro = config.get("compilation", "include_intro")
        self.include_outro = config.get("compilation", "include_outro")
        self.add_transitions = config.get("compilation", "add_transitions")
    
    def get_category_videos(self, category: str) -> List[Path]:
        """Get all videos in a category."""
        category_dir = self.videos_dir / category
        
        if not category_dir.exists():
            return []
        
        videos = list(category_dir.glob("*.mp4"))
        return sorted(videos)
    
    def get_compilable_categories(self) -> Dict[str, List[Path]]:
        """Get all categories with enough videos for compilation."""
        compilable = {}
        
        # Scan all category directories
        for category_dir in self.videos_dir.iterdir():
            if not category_dir.is_dir():
                continue
            
            videos = list(category_dir.glob("*.mp4"))
            
            if len(videos) >= self.min_videos_for_compilation:
                compilable[category_dir.name] = sorted(videos)
                logger.info(f"✅ {category_dir.name}: {len(videos)} videos ready for compilation")
        
        return compilable
    
    def order_videos(self, videos: List[Path], method: Optional[str] = None) -> List[Path]:
        """
        Order videos for compilation.
        
        Args:
            videos: List of video paths
            method: 'sequential', 'random', 'duration', or None (use config)
        
        Returns:
            Ordered list of video paths
        """
        if method is None:
            method = self.ordering_method
        
        if method == "sequential":
            return sorted(videos)
        
        elif method == "random":
            import random
            ordered = videos.copy()
            random.shuffle(ordered)
            return ordered
        
        elif method == "duration":
            # Sort by file size (proxy for duration)
            return sorted(videos, key=lambda p: p.stat().st_size)
        
        else:
            return sorted(videos)
    
    @timer
    def create_compilation(
        self,
        category: str,
        videos: List[Path],
        output_name: Optional[str] = None
    ) -> Tuple[bool, str, Optional[Path]]:
        """
        Create a compilation video from multiple Shorts.
        
        Args:
            category: Category name
            videos: List of video paths
            output_name: Custom output filename
        
        Returns:
            (success, message, filepath)
        """
        if len(videos) < self.min_videos_for_compilation:
            return False, f"❌ Not enough videos ({len(videos)} < {self.min_videos_for_compilation})", None
        
        try:
            # Create output directory
            self.compilations_dir.mkdir(parents=True, exist_ok=True)
            
            if output_name is None:
                output_name = f"{category}_compilation_v{len(list(self.compilations_dir.glob(f'{category}_*'))) + 1}.mp4"
            
            output_path = self.compilations_dir / output_name
            
            logger.info(f"🎬 Creating compilation: {category} ({len(videos)} videos)")
            
            # Create concat file for FFmpeg
            concat_file = Path("/tmp") / f"concat_{int(__import__('time').time())}.txt"
            
            with open(concat_file, 'w') as f:
                for video_path in videos:
                    f.write(f"file '{video_path.absolute()}'\n")
            
            logger.debug(f"Concat file: {concat_file}")
            
            # Use FFmpeg to concatenate videos
            cmd = [
                "ffmpeg",
                "-f", "concat",
                "-safe", "0",
                "-i", str(concat_file),
                "-c", "copy",  # Copy codec, don't re-encode
                "-y",
                str(output_path)
            ]
            
            logger.debug(f"FFmpeg command: {' '.join(cmd)}")
            
            result = subprocess.run(cmd, capture_output=True, timeout=600)
            
            # Cleanup
            concat_file.unlink(missing_ok=True)
            
            if result.returncode != 0:
                error = result.stderr.decode() if result.stderr else "Unknown error"
                logger.error(f"FFmpeg error: {error[:200]}")
                return False, f"❌ Compilation failed", None
            
            if output_path.exists():
                file_size = output_path.stat().st_size / (1024 * 1024)
                logger.info(f"✅ Compilation created ({file_size:.1f} MB)")
                return True, f"✅ Compilation created: {output_path.name}", output_path
            else:
                return False, "❌ Compilation file not created", None
        
        except subprocess.TimeoutExpired:
            return False, "⏱️  Compilation timed out", None
        except Exception as e:
            logger.error(f"❌ Error: {e}")
            return False, f"❌ Error: {str(e)}", None
    
    def create_all_compilations(self, force: bool = False) -> Dict[str, Tuple[bool, Path]]:
        """
        Create compilations for all compilable categories.
        
        Args:
            force: Force creation even if compilation exists
        
        Returns:
            {category: (success, filepath)}
        """
        results = {}
        compilable = self.get_compilable_categories()
        
        for category, videos in compilable.items():
            # Check if compilation already exists
            existing = list(self.compilations_dir.glob(f"{category}_*.mp4"))
            
            if existing and not force:
                logger.info(f"⏭️  Skipping {category} (compilation already exists)")
                results[category] = (True, existing[0])
                continue
            
            # Order videos
            ordered_videos = self.order_videos(videos)
            
            # Create compilation
            success, message, filepath = self.create_compilation(category, ordered_videos)
            results[category] = (success, filepath)
            print(message)
        
        return results


# ============================================================================
# COMPILATION TRACKER
# ============================================================================

class CompilationTracker:
    """Track which compilations have been created."""
    
    def __init__(self):
        self.tracker_file = COMPILATIONS_DIR / "compilations.json"
        self.compilations = self._load_compilations()
    
    def _load_compilations(self) -> dict:
        """Load compilation history."""
        if self.tracker_file.exists():
            with open(self.tracker_file, 'r') as f:
                return json.load(f)
        return {}
    
    def _save_compilations(self):
        """Save compilation history."""
        self.tracker_file.parent.mkdir(parents=True, exist_ok=True)
        with open(self.tracker_file, 'w') as f:
            json.dump(self.compilations, f, indent=2)
    
    def record_compilation(self, category: str, filepath: Path, video_count: int):
        """Record a created compilation."""
        self.compilations[category] = {
            'filepath': str(filepath),
            'video_count': video_count,
            'created_at': __import__('time').time(),
            'uploaded': False
        }
        self._save_compilations()
        logger.info(f"📝 Recorded compilation: {category}")
    
    def mark_as_uploaded(self, category: str):
        """Mark compilation as uploaded."""
        if category in self.compilations:
            self.compilations[category]['uploaded'] = True
            self._save_compilations()
            logger.info(f"✅ Marked as uploaded: {category}")
    
    def get_pending_uploads(self) -> Dict[str, dict]:
        """Get compilations pending upload."""
        return {
            cat: data for cat, data in self.compilations.items()
            if not data.get('uploaded', False)
        }


# ============================================================================
# AUTO-COMPILATION MONITOR
# ============================================================================

class AutoCompilationMonitor:
    """Monitor video directories and auto-compile when thresholds are reached."""
    
    def __init__(self):
        self.engine = CompilationEngine()
        self.tracker = CompilationTracker()
        self.check_interval = config.get("compilation", "auto_check_interval")
    
    def check_and_compile(self) -> Dict[str, Tuple[bool, Path]]:
        """Check all categories and compile if needed."""
        results = {}
        compilable = self.engine.get_compilable_categories()
        
        for category, videos in compilable.items():
            # Check if we should compile
            last_compilation = self.tracker.compilations.get(category)
            
            if last_compilation:
                # Already have a compilation for this category
                # Only re-compile if we have significantly more videos
                if len(videos) > (last_compilation.get('video_count', 0) + 10):
                    logger.info(f"🔄 Re-compiling {category} (new videos added)")
                    success, message, filepath = self.engine.create_compilation(category, videos)
                    results[category] = (success, filepath)
                    
                    if success:
                        self.tracker.record_compilation(category, filepath, len(videos))
            else:
                # First compilation for this category
                success, message, filepath = self.engine.create_compilation(category, videos)
                results[category] = (success, filepath)
                
                if success:
                    self.tracker.record_compilation(category, filepath, len(videos))
                
                print(message)
        
        return results


# ============================================================================
# COMPILATION METADATA GENERATOR
# ============================================================================

class CompilationMetadataGenerator:
    """Generate metadata for compilation videos."""
    
    @staticmethod
    def generate_compilation_title(category: str, video_count: int) -> str:
        """Generate title for compilation."""
        return f"🎬 ULTIMATE {category.upper()} Compilation - {video_count} Best Videos"
    
    @staticmethod
    def generate_compilation_description(category: str, video_count: int, video_topics: list = None) -> str:
        """Generate description for compilation."""
        description = f"""🎯 {category.upper()} COMPILATION

Enjoy the ultimate collection of {category} videos! This compilation features {video_count} of the best videos on the topic.

📌 TOPICS COVERED:
"""
        
        if video_topics:
            for topic in video_topics[:10]:
                description += f"• {topic}\n"
        
        description += f"""
🔔 Subscribe for more compilations!
👍 Like if you enjoyed this
💬 Tell us your favorite in the comments!

#Compilation #{category} #YouTube
"""
        
        return description[:5000]
    
    @staticmethod
    def generate_compilation_tags(category: str) -> list:
        """Generate tags for compilation."""
        return [
            f"{category} compilation",
            "compilation",
            category,
            "best of",
            "shorts",
            "highlights",
            "clips"
        ]


# ============================================================================
# SINGLETON INSTANCES
# ============================================================================

compilation_engine = CompilationEngine()
compilation_tracker = CompilationTracker()
auto_monitor = AutoCompilationMonitor()
compilation_metadata = CompilationMetadataGenerator()

# ============================================================================
# COMMAND-LINE INTERFACE
# ============================================================================

def main():
    """Interactive compilation engine CLI."""
    from utils import print_header, print_success, print_error, print_info
    
    print_header("🎬 COMPILATION ENGINE")
    
    while True:
        print("\nOptions:")
        print("  1. Check compilable categories")
        print("  2. Create compilation for category")
        print("  3. Auto-compile all compilable categories")
        print("  4. View compilation history")
        print("  5. Exit")
        
        choice = input("\nSelect option (1-5): ").strip()
        
        if choice == "1":
            compilable = compilation_engine.get_compilable_categories()
            
            if compilable:
                print_success(f"Found {len(compilable)} compilable categories:")
                for category, videos in compilable.items():
                    print(f"  {category}: {len(videos)} videos")
            else:
                print_info("No compilable categories found")
        
        elif choice == "2":
            category = input("Enter category name: ").strip()
            videos = compilation_engine.get_category_videos(category)
            
            if not videos:
                print_error(f"No videos found in category: {category}")
                continue
            
            # Order videos
            ordering = input("Video ordering (sequential/random/duration) [sequential]: ").strip() or "sequential"
            ordered = compilation_engine.order_videos(videos, ordering)
            
            # Create compilation
            success, message, filepath = compilation_engine.create_compilation(category, ordered)
            print(message)
            
            if success:
                compilation_tracker.record_compilation(category, filepath, len(ordered))
                print_success(f"Saved to: {filepath}")
        
        elif choice == "3":
            results = auto_monitor.check_and_compile()
            
            if results:
                print_success(f"Auto-compilation complete ({len(results)} created)")
            else:
                print_info("No compilations created")
        
        elif choice == "4":
            compilations = compilation_tracker.compilations
            
            if compilations:
                print_success(f"Compilation history ({len(compilations)} total):")
                for category, data in compilations.items():
                    status = "✅ Uploaded" if data.get('uploaded') else "⏳ Pending"
                    print(f"  {category}: {data['video_count']} videos - {status}")
            else:
                print_info("No compilations created yet")
        
        elif choice == "5":
            print_info("Goodbye!")
            break
        
        else:
            print_error("Invalid option")

if __name__ == "__main__":
    main()
