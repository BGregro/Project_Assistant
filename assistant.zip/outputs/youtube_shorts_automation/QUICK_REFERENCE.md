# 🎬 YouTube Shorts Automation - Quick Reference

**Fast lookup for common commands and workflows**

---

## ⚡ One-Minute Setup Check

```bash
# 1. Ollama running?
ollama list
# Should show: qwen2.5

# 2. FFmpeg installed?
ffmpeg -version

# 3. Python dependencies?
pip list | grep -E "pyttsx3|PIL|requests"

# 4. Ready to go?
python src/main.py --help
```

---

## 🎬 Common Commands

### **Create One Video**
```bash
python src/main.py --topic "Your topic here"
```

### **Interactive Menu**
```bash
python src/main.py --interactive
```

### **Batch Create (Multiple Videos)**
```bash
python src/main.py --batch topics.txt
```

### **Auto-Compile Videos**
```bash
python src/main.py --compile
```

### **View Statistics**
```bash
python src/main.py --stats
```

### **Show Topic History**
```bash
python src/main.py --show-history
```

### **Get Help**
```bash
python src/main.py --help
```

---

## 🎨 Thumbnail Selection Quick Guide

Choose based on **topic type**:

| Topic | Thumbnail | Command |
|-------|-----------|---------|
| Tutorial | `v1` (High Contrast) | [1] |
| Intriguing | `v2` (Curiosity Hook) | [2] |
| Professional | `v3` (Minimal) | [3] |
| "How to..." | `v4` (Benefit-Driven) | [4] |
| Trending | `v5` (Trending Bold) | [5] |
| Not sure? | `v1` or `a` (auto) | [1] or [a] |

---

## 📁 Key File Locations

```
youtube_shorts_automation/
├── config.json              ← Edit settings here
├── data/
│   ├── topics.json          ← Used topics
│   └── thumbnails/          ← All thumbnails
├── output/
│   ├── videos/              ← MP4 files (by category)
│   ├── scripts/             ← Generated scripts
│   ├── voiceovers/          ← MP3 audio files
│   └── thumbnails/          ← PNG thumbnail images
└── src/
    └── main.py              ← Run this file
```

---

## ⚙️ Configuration Tweaks

### **Change Voiceover Speed**
Edit `config.json`:
```json
"voiceover": {
  "rate": 150  // 100-200 (lower = slower)
}
```

### **Change Voice Gender**
```json
"voiceover": {
  "voice": "male"  // or "female"
}
```

### **Auto-Upload Videos**
```json
"upload": {
  "auto_upload": true  // Upload immediately after generation
}
```

### **Auto-Compile Settings**
```json
"compilation": {
  "min_videos_for_compilation": 5  // Compile after 5 videos
}
```

---

## 🚀 Workflows

### **Workflow 1: Create 5 Videos in 1 Hour**

```bash
# 1. Create topics.txt with 5 topics:
python src/main.py --batch topics.txt

# 2. System will ask you to choose thumbnails for each
# 3. All 5 done in ~40 minutes (wait for prompts)
# 4. Uploaded to YouTube
```

### **Workflow 2: Weekly Content Creation**

```bash
# Monday: Create batch
python src/main.py --batch monday_videos.txt

# Friday: Compile this week's videos
python src/main.py --compile

# Result: 5 Shorts + 1 Compilation video
```

### **Workflow 3: Test & Iterate**

```bash
# Create 1 test video
python src/main.py --topic "Test Topic"

# Review video at: output/videos/test_topic.mp4

# If good: create more
# If bad: adjust config.json and try again
```

---

## 🛠️ Troubleshooting Quick Fixes

### **"Ollama not available"**
```bash
# Open new Command Prompt:
ollama serve
# Keep it running while creating videos
```

### **"FFmpeg not found"**
```bash
ffmpeg -version  # Check if installed
# If not, download from: https://ffmpeg.org/download.html
```

### **"Module not found"**
```bash
pip install -r requirements.txt
```

### **"Video won't create"**
```bash
# Check voiceover exists:
dir output\voiceovers\
# Should have MP3 files
```

### **"YouTube upload fails"**
1. Check `youtube_client_secrets.json` exists in root
2. Make sure YouTube API is enabled
3. First upload may need browser auth (system opens automatically)

---

## 📊 Performance Expectations

| Task | Time | Notes |
|------|------|-------|
| Script generation | 30-60 sec | First run takes longer |
| Voiceover creation | 20-30 sec | Audio synthesis |
| Thumbnail variants | 30-45 sec | 5 design variants |
| Video synthesis | 2-5 min | Using CPU |
| **Total per video** | **~5-10 min** | Fully automated |
| **Batch of 5** | **~25-35 min** | After your thumbnail choices |

---

## 💾 Storage Usage

| Item | Size | Notes |
|------|------|-------|
| Per video | ~100-150 MB | 60-90 second Shorts |
| Voiceover MP3 | ~5-10 MB | 60-90 sec audio |
| Thumbnail PNG | ~40-50 KB | 5 variants |
| Monthly (20 videos) | ~2.4 GB | Reasonable |
| Ollama model | ~5 GB | One-time download |

You have 639 GB free - **no worries** ✅

---

## 📱 Best YouTube Practices

### **Upload Times (Tech Audience)**
- **Weekday 9 AM** - Before work (best)
- **Weekday 12 PM** - Lunch break
- **Weekday 5 PM** - After work
- **Avoid:** Late night, weekends, early morning

### **Video Frequency**
- **Month 1:** 2-3 videos/week (testing)
- **Month 2+:** 3-5 videos/week (consistency)
- **Compilations:** Every 5 videos (auto-stitch)

### **Category Best Practices**
- Keep 3-5 category collections
- Build depth in each (5+ videos per category)
- Use compilations to boost watch time

### **Thumbnail A/B Testing**
- Month 1: Watch which variants perform best
- Month 2: Use best-performing variants more
- Month 3+: Optimize by category

---

## 🎯 Success Metrics to Track

### **Short-term (Weeks 1-4)**
- [ ] 5-10 videos created
- [ ] Videos uploading successfully
- [ ] Getting first views (100-500 per video)

### **Medium-term (Months 2-3)**
- [ ] 20-30 videos published
- [ ] 100+ total watch hours
- [ ] 500+ channel subscribers
- [ ] Approaching YouTube Partner Program

### **Long-term (Months 4-12)**
- [ ] 1,000+ subscribers ✓
- [ ] 4,000 watch hours ✓
- [ ] Monetization enabled
- [ ] $500-1,500/month revenue

---

## 🔄 Maintenance Commands

### **Check System Status**
```bash
python src/main.py --status
```

### **View All Videos**
```bash
python src/main.py --list-videos
```

### **View All Topics Used**
```bash
python src/main.py --show-history
```

### **Refresh Metadata**
```bash
python src/main.py --refresh
```

### **Clear Cache (if stuck)**
```bash
python src/main.py --clear-cache
```

---

## 📝 Batch File Examples

### **Python Tips (5 videos)**
```
Python list comprehensions
Lambda functions explained
Async/await for beginners
Decorators in Python
Python context managers
```

### **AI Tools (5 videos)**
```
ChatGPT 4.5 best features
Claude 3 analysis tool
Ollama local AI setup
Stable Diffusion guide
LLaMA 2 tutorial
```

### **Web Development (5 videos)**
```
React hooks explained
Docker containers basics
REST API design patterns
SQL optimization tips
CSS Grid mastery
```

---

## 🚀 Getting Started (5 Steps)

1. **Install Ollama**
   ```bash
   ollama pull qwen2.5
   ollama serve
   ```

2. **Install Dependencies**
   ```bash
   pip install -r requirements.txt
   ```

3. **Start Creating**
   ```bash
   python src/main.py --interactive
   ```

4. **Choose Thumbnails**
   Select your favorite from 5 variants for each video

5. **Upload & Monitor**
   Approve uploads and watch your channel grow!

---

## 💡 Pro Tips

**Tip 1:** Always keep Ollama running
```bash
ollama serve  # In separate Command Prompt window
```

**Tip 2:** Batch process on weekends
Create 10-15 videos at once, upload throughout week

**Tip 3:** Test thumbnails systematically
Try each variant type and track which performs best

**Tip 4:** Use compilations strategically
Every 5 videos = 1 compilation video (doubles watch time)

**Tip 5:** Monitor early metrics
First 24 hours = algorithm importance (get quick views)

---

## 🆘 Emergency Commands

**If everything is broken:**
```bash
# 1. Delete cache
python src/main.py --clear-cache

# 2. Reinstall dependencies
pip install -r requirements.txt --force-reinstall

# 3. Test connection
python -c "import requests; print(requests.get('http://localhost:11434/api/tags').json())"

# 4. Restart everything
# Restart Command Prompt, restart Ollama
```

---

## 📞 Common Questions

**Q: How long until monetization?**
A: 1-3 months with consistent uploads (1k subs + 4k hours)

**Q: How much money can I make?**
A: $8-20 CPM (Cost Per Mille) = $100-2,000/month at 100k views

**Q: Can I edit videos after creation?**
A: Yes! All MP4s can be edited with DaVinci Resolve, CapCut, etc.

**Q: What if a topic fails?**
A: Very rare. Just try a different topic.

**Q: Can I use custom voiceovers?**
A: Replace MP3 files in `output/voiceovers/` before video creation

**Q: How do I delete a video?**
A: Delete MP4 from `output/videos/`, then run `python src/main.py --refresh`

---

## 🎓 Learn More

- **COMPLETE_USER_GUIDE.md** - Detailed setup & workflows
- **THUMBNAIL_GENERATOR_QUICK_START.md** - Thumbnail A/B testing
- **SYSTEM_DESIGN.md** - Architecture & design decisions
- **README.md** - Feature overview

---

## 🔗 Important Links

- **Ollama:** https://ollama.ai/
- **FFmpeg:** https://ffmpeg.org/download.html
- **YouTube API:** https://developers.google.com/youtube/v3
- **Google Cloud Console:** https://console.cloud.google.com/

---

**Last Updated:** June 2025  
**Version:** 1.0 (With Thumbnail Generator)  
**Ready to create?** `python src/main.py --interactive` ✨
