# 🎥 YouTube Shorts Automation System

**Fully automated AI-powered YouTube Shorts video generation and compilation.**

Create, compile, and publish YouTube Shorts videos with **just one input: the topic**. Everything else is automated — from script generation to video synthesis to YouTube upload.

## ✨ Key Features

✅ **100% Automated Workflow**
- Topic Input → Script Generation → Voiceover → Video Creation → Upload → Compilation
- 5-7 minutes per video start-to-finish

✅ **No API Costs** (100% Local)
- Ollama (local LLM) for script generation
- pyttsx3 (local TTS) for voiceover
- FFmpeg (local video processing)
- Zero external API calls

✅ **Smart Topic Management**
- Duplicate prevention (never create same video twice)
- Automatic categorization
- Category-based folder organization
- Ready-to-compile collections

✅ **Manual or Automatic Upload**
- Manual approval mode (review before posting)
- Scheduled upload mode
- Automatic upload mode
- Full YouTube integration with OAuth2

✅ **Auto-Compilation**
- Automatically creates longer videos from 5+ Shorts
- Configurable ordering (sequential, random, duration-based)
- Full-length compilations boost watch time & revenue

✅ **YouTube Compliant**
- Monetization-eligible content
- Dual upload: Shorts + Full videos
- CPM: $8-20 per 1K views (tech content)

## 📊 System Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                   YOUTUBE SHORTS AUTOMATION                  │
├─────────────────────────────────────────────────────────────┤
│                                                               │
│  TOPIC INPUT (Human: You provide the topic)                 │
│         ↓                                                     │
│  SCRIPT GENERATION (Ollama qwen2.5 - 30-60 sec)            │
│         ↓                                                     │
│  VOICEOVER SYNTHESIS (pyttsx3 TTS - 20-30 sec)             │
│         ↓                                                     │
│  VIDEO SYNTHESIS (FFmpeg composition - 2-5 min)            │
│         ↓                                                     │
│  THUMBNAIL GENERATION (Pillow - 10 sec)                     │
│         ↓                                                     │
│  MANUAL APPROVAL (Optional - you review)                    │
│         ↓                                                     │
│  YOUTUBE UPLOAD (OAuth2 API - 30-60 sec)                    │
│         ↓                                                     │
│  CATEGORY TRACKING (Organize by topic collections)          │
│         ↓                                                     │
│  AUTO-COMPILATION (Group 5+ videos per category)            │
│         ↓                                                     │
│  PUBLISH COMPILATIONS (Longer videos boost watch time)      │
│                                                               │
└─────────────────────────────────────────────────────────────┘
```

## 🚀 Quick Start

### Prerequisites

**System Requirements:**
- Windows 10+, macOS, or Linux
- 8GB+ RAM (16GB+ recommended)
- 50GB+ free disk space
- Internet connection (for YouTube upload)

**Software Requirements:**

1. **Ollama + qwen2.5 Model** (Local LLM)
   ```bash
   # Download from https://ollama.ai/
   ollama pull qwen2.5
   ```

2. **FFmpeg** (Video processing)
   - **Windows**: Download from https://ffmpeg.org/download.html
   - **macOS**: `brew install ffmpeg`
   - **Linux**: `sudo apt-get install ffmpeg`

3. **YouTube API Credentials** (For upload feature)
   - Go to: https://console.cloud.google.com/
   - Create new project
   - Enable YouTube Data API v3
   - Create OAuth2 credentials (Desktop Application)
   - Download JSON file → save as `youtube_client_secrets.json` in project root

### Installation

```bash
# 1. Clone or download project
cd youtube_shorts_automation

# 2. Create virtual environment
python -m venv venv

# 3. Activate venv
# Windows:
venv\Scripts\activate
# macOS/Linux:
source venv/bin/activate

# 4. Install Python dependencies
pip install -r requirements.txt

# 5. Test installation
python src/main.py --help
```

### First Run

```bash
# Interactive mode (recommended for first time)
python src/main.py --interactive

# Or create a single video:
python src/main.py --topic "Python list comprehensions"
```

## 📖 Usage Guide

### Mode 1: Interactive Menu (Easiest)

```bash
python src/main.py --interactive
```

Walk through menus:
1. Create Single Video
2. Create Batch Videos
3. Compile Categories
4. View Statistics
5. Settings

### Mode 2: Single Video (Command-line)

```bash
python src/main.py --topic "Your video topic here"
```

Creates one video, asks for approval, uploads if approved.

### Mode 3: Batch Processing

Create a file `topics.txt`:
```
Python list comprehensions
Async programming explained
Git workflow for beginners
Machine learning overview
Data structures tutorial
```

Run:
```bash
python src/main.py --batch topics.txt
```

Creates all videos, asks for approval on each.

### Mode 4: Auto-Compile

```bash
python src/main.py --compile
```

Automatically creates compilations from existing videos:
- Groups videos by category
- Creates longer full-length videos
- Improves watch time & revenue

## ⚙️ Configuration

Edit `config.json` to customize:

```json
{
  "upload": {
    "auto_upload": false,           // Auto-upload without approval
    "approval_required": true,      // Require manual review
    "upload_frequency": "manual"    // "manual", "scheduled", "automatic"
  },
  "compilation": {
    "auto_compile_enabled": true,   // Auto-compile when enough videos
    "min_videos_for_compilation": 5,
    "ordering_method": "sequential" // "sequential", "random", "duration"
  },
  "voiceover": {
    "voice": "female",              // "male" or "female"
    "rate": 150,                    // Words per minute (50-300)
    "volume": 0.9                   // 0.0-1.0
  },
  "script_generation": {
    "style": "engaging",            // "educational", "entertaining", etc.
    "include_hook": true,           // Attention-grabbing opening
    "include_cta": true             // Call-to-action ending
  }
}
```

## 📁 Project Structure

```
youtube_shorts_automation/
├── src/
│   ├── main.py                    # Main orchestrator & CLI
│   ├── config.py                  # Configuration manager
│   ├── utils.py                   # Logging, utilities
│   ├── topic_manager.py           # Topic tracking & categorization
│   ├── script_generator.py        # Ollama integration
│   ├── voiceover_synthesis.py     # pyttsx3 TTS
│   ├── video_synthesizer.py       # FFmpeg video creation
│   ├── youtube_uploader.py        # YouTube API integration
│   └── compilation_engine.py      # Auto-compilation system
├── data/
│   ├── topics.json                # Used topics (prevents duplicates)
│   ├── categories.json            # Topic collections
│   └── config.json                # Settings
├── output/
│   ├── scripts/                   # Generated scripts
│   ├── voiceovers/                # Generated MP3 files
│   ├── videos/                    # Generated MP4 videos (by category)
│   ├── thumbnails/                # Generated thumbnails
│   └── compilations/              # Auto-compiled videos
├── requirements.txt               # Python dependencies
├── README.md                      # This file
└── SYSTEM_DESIGN.md              # Detailed technical documentation
```

## 💰 Revenue Potential

### Timeline
- **Months 1-3**: Build audience (0-300 subscribers, $0/month)
- **Months 4-6**: Hit monetization threshold (1k subs + 4k watch hours) → $50-300/month
- **Months 6-12**: Scale to 5,000+ subscribers → $500-1,500/month
- **Year 2+**: Established channel → $1,000-3,000+/month

### How It Works
1. **CPM** (Cost Per Mille): $8-20 per 1,000 views for tech content
2. **Watch time**: Compilations (longer videos) boost total watch time
3. **Growth**: Consistent uploads → algorithmic boost → faster growth

### Example
- 50 Shorts videos @ 100 views each = 5,000 views
- 10 compilations @ 500 views each = 5,000 views
- Total: 10,000 views/month
- At $12 CPM: **$120/month** (passive income)
- Scale to 100K views: **$1,200/month**

## ⚠️ YouTube Compliance

**Your Content is Monetization-Eligible**

YouTube's July 2025 policy requires at least ONE element to be human-created:
- ✅ **You pick the topic** (human input)
- ✅ AI generates script (tool-assisted)
- ✅ AI generates voiceover (allowed)
- ✅ AI generates visuals (allowed)

**Result**: Fully monetizable, 100% legal, ethical AI use.

## 🛠️ Troubleshooting

### Ollama Not Found
```bash
# Make sure Ollama is running
ollama serve

# In another terminal, pull the model
ollama pull qwen2.5

# Test connection
curl http://localhost:11434/api/tags
```

### FFmpeg Not Found
- **Windows**: Add FFmpeg to PATH or download from ffmpeg.org
- **macOS**: `brew install ffmpeg`
- **Linux**: `sudo apt-get install ffmpeg`

### YouTube Upload Not Working
- Check OAuth2 credentials file exists
- Verify YouTube API is enabled in Google Cloud Console
- Make sure credentials have "youtube.upload" scope

### Videos Too Long/Short
Adjust voiceover rate in config.json:
```json
"voiceover": {
  "rate": 150  // Lower = slower (more time), Higher = faster
}
```

## 📚 Additional Resources

- **SYSTEM_DESIGN.md** - Detailed architecture documentation
- **config.json** - All configuration options explained
- **YouTube API Docs** - https://developers.google.com/youtube/v3
- **Ollama Documentation** - https://ollama.ai/
- **FFmpeg Guide** - https://ffmpeg.org/documentation.html

## 🤝 Contributing

This is a personal project, but you can:
- Report bugs
- Suggest features
- Improve documentation
- Optimize performance

## ⚖️ License

MIT License - Use freely, modify, redistribute

## 📝 Version History

**v1.0 (Current)**
- ✅ Complete video generation pipeline
- ✅ Topic management with duplicate prevention
- ✅ YouTube upload integration
- ✅ Auto-compilation system
- ✅ Manual approval workflow
- ✅ Batch processing

**v2.0 (Planned)**
- GUI/Web interface
- Advanced analytics
- Scheduled uploads
- Video editing interface
- Multi-language support

## 🎯 Next Steps

1. ✅ Install all prerequisites
2. ✅ Run `python src/main.py --interactive`
3. ✅ Enter a test topic (e.g., "Python tips")
4. ✅ Review the generated video
5. ✅ Approve for upload
6. ✅ Repeat with more topics
7. ✅ Use `--compile` to create compilations

**Start with 5-10 videos to test everything works properly, then scale up!**

---

**Happy video creation! 🚀📹**

Questions? Check SYSTEM_DESIGN.md or adjust config.json
