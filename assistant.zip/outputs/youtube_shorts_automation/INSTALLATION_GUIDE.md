# 🔧 Complete Installation Guide

Step-by-step instructions to set up the YouTube Shorts Automation System on your Windows laptop.

## 📋 Prerequisites Checklist

- [ ] Windows 10 or Windows 11
- [ ] Python 3.9+ installed (check: `python --version`)
- [ ] At least 50GB free disk space
- [ ] Internet connection (for YouTube upload, Ollama download)
- [ ] ~30 minutes setup time

## ⏱️ Installation Steps (30 minutes total)

### Step 1: Install Ollama (10 minutes)

**What is Ollama?** Local AI model that generates scripts (no API costs)

1. Download Ollama from: https://ollama.ai/
2. Run installer, follow prompts
3. After installation, open Command Prompt:
   ```bash
   ollama --version
   ```
   Should show version number

4. Download qwen2.5 model (will download ~5GB):
   ```bash
   ollama pull qwen2.5
   ```
   This takes 10-15 minutes depending on internet speed

5. Test it's working:
   ```bash
   ollama serve
   ```
   Should show: `Listening on http://127.0.0.1:11434`
   Keep this running! ✅ (Open new Command Prompt for next steps)

**Note:** Ollama runs in background and starts automatically after reboot.

### Step 2: Install FFmpeg (5 minutes)

**What is FFmpeg?** Local video processing tool (creates MP4 files)

#### Option A: Using Chocolatey (Easiest)
```bash
# If you have Chocolatey installed:
choco install ffmpeg
```

#### Option B: Manual Installation (Recommended if no Chocolatey)
1. Download from: https://ffmpeg.org/download.html
2. Click "Windows builds by BtbN"
3. Download "ffmpeg-master-latest-win64-gpl.zip" (~200MB)
4. Extract to: `C:\ffmpeg`
5. Add to PATH:
   - Right-click "This PC" → Properties
   - Click "Advanced system settings"
   - Click "Environment Variables"
   - Under "System variables", find "Path", click Edit
   - Click "New", add: `C:\ffmpeg\bin`
   - Click OK, OK, OK

6. Test installation:
   ```bash
   ffmpeg -version
   ```
   Should show version info ✅

### Step 3: Install Python Dependencies (5 minutes)

1. Open Command Prompt in project folder:
   ```bash
   # Navigate to the project
   cd C:\path\to\youtube_shorts_automation
   ```

2. Create virtual environment:
   ```bash
   python -m venv venv
   ```

3. Activate virtual environment:
   ```bash
   venv\Scripts\activate
   ```
   You should see `(venv)` at start of command line

4. Install Python packages:
   ```bash
   pip install -r requirements.txt
   ```
   Takes 2-3 minutes, watch for "Successfully installed" message ✅

### Step 4: (Optional) Set Up YouTube Upload

Skip this if you don't want to upload to YouTube yet. You can add it later.

#### If you want YouTube upload:

1. Go to: https://console.cloud.google.com/
2. Create a new project (name: "YouTube Shorts Automation")
3. Search for "YouTube Data API v3"
4. Click "Enable"
5. Go to Credentials (left sidebar)
6. Click "Create Credentials" → "OAuth client ID"
7. Choose "Desktop application"
8. Download JSON file
9. Save as `youtube_client_secrets.json` in project root folder

## ✅ Verify Everything Works

Run these tests in order (with Ollama still running):

### Test 1: Python Environment
```bash
python --version
# Should show Python 3.9 or higher
```

### Test 2: Ollama Connection
```bash
python -c "import requests; print(requests.get('http://localhost:11434/api/tags').json())"
# Should show available models including qwen2.5
```

### Test 3: FFmpeg
```bash
ffmpeg -version
# Should show version info
```

### Test 4: All Dependencies
```bash
python -c "import pyttsx3, requests, PIL; print('✅ All dependencies installed!')"
```

### Test 5: Launch Application
```bash
python src/main.py --help
# Should show help message with all commands
```

## 🚀 First Run

With Ollama running in background:

```bash
# Interactive mode (easiest for first time)
python src/main.py --interactive

# Or test with a single video:
python src/main.py --topic "Python tips"
```

## 📁 Project Structure After Setup

```
C:\path\to\youtube_shorts_automation\
├── venv\                          # Python environment (created)
├── src\
│   ├── main.py
│   ├── config.py
│   ├── topic_manager.py
│   ├── script_generator.py
│   ├── voiceover_synthesis.py
│   ├── video_synthesizer.py
│   ├── youtube_uploader.py
│   ├── compilation_engine.py
│   └── utils.py
├── data\
│   ├── config.json                # Settings (will be created)
│   ├── topics.json                # Tracked topics (will be created)
│   └── categories.json            # Topic collections (will be created)
├── output\
│   ├── scripts\                   # Generated scripts
│   ├── voiceovers\                # MP3 audio files
│   ├── videos\                    # MP4 videos (organized by category)
│   ├── thumbnails\                # Video thumbnails
│   └── compilations\              # Compiled videos
├── youtube_client_secrets.json    # (Optional, if YouTube upload enabled)
├── requirements.txt
├── README.md
└── INSTALLATION_GUIDE.md (this file)
```

## ⚠️ Troubleshooting

### "Ollama is not available" Error

**Problem:** System can't connect to Ollama

**Solution:**
1. Make sure Ollama is running:
   ```bash
   # Open new Command Prompt and run:
   ollama serve
   ```
   Should show: `Listening on http://127.0.0.1:11434`

2. Keep this window open while using the app

3. Check if qwen2.5 model is downloaded:
   ```bash
   ollama list
   # Should show: qwen2.5  
   ```

### "FFmpeg not found" Error

**Problem:** System can't find FFmpeg

**Solution:**
1. Verify FFmpeg installed:
   ```bash
   ffmpeg -version
   ```

2. If not found, re-check PATH:
   - Right-click "This PC" → Properties
   - Advanced system settings → Environment Variables
   - Check "Path" has `C:\ffmpeg\bin`
   - Restart Command Prompt

### "pyttsx3 is not installed" Error

**Solution:**
```bash
# Make sure venv is activated, then:
pip install pyttsx3
```

### Voiceover Doesn't Sound Good

Edit `config.json`:
```json
{
  "voiceover": {
    "voice": "female",    // Try "male"
    "rate": 150,         // Lower = slower, higher = faster
    "volume": 0.9        // 0.0-1.0
  }
}
```

### Videos Won't Create (FFmpeg Error)

**Problem:** FFmpeg can't create video

**Check:**
1. FFmpeg is installed: `ffmpeg -version`
2. Voiceover MP3 exists and is valid
3. Disk has enough space (50GB+)
4. No special characters in filenames

### YouTube Upload Fails

**Problem:** Can't authenticate with YouTube

**Solution:**
1. Check `youtube_client_secrets.json` exists in root folder
2. Make sure YouTube Data API is enabled
3. First-time upload may require browser authentication
   - System will open browser window automatically
   - Grant permissions
   - Should work after that

## 🔄 Update/Reinstall

To reset everything and reinstall:

```bash
# Delete virtual environment
rmdir /s venv

# Delete generated files (optional)
rmdir /s output
rmdir /s data

# Reinstall
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt

# Restart application
python src/main.py --interactive
```

## 📚 Next Steps After Installation

1. **Test with sample topic:**
   ```bash
   python src/main.py --topic "Python list comprehensions"
   ```

2. **Review generated video** in `output/videos/` folder

3. **Create batch of videos:**
   - Create `topics.txt` with 5 topics (one per line)
   - Run: `python src/main.py --batch topics.txt`

4. **Enable YouTube upload:**
   - Set up credentials (see Step 4 above)
   - Approve videos one-by-one before uploading

5. **Auto-compile videos:**
   - After 5+ videos in a category
   - Run: `python src/main.py --compile`

## 💡 Tips

**Keep Ollama Running**
- Ollama needs to run in background for script generation
- After first setup, it auto-starts with Windows
- Check: `ollama serve` in Command Prompt

**First Run Takes Longer**
- Script generation slower on first run (Ollama initializing)
- Subsequent scripts are faster
- Video creation uses GPU if available (automatic)

**Monitor Disk Space**
- Each 60-second video: ~50-100MB
- Audio file: ~5-10MB
- Store videos on large drive if possible

**Customize Everything**
- Edit `config.json` to change voices, speeds, styles
- Change voiceover gender, speaking rate
- Enable/disable auto-upload
- Set compilation preferences

## ❓ Still Having Issues?

1. Check README.md for additional troubleshooting
2. Verify all prerequisites installed
3. Check internet connection (for Ollama download)
4. Make sure Windows is up-to-date
5. Try restarting computer after installation

---

**Setup complete!** You're ready to create AI-powered YouTube Shorts! 🚀
