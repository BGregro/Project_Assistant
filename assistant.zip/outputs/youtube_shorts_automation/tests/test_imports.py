"""
Basic test suite to verify all modules can be imported and core functionality works.
"""

import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

import pytest


def test_imports():
    """Test that all core modules can be imported."""
    try:
        from config import config, DATA_DIR
        from utils import log_action, get_logger
        from topic_manager import TopicManager
        from script_generator import ScriptGenerator
        from voiceover_synthesis import VoiceoverSynthesis
        from video_synthesizer import VideoSynthesizer
        from youtube_uploader import YouTubeUploader
        assert True
    except ImportError as e:
        pytest.fail(f"Import failed: {e}")

def test_config_exists():
    """Test that configuration can be loaded."""
    sys.path.insert(0, str(Path(__file__).parent.parent / "src"))
    from config import config
    
    assert config is not None
    # config is a Config object, not a dict
    assert hasattr(config, 'get')

def test_topic_manager_init():
    """Test that TopicManager can be instantiated."""
    sys.path.insert(0, str(Path(__file__).parent.parent / "src"))
    from topic_manager import TopicManager
    
    tm = TopicManager()
    assert tm is not None


def test_script_generator_init():
    """Test that ScriptGenerator can be instantiated."""
    sys.path.insert(0, str(Path(__file__).parent.parent / "src"))
    from script_generator import ScriptGenerator
    
    sg = ScriptGenerator()
    assert sg is not None


def test_voiceover_init():
    """Test that VoiceoverSynthesis can be instantiated."""
    sys.path.insert(0, str(Path(__file__).parent.parent / "src"))
    from voiceover_synthesis import VoiceoverSynthesis
    
    vo = VoiceoverSynthesis()
    assert vo is not None


def test_video_synthesizer_init():
    """Test that VideoSynthesizer can be instantiated."""
    sys.path.insert(0, str(Path(__file__).parent.parent / "src"))
    from video_synthesizer import VideoSynthesizer
    
    vs = VideoSynthesizer()
    assert vs is not None


def test_youtube_uploader_init():
    """Test that YouTubeUploader can be instantiated."""
    sys.path.insert(0, str(Path(__file__).parent.parent / "src"))
    from youtube_uploader import YouTubeUploader
    
    yu = YouTubeUploader()
    assert yu is not None


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
